# ospath.py is obsolete
import os
exec 'from %s import *' % os.name
