/* Leave this blank line here -- autoheader needs it! */


/* Define if your <unistd.h> contains bad prototypes for exec*()
   (as it does on SGI IRIX 4.x) */
#undef BAD_EXEC_PROTOTYPES

/* Define if your compiler botches static forward declarations
   (as it does on SCI ODT 3.0) */
#undef BAD_STATIC_FORWARD

/* Define to `long' if <time.h> doesn't define.  */
#undef clock_t

/* Define if getpgrp() must be called as getpgrp(0)
   and (consequently) setpgrp() as setpgrp(0, 0). */
#undef GETPGRP_HAVE_ARG

/* Define this if your time.h defines altzone */
#undef HAVE_ALTZONE

/* Define if your compiler supports function prototypes */
#undef HAVE_PROTOTYPES

/* Define if your compiler supports variable length function prototypes
   (e.g. void fprintf(FILE *, char *, ...);) *and* <stdarg.h> */
#undef HAVE_STDARG_PROTOTYPES

/* Define if you have POSIX threads */
#undef _POSIX_THREADS

/* Define to empty if the keyword does not work.  */
#undef signed

/* Define for SOLARIS 2.x */
#undef SOLARIS

/* Define if  you can safely include both <sys/select.h> and <sys/time.h>
   (which you can't on SCO ODT 3.0). */
#undef SYS_SELECT_WITH_SYS_TIME

/* Define if you want to use SGI (IRIX 4) dynamic linking.
   This requires the "dl" library by Jack Jansen,
   ftp://ftp.cwi.nl/pub/dynload/dl-1.6.tar.Z.
   Don't bother on IRIX 5, it already has dynamic linking using SunOS
   style shared libraries */ 
#undef WITH_SGI_DL

/* Define if you want to emulate SGI (IRIX 4) dynamic linking.
   This is rumoured to work on VAX (Ultrix), Sun3 (SunOS 3.4),
   Sequent Symmetry (Dynix), and Atari ST.
   This requires the "dl-dld" library,
   ftp://ftp.cwi.nl/pub/dynload/dl-dld-1.1.tar.Z,
   as well as the "GNU dld" library,
   ftp://ftp.cwi.nl/pub/dynload/dld-3.2.3.tar.Z.
   Don't bother on SunOS 4 or 5, they already have dynamic linking using
   shared libraries */ 
#undef WITH_DL_DLD

/* Define if you want to compile in rudimentary thread support */
#undef WITH_THREAD

/* Define if you want to use the GNU readline library */
#undef WITH_READLINE


/* Leave that blank line there-- autoheader needs it! */
