class Spam():
  def spam(self):
    print 9
    print 'I am here!'

print Spam().spam()

