# Module 'minmax'
# These are now built in functions.
# For compatibility, we export the builtins

min = min
max = max
