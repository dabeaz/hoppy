/***********************************************************
Copyright 1991, 1992 by Stichting Mathematisch Centrum, Amsterdam, The
Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Configurable Python configuration file */

#include "patchlevel.h"

#define VERSION "0.9.%d (%s)"

#ifdef __DATE__
#define DATE __DATE__
#else
#define DATE ">= 1 Jan 1992"
#endif

#include <stdio.h>

#ifdef USE_STDWIN
#include <stdwin.h>
#endif

char version[80];

char *argv0;

/*ARGSUSED*/
void
initargs(p_argc, p_argv)
	int *p_argc;
	char ***p_argv;
{
	sprintf(version, VERSION, PATCHLEVEL, DATE);

	argv0 = **p_argv;

#ifdef USE_STDWIN
	wargs(p_argc, p_argv);
#endif
	if (*p_argc < 2 && isatty(0) && isatty(1))
	{
		printf("Python %s.\n", version);
		printf(
"Copyright 1990, 1991, 1992 Stichting Mathematisch Centrum, Amsterdam\n");
	}
}

void
initcalls()
{
}

void
donecalls()
{
#ifdef USE_STDWIN
	wdone();
#endif
#ifdef USE_AUDIO
	asa_done();
#endif
}

#ifndef PYTHONPATH
#define PYTHONPATH ".:/usr/local/lib/python"
#endif

extern char *getenv();

char *
getpythonpath()
{
	char *path = getenv("PYTHONPATH");
	if (path == 0)
		path = PYTHONPATH;
	return path;
}


/* Table of built-in modules.
   These are initialized when first imported. */

/* Standard modules */
extern void inittime();
extern void initmath();
extern void initregex();
extern void initposix();
extern void initpwd();
extern void initgrp();
extern void initmarshal();

#ifdef USE_AUDIO
extern void initaudio();
#endif
#ifdef USE_AL
extern void inital();
#endif
#ifdef USE_AMOEBA
extern void initamoeba();
#endif
#ifdef USE_GL
extern void initgl();
#ifdef USE_FM
extern void initfm();
#ifdef USE_FL
extern void initfl();
#endif
#endif
#ifdef USE_PANEL
extern void initpanel();
#endif
#endif
#ifdef USE_STDWIN
extern void initstdwin();
#endif
#ifdef USE_SOCKET
extern void initsocket();
#endif
#ifdef USE_JPEG
extern void initjpeg();
#endif

struct {
	char *name;
	void (*initfunc)();
} inittab[] = {

	/* Standard modules */

	{"time",	inittime},
	{"math",	initmath},
	{"regex",	initregex},
	{"posix",	initposix},
	{"pwd",		initpwd},
	{"grp",		initgrp},
	{"marshal",	initmarshal},


	/* Optional modules */

#ifdef USE_AUDIO
	{"audio",	initaudio},
#endif

#ifdef USE_AL
	{"al",		inital},
#endif

#ifdef USE_AMOEBA
	{"amoeba",	initamoeba},
#endif

#ifdef USE_GL
	{"gl",		initgl},
#ifdef USE_FM
	{"fm",		initfm},
#ifdef USE_FL
	{"fl",		initfl},
#endif
#endif
#ifdef USE_PANEL
	{"pnl",		initpanel},
#endif
#endif

#ifdef USE_STDWIN
	{"stdwin",	initstdwin},
#endif

#ifdef USE_SOCKET
	{"socket",	initsocket},
#endif

#ifdef USE_JPEG
	{"jpeg",	initjpeg},
#endif

	{0,		0}		/* Sentinel */
};
