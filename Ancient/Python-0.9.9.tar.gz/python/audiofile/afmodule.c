/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* AudioFile client interface */

#include "allobjects.h"
#include "modsupport.h"
#include "structmember.h"

#include <AF/AFlib.h>
#include <AF/AFUtils.h>

static object *AFError;		/* Exception raised for af-specific errors */


/* Device Descriptor object */

typedef struct {
	OB_HEAD
	AFDeviceDescriptor *d_dev;
	object *d_ref;
} devobject;

extern typeobject Devtype;	/* Really static, forward */

#define is_devobject(dp)	((dp)->ob_type == &Devtype)

static devobject *
newdevobject(ref, dev)
	object *ref;
	AFDeviceDescriptor *dev;
{
	devobject *dp;
	dp = NEWOBJ(devobject, &Devtype);
	if (dp == NULL)
		return NULL;
	dp->d_dev = dev;
	XINCREF(ref);
	dp->d_ref = ref;
	return dp;
}

static void
dev_dealloc(dp)
	devobject *dp;
{
	dp->d_dev = NULL;
	XDECREF(dp->d_ref);
	dp->d_ref = NULL;
	DEL(dp);
}

#define OFF(x) offsetof(AFDeviceDescriptor, x)

static struct memberlist dev_memberlist[] = {
	{"type",		T_INT,	OFF(type),		RO},
	{"numberOfInputs",	T_INT,	OFF(numberOfInputs),	RO},
	{"numberOfOutputs",	T_INT,	OFF(numberOfOutputs),	RO},
	{"inputsFromPhone",	T_INT,	OFF(inputsFromPhone),	RO},
	{"outputsToPhone",	T_INT,	OFF(outputsToPhone),	RO},
	{"playSampleFreq",	T_INT,	OFF(playSampleFreq),	RO},
	{"playBufType",		T_INT,	OFF(playBufType),	RO},
 	{"playNchannels",	T_INT,	OFF(playNchannels),	RO},
	{"playNSamplesBuf",	T_INT,	OFF(playNSamplesBuf),	RO},
	{"recSampleFreq",	T_INT,	OFF(recSampleFreq),	RO},
	{"recNchannels",	T_INT,	OFF(recNchannels),	RO},
	{"recBufType",		T_INT,	OFF(recBufType),	RO},
	{"recNSamplesBuf",	T_INT,	OFF(recNSamplesBuf),	RO},
	{NULL} /* Sentinel */
};

#undef OFF

static object *
dev_getattr(dp, name)
	devobject *dp;
	char *name;
{
	return getmember((char *)dp->d_dev, dev_memberlist, name);
}

static typeobject Devtype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"audio device descriptor",	/*tp_name*/
	sizeof(devobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	dev_dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	dev_getattr,		/*tp_getattr*/
	0,			/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
};


/* Error handler administration */

/* To use this, call conn.geterror() after each operation.
   If you miss an error, it will be printed and ignored. */

static AFErrorEvent lasterrorevent;

static int
myErrorHandler(conn, event)
	AFAudioConn *conn;
	AFErrorEvent *event;
{
	if (lasterrorevent.audioconn != NULL)
		_APrintDefaultError(lasterrorevent.audioconn, event, stderr);
	lasterrorevent = *event;
}


/* Audio Context object */

typedef struct {
	OB_HEAD
	AC a_ac;
	object *a_ref;
} acobject;

extern typeobject Actype;	/* Really static, forward */

#define is_acobject(ap)		((ap)->ob_type == &Actype)

static acobject *
newacobject(ref)
	object *ref;
{
	acobject *ap;
	ap = NEWOBJ(acobject, &Actype);
	if (ap == NULL)
		return NULL;
	ap->a_ac = NULL;
	XINCREF(ref);
	ap->a_ref = ref;
	return ap;
}

static void
ac_dealloc(ap)
	acobject *ap;
{
	if (ap->a_ac)
		AFFreeAC(ap->a_ac);
	ap->a_ac = NULL;
	XDECREF(ap->a_ref);
	ap->a_ref = NULL;
	DEL(ap);
}

static object *
ac_close(ap, args)
	acobject *ap;
	object *args;
{
	if (!getnoarg(args))
		return NULL;
	if (ap->a_ac)
		AFFreeAC(ap->a_ac);
	ap->a_ac = NULL;
	XDECREF(ap->a_ref);
	ap->a_ref = NULL;
	INCREF(None);
	return None;
}

static object *
ac_enable_disable(ap, args, func)
	acobject *ap;
	object *args;
	void (*func)();
{
	AMask mask;
	AMask old_state, new_state;
	if (!getargs(args, "i", &mask))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	func(ap->a_ac, mask, &old_state, &new_state);
	return mkvalue("(ii)", old_state, new_state);
}

static object *
ac_DialPhone(ap, args)
	acobject *ap;
	object *args;
{
	char *dialstring;
	if (!getargs(args, "s", &dialstring))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	return newintobject(AFDialPhone(ap->a_ac, dialstring));
}

static object *
ac_DisableInput(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFDisableInput);
}

static object *
ac_DisableOutput(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFDisableOutput);
}

static object *
ac_DisablePassThrough(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFDisablePassThrough);
}

static object *
ac_EnableInput(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFEnableInput);
}

static object *
ac_EnableOutput(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFEnableOutput);
}

static object *
ac_EnablePassThrough(ap, args)
	acobject *ap;
	object *args;
{
	return ac_enable_disable(ap, args, &AFEnablePassThrough);
}

static object *
ac_FlashHook(ap, args)
	acobject *ap;
	object *args;
{
	int duration;
	if (!getargs(args, "i", &duration))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	AFFlashHook(ap->a_ac, duration);
	INCREF(None);
	return None;
}

static object *
ac_HookSwitch(ap, args)
	acobject *ap;
	object *args;
{
	int onoff;
	if (!getargs(args, "i", &onoff))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	AFHookSwitch(ap->a_ac, onoff);
	INCREF(None);
	return None;
}

static object *
ac_GetTime(ap, args)
	acobject *ap;
	object *args;
{
	ATime time;
	if (!getnoarg(args))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	time = AFGetTime(ap->a_ac);
	return newintobject(time);
}

static object *
ac_PlaySamples(ap, args)
	acobject *ap;
	object *args;
{
	ATime time;
	int nbytes;
	unsigned char *buf;
	if (!getargs(args, "(is#)", &time, &buf, &nbytes))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	time = AFPlaySamples(ap->a_ac, time, nbytes, buf);
	return newintobject(time);
}

static object *
ac_query(ap, args, func)
	acobject *ap;
	object *args;
	int (*func)();
{
	int min, value, max;
	if (!getnoarg(args))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	value = func(ap->a_ac, &min, &max);
	return mkvalue("(iii)", min, value, max);
}

static object *
ac_QueryInputGain(ap, args)
	acobject *ap;
	object *args;
{
	return ac_query(ap, args, AFQueryInputGain);
}

static object *
ac_QueryOutputGain(ap, args)
	acobject *ap;
	object *args;
{
	return ac_query(ap, args, AFQueryOutputGain);
}

static object *
ac_RecordSamples(ap, args)
	acobject *ap;
	object *args;
{
	ATime time, newtime;
	int nbytes;
	int block;
	object *buf;
	object *res;
	if (!getargs(args, "(iii)", &time, &nbytes, &block))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	if ((buf = newsizedstringobject((char *)NULL, nbytes)) == NULL)
		return NULL;
	newtime = AFRecordSamples(ap->a_ac, time, nbytes,
				  getstringvalue(buf), block);
	/* XXX if (!block) should calculate real buffer size! */
	res = mkvalue("(iS)", time, buf);
	DECREF(buf);
	return res;
}

static object *
ac_SelectEvents(ap, args)
	acobject *ap;
	object *args;
{
	long mask;
	if (!getargs(args, "l", &mask))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	AFSelectEvents(ap->a_ac, mask);
	INCREF(None);
	return None;
}	

static object *
ac_SetInputGain(ap, args)
	acobject *ap;
	object *args;
{
	int gain;
	if (!getargs(args, "i", &gain))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	AFSetInputGain(ap->a_ac, gain);
	INCREF(None);
	return None;
}	

static object *
ac_SetOutputGain(ap, args)
	acobject *ap;
	object *args;
{
	int gain;
	if (!getargs(args, "i", &gain))
		return NULL;
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	AFSetOutputGain(ap->a_ac, gain);
	INCREF(None);
	return None;
}	

static struct methodlist ac_methods[] = {
	{"close",		ac_close},
	{"FreeAC",		ac_close},
	{"DialPhone",		ac_DialPhone},
	{"DisableInput",	ac_DisableInput},
	{"DisableOutput",	ac_DisableOutput},
	{"DisablePassThrough",	ac_DisablePassThrough},
	{"EnableInput",		ac_EnableInput},
	{"EnableOutput",	ac_EnableOutput},
	{"EnablePassThrough",	ac_EnablePassThrough},
	{"FlashHook",		ac_FlashHook},
	{"HookSwitch",		ac_HookSwitch},
	{"GetTime",		ac_GetTime},
	{"PlaySamples",		ac_PlaySamples},
	{"QueryInputGain",	ac_QueryInputGain},
	{"QueryOutputGain",	ac_QueryOutputGain},
	{"RecordSamples",	ac_RecordSamples},
	{"SelectEvents",	ac_SelectEvents},
	{"SetInputGain",	ac_SetInputGain},
	{"SetOutputGain",	ac_SetOutputGain},
	{NULL,			NULL}		/* sentinel */
};

static object *
ac_getattr(ap, name)
	acobject *ap;
	char *name;
{
	if (!ap->a_ac) {
		err_setstr(AFError, "closed AC object");
		return NULL;
	}
	if (strcmp(name, "device") == 0) {
		return (object *)newdevobject((object *)ap, ap->a_ac->device);
	}
	if (strcmp(name, "connection") == 0) {
		INCREF(ap->a_ref);
		return ap->a_ref;
	}
	return findmethod(ac_methods, (object *)ap, name);
}

static typeobject Actype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"audio context",	/*tp_name*/
	sizeof(acobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	ac_dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	ac_getattr,		/*tp_getattr*/
	0,			/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
};


/* Connection object */

typedef struct {
	OB_HEAD
	AFAudioConn *c_conn;
} connobject;

extern typeobject Conntype;	/* Really static, forward */

#define is_connobject(cp)	((cp)->ob_type == &Conntype)

static connobject *
newconnobject()
{
	connobject *cp;
	cp = NEWOBJ(connobject, &Conntype);
	if (cp == NULL)
		return NULL;
	cp->c_conn = NULL;
	return cp;
}

static void
conn_dealloc(cp)
	connobject *cp;
{
	if (cp->c_conn)
		AFCloseAudioConn(cp->c_conn);
	cp->c_conn = NULL;
	DEL(cp);
}

static object *
conn_close(cp, args)
	connobject *cp;
	object *args;
{
	if (!getnoarg(args))
		return NULL;
	if (cp->c_conn)
		AFCloseAudioConn(cp->c_conn);
	cp->c_conn = NULL;
	INCREF(None);
	return None;
}

static object *
conn_device(cp, args)
	connobject *cp;
	object *args;
{
	int i;
	devobject *dp;
	if (!getargs(args, "i", &i))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	if (i < 0 || i >= ANumberOfAudioDevices(cp->c_conn)) {
		err_setstr(AFError, "device number out of range");
		return NULL;
	}
	return (object *)newdevobject((object *)cp,
				      AAudioDeviceDescriptor(cp->c_conn, i));
}

static object *
conn_CreateAC(cp, args)
	connobject *cp;
	object *args;
{
	int device;
	acobject *ap;
	if (!getargs(args, "i", &device))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	if ((ap = newacobject((object *)cp)) == NULL)
		return NULL;
	if ((ap->a_ac = AFCreateAC(cp->c_conn, device, 0L, NULL)) == NULL) {
		DECREF(ap);
		err_setstr(AFError, "can't create audio context");
		return NULL;
	}
	return (object *)ap;
}

static object *
conn_CreatePhoneAC(cp, args)
	connobject *cp;
	object *args;
{
	acobject *ap;
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	if ((ap = newacobject((object *)cp)) == NULL)
		return NULL;
	if ((ap->a_ac = AFCreatePhoneAC(cp->c_conn, 0L, NULL)) == NULL) {
		DECREF(ap);
		err_setstr(AFError, "can't create audio context");
		return NULL;
	}
	return (object *)ap;
}

static object *
conn_Flush(cp, args)
	connobject *cp;
	object *args;
{
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	AFFlush(cp->c_conn);
	INCREF(None);
	return None;
}

static object *
conn_Sync(cp, args)
	connobject *cp;
	object *args;
{
	ABool discard;
	if (!getargs(args, "i", &discard))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	AFSync(cp->c_conn, discard);
	INCREF(None);
	return None;
}

static object *
conn_EventsQueued(cp, args)
	connobject *cp;
	object *args;
{
	int mode;
	long queued;
	if (!getargs(args, "i", &mode))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	queued = AFEventsQueued(cp->c_conn, mode);
	return newintobject(queued);
}

static object *
conn_Pending(cp, args)
	connobject *cp;
	object *args;
{
	long pending;
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	pending = AFPending(cp->c_conn);
	return newintobject(pending);
}

static object *
conn_NextEvent(cp, args)
	connobject *cp;
	object *args;
{
	AFEvent event;
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	AFNextEvent(cp->c_conn, &event);
	return newintobject((long)event.type); /* XXX For now */
}

static object *
conn_NoOp(cp, args)
	connobject *cp;
	object *args;
{
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	AFNoOp(cp->c_conn);
	INCREF(None);
	return None;
}

static object *
conn_geterror(cp, args)
	connobject *cp;
	object *args;
{
	object *res;
	if (!getnoarg(args))
		return NULL;
	if (!cp->c_conn) {
		err_setstr(AFError, "closed connection object");
		return NULL;
	}
	if (lasterrorevent.audioconn != cp->c_conn) {
		AFSync(cp->c_conn, AFalse);
	}
	if (lasterrorevent.audioconn != cp->c_conn) {
		INCREF(None);
		return None;
	}
	res = mkvalue("(iiiii)",
		      lasterrorevent.resourceid,
		      lasterrorevent.serial,
		      lasterrorevent.error_code,
		      lasterrorevent.request_code,
		      lasterrorevent.minor_code);
	lasterrorevent.audioconn = NULL;
	return res;
}

static struct methodlist conn_methods[] = {
	{"close",		conn_close},
	{"device",		conn_device},
	{"geterror",		conn_geterror},
	{"AudioDeviceDescriptor", conn_device},
	{"CloseAudioConn",	conn_close},
	{"CreateAC",		conn_CreateAC},
	{"CreatePhoneAC",	conn_CreatePhoneAC},
	{"Flush",		conn_Flush},
	{"Sync",		conn_Sync},
	{"EventsQueued",	conn_EventsQueued},
	{"Pending",		conn_Pending},
	{"NextEvent",		conn_NextEvent},
	{"NoOp",		conn_NoOp},
	{NULL,			NULL}		/* sentinel */
};

#define OFF(x) offsetof(AFAudioConn, x)

static struct memberlist conn_memberlist[] = {
	{"fd",			T_INT,		OFF(fd),		RO},
	{"lock",		T_INT,		OFF(lock),		RO},
	{"proto_major_version",	T_INT,		OFF(proto_major_version), RO},
	{"proto_minor_version",	T_INT,		OFF(proto_minor_version), RO},
	{"vendor",		T_STRING,	OFF(vendor),		RO},
        {"resource_base",	T_LONG,		OFF(resource_base),	RO},
	{"resource_mask",	T_LONG,		OFF(resource_mask),	RO},
	{"resource_id",		T_LONG,		OFF(resource_id),	RO},
	{"resource_shift",	T_INT,		OFF(resource_shift),	RO},
	{"vnumber",		T_INT,		OFF(vnumber),		RO},
	{"release",		T_INT,		OFF(release),		RO},
	{"qlen",		T_INT,		OFF(qlen),		RO},
	{"last_request_read",	T_ULONG,	OFF(last_request_read),	RO},
	{"request",		T_ULONG,	OFF(request),		RO},
	{"max_request_size",	T_UINT,		OFF(max_request_size),	RO},
	{"audioconn_name",	T_STRING,	OFF(audioconn_name),	RO},
	{"ndevices",		T_INT,		OFF(ndevices),		RO},
	{"flags",		T_ULONG,	OFF(flags),		RO},
	{NULL} /* Sentinel */
};

#undef OFF

static object *
conn_getattr(cp, name)
	connobject *cp;
	char *name;
{
	object *v;
	v = findmethod(conn_methods, (object *)cp, name);
	if (v == NULL) {
		err_clear();
		v = getmember((char *)cp->c_conn, conn_memberlist, name);
	}
	return v;
}

static typeobject Conntype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"audio connection",	/*tp_name*/
	sizeof(connobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	conn_dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	conn_getattr,		/*tp_getattr*/
	0,			/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
};


/* Functions in the af module */

static object *
af_OpenAudioConn(self, args)
	object *self;
	object *args;
{
	char *server;
	connobject *cp;
	AFAudioConn *conn;
	if (args == NULL)
		server = NULL;
	else if (!getargs(args, "z", &server))
		return NULL;
	if ((cp = newconnobject()) == NULL)
		return NULL;
	if ((conn = AFOpenAudioConn(server)) == NULL) {
		DECREF(cp);
		err_setstr(AFError, "can't open audio connection");
		return NULL;
	}
	cp->c_conn = conn;
	return (object *)cp;
}

extern char *AFAudioConnName PROTO((char *));

static object *
af_AudioConnName(self, args)
	object *self;
	object *args;
{
	char *server;
	if (args == NULL)
		server = NULL;
	else if (!getargs(args, "z", &server))
		return NULL;
	return newstringobject(AFAudioConnName(server));
}

static struct methodlist af_methods[] = {
	{"OpenAudioConn",	af_OpenAudioConn},
	{"AudioConnName",	af_AudioConnName},
	{NULL,			NULL}		/* sentinel */
};

void
initaf()
{
	object *m, *d;
	m = initmodule("af", af_methods);
	d = getmoduledict(m);
	AFError = newstringobject("af.error");
	dictinsert(d, "error", AFError);
	if (err_occurred())
		fatal("can't initialize module af");
	AFSetErrorHandler(&myErrorHandler);
}
