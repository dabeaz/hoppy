# Show audio server status (mimics output of "aset [-b] q")

import sys
import string
import af

def main():
	brief = ('-b' in sys.argv)
	conn = af.OpenAudioConn()
	if not brief:
		print 'Server '+ conn.audioconn_name + ', device summary:'
		print
		print \
	'        Connections   To                             Gain       Pass'
		print \
	'          #  State   Phone  Type  Rate #Chan    Min  Cur  Max   thru'
	 	print \
	'         ------------------------------------------------------------'
	for i in range(conn.ndevices):
		ac = conn.CreateAC(i)
		dev = ac.device
		# Recording side
		rmin, rgain, rmax = ac.QueryInputGain()
		oldinputs, inputs = ac.EnableInput(0)
		oldpassthrough, passthrough = ac.EnablePassThrough(0)
		rtype = enc_name(dev.recBufType)
		print rj(i, 2), '  In:', rj(dev.numberOfInputs, 2),
		print ' ', lj(mask(inputs, dev.numberOfInputs), 7),
		print rj(dev.inputsFromPhone, 2), rj(rtype, 7),
		print rj(dev.recSampleFreq, 5), rj(dev.recNchannels, 4),
		print ' ', rj(rmin, 4), rj(rgain, 4), rj(rmax, 4),
		if passthrough: print '   on',
		else: print '   off',
		print
		# Playback side
		pmin, pgain, pmax = ac.QueryOutputGain()
		oldoutputs, outputs = ac.EnableOutput(0)
		ptype = enc_name(dev.playBufType)
		print '    Out:', rj(dev.numberOfOutputs, 2),
		print ' ', lj(mask(outputs, dev.numberOfOutputs), 7),
		print rj(dev.outputsToPhone, 2), rj(ptype, 7),
		print rj(dev.playSampleFreq, 5), rj(dev.playNchannels, 4),
		print ' ', rj(pmin, 4), rj(pgain, 4), rj(pmax, 4),
		print
		#
		if not brief: print
		#
		ac.close()

def mask(x, n):
	s = ''
	for i in range(n):
		if x & (1<<i): s = s + '*'
		else: s = s + '-'
	return '(' + s + ')'

def enc_name(type):
	if 0 <= type < len(encoding_names):
		return encoding_names[type]
	else:
		return '?'

encoding_names = [ \
	  'MU255', \
	  'ALAW', \
	  'LIN16', \
	  'LIN32', \
	  'G721', \
	  'G723', \
	  '?', \
	  'IMA', \
	  'CRLADPCM2', \
	  'CRLADPCM3', \
	  'CRLADPCM4', \
	  'LPC10', \
	  'CELP1016', \
	  'IEEES', \
	  'IEEED', \
	  'G722', \
	  'MPEG', \
	]

def lj(s, n):
	return string.ljust(str(s), n)

def rj(s, n):
	return string.rjust(str(s), n)

main()
