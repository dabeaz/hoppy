import VFile
import sys
import time
import gl, GL, DEVICE
import onebit

BLOCKSIZE = 8*1024
#BLOCKSIZE = 7
TMPNAME = '/usr/tmp/@rawv'
#TMPNAME = '@rawv'

def main():
	process(sys.argv[1])

def process(filename):
##	print 'Copying', filename, 'to', TMPNAME
	print 'Warming the cache'
	vin = VFile.VinFile().init(filename)
	vin.warmcache()
##	f = open(TMPNAME, 'w')
##	pointers = []
##	while 1:
##		try:
##			t, data, cdata = vin.getnextframe()
##		except EOFError:
##			break
##		if not cdata: cdata = ''
##		pointers.append(f.tell(), len(data), len(cdata))
##		f.write(data)
##		if cdata: f.write(cdata)
##		f.seek(roundup(f.tell(), BLOCKSIZE))
##	f.close()

	print 'Opening the window'
	gl.foreground()
	gl.prefsize(vin.width, vin.height)
	wid = gl.winopen(filename)
	vin.initcolormap()
	gl.qdevice(DEVICE.ESCKEY)

	print 'Displaying -- type ^C to stop'
	while 1:

		# Now play the movie from the raw disk
##		f = open(TMPNAME, 'r')
		vin.rewind()
		n = 0
		t0 = time.millitimer()
		while 1:
##		for offset, size, csize in pointers:
##			f.seek(offset)
##			data = f.read(size)
##			if csize: cdata = f.read(csize)
##			else: cdata = ''
			try:
				t, data, cdata = vin.getnextframe()
			except EOFError:
				break
			data = onebit.dither(data, vin.width)
			vin.showframe(data, cdata)
			n = n+1
			if gl.qtest():
				if gl.qread()[0] == DEVICE.ESCKEY:
					sys.exit(0)
		t1 = time.millitimer()
##		f.close()

		# Print statistics
		print n, 'frames in', t1-t0, 'msec',
		print int(n*10000.0/(t1-t0))*0.1, 'fr/sec'


def roundup(x, r):
	return ((x + r - 1) / r) * r

try:
	main()
except KeyboardInterrupt:
	pass
