#! /ufs/guido/bin/sgi/python

import sv, SV
import gl, GL, DEVICE
from time import sleep

def main():
	gl.foreground()
	win = gl.winopen('bug')
	x, y = gl.getsize()

	v = sv.OpenVideo()
	v.SetSize(x, y)
	v.BindGLWindow(win, SV.IN_REPLACE)

	sleep(3)

	v.BindGLWindow(win, SV.IN_OFF)
##	v.SetSize(0, 0)

	w, h, full = v.CaptureOneFrame(SV.RGB32_FRAMES, \
		0, 0)


main()
