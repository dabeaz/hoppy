import VFile
import sys
import time
import gl, GL, DEVICE

BLOCKSIZE = 8*1024
#BLOCKSIZE = 7
TMPNAME = '/tmp/@rawv'
#TMPNAME = '@rawv'

def main():
	process(sys.argv[1])

def process(filename):
	print 'Copying', filename, 'to', TMPNAME
	vin = VFile.VinFile().init(filename)
	print 'packfactor =', vin.packfactor
	f = open(TMPNAME, 'w')
	pointers = []
	while 1:
		try:
			t, data, cdata = vin.getnextframe()
		except EOFError:
			break
		if not cdata: cdata = ''
		pointers.append(f.tell(), len(data), len(cdata))
		f.write(data)
		if cdata: f.write(cdata)
		f.seek(roundup(f.tell(), BLOCKSIZE))
	f.close()

	print 'Opening the window'
	gl.foreground()
	gl.prefsize(vin.width, vin.height)
	wid = gl.winopen(filename + ' via ' + TMPNAME)
	vin.initcolormap()
	gl.qdevice(DEVICE.ESCKEY)

	print 'Displaying -- type ^C to stop'
	while 1:

		# Now play the movie from the raw disk
		f = open(TMPNAME, 'r')
		i = 0
		t0 = time.millitimer()
		for offset, size, csize in pointers:
			f.seek(offset)
			data = f.read(size)
			if csize: cdata = f.read(csize)
			else: cdata = ''
			vin.showframe(data, cdata)
			i = i+1
			if i%5 == 0 and gl.qtest():
				if gl.qread()[0] == DEVICE.ESCKEY:
					sys.exit(0)
		t1 = time.millitimer()
		f.close()

		# Print statistics
		n = len(pointers)
		print n, 'frames in', t1-t0, 'msec',
		print int(n*10000.0/(t1-t0))*0.1, 'fr/sec'


def roundup(x, r):
	return ((x + r - 1) / r) * r

try:
	main()
except KeyboardInterrupt:
	pass
