#!/ufs/guido/bin/sgi/python

# display video with a delay that increases for higher scan lines

import sys
import time
import struct
import string
import gl, GL, DEVICE
sys.path.append('/ufs/guido/src/video')
import LiveVideoIn
import LiveVideoOut
import SV
import getopt


DEFWIDTH = 400
DEFHEIGHT = 300
DEFNBANDS = 24


def main():
	sys.stdout = sys.stderr

	width = DEFWIDTH
	height = DEFHEIGHT
	nbands = DEFNBANDS

	try:
		opts, args = getopt.getopt(sys.argv[1:], 'w:h:n:')
	except getopt.error, msg:
		usage(msg)

	try:
		for opt, optarg in opts:
			if opt == '-n':
				nbands = string.atoi(optarg)
			if opt == '-w':
				width = string.atoi(optarg)
			if opt == '-h':
				height = string.atoi(optarg)
	except string.atoi_error, msg:
		usage('bad integer: ' + msg)

	if not LiveVideoIn.have_video:
		print 'Sorry, no video available'
		sys.exit(1)

	gl.foreground()
	gl.prefsize(width, height)
	gl.stepunit(8, 6)
	wid = gl.winopen('whoops')
	gl.keepaspect(width, height)
	gl.stepunit(8, 6)
	gl.maxsize(SV.PAL_XMAX, SV.PAL_YMAX)
	gl.winconstraints()
	gl.qdevice(DEVICE.ESCKEY)
	gl.qdevice(DEVICE.WINSHUT)
	gl.qdevice(DEVICE.WINQUIT)
	width, height = gl.getsize()

	lvo = LiveVideoOut.LiveVideoOut().init(wid, width, height)

	lpp = height/nbands
	lvi = LiveVideoIn.LiveVideoIn().init(width*lpp, width, height)

	queues = [None] * height

	while 1:

		if gl.qtest():
			dev, val = gl.qread()
			if dev in (DEVICE.ESCKEY, \
				DEVICE.WINSHUT, DEVICE.WINQUIT):
				break
			if dev == DEVICE.REDRAW:
				w, h = gl.getsize()
				x, y = gl.getorigin()
				if (w, h) <> (width, height):
					width, height = w, h
					lpp = height/nbands
					lvi.close()
					lvi = LiveVideoIn.LiveVideoIn().init( \
						width*lpp, width, height)
					lvo.resizevideo(width, height)
					queues = [None] * height

		rv = lvi.getnextpacket()
		if not rv:
			time.millisleep(10)
			continue

		pos, data = rv
		q = queues[pos]
		if q is None:
			q = []
			queues[pos] = q
		q.append(data)
		if len(q) > pos/lpp:
			data = q[0]
			del q[0]
			lvo.putnextpacket(pos, data)
			

	lvi.close()
	lvo.close()


main()
