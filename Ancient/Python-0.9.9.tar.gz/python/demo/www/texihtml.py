#! /ufs/guido/bin/sgi/python
import texi2html
