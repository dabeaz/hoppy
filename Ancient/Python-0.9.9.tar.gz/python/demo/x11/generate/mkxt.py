#! /ufs/guido/bin/sgi/python

# This is the start for a Python interface to any Xt-based toolkit,
# such as the Athena or Motif widgets.  For (almost) each function in
# the Xt library, there's a call to dofunction().  This writes out
# a suitable glue function and saves the name of the function in a
# list.  At the the this list is used to generate the "method lists".
# It is possible to have hand-written functions added to the method
# lists too.
# Passed to dofunction() are the return type, the function name, and
# the types of the arguments the function takes.  If the Python
# equivalent is to be a widget method (as opposed to a function in the
# module xt), the Widget argument representing 'self' must be written
# as '*'.

# To do:
# - add all functions that can be added without much trouble
# - add knowledge about more resource types
# - add app context functions
# - add XtNextEvent etc.
# - allow KeyboardInterrupt to jump out of blocking calls (like XtMainLoop)
# - add direct access to some struct members?
# - (eventually) add full Xlib support?
# - anything else I forgot?

import string
from mktools import *

setfile('Xtgenerated.h')

def makename(name):
	if name[:2] == 'WM':
		return 'wm' + name[2:]
	else:
		return string.lower(name[0]) + name[1:]

initwidgetset('Xt', 'widget', 'wclass', '<X11/%s.h>', makename, 'Xt')

setmoduleprefix()
#dowidget('Core')
dowidget('Composite')
dowidget('Constraint')
dowidget('Shell')
dowidget('OverrideShell', None)
dowidget('WMShell', None)
dowidget('VendorShell', 'Vendor')
dowidget('TopLevelShell', None)
dowidget('TransientShell', None)
dowidget('ApplicationShell', None)
myfunction('Widget', 'XtInitialize', 'String', '?list', 'stringlist')
myfunction('Widget', 'XtCreateApplicationShell',
	   'String', 'WidgetClass', 'argdict')
dofunction('XtInputId', 'XtAddInput',
	   'int', 'void*int', 'cbinputfunc', 'cbinputarg')
dofunction('void', 'XtRemoveInput', 'XtInputId')
dofunction('XtIntervalId', 'XtAddTimeOut',
	   'unsigned long', 'cbtimeoutfunc', 'cbtimeoutarg')
dofunction('void', 'XtRemoveTimeOut', 'XtIntervalId')
dofunction('XtWorkProcId', 'XtAddWorkProc', 'cbworkfunc', 'cbworkarg')
dofunction('void', 'XtRemoveWorkProc', 'XtWorkProcId')
dofunction('void', 'XtMainLoop')
dolist()

setwclassprefix()
myfunction('?list', 'XtGetResourceList', '*')
dolist()

setwidgetprefix()
dofunction('Widget', 'XtParent', '*')
dofunction('void', 'XtManageChild', '*')
dofunction('void', 'XtUnmanageChild', '*')
dofunction('Boolean', 'XtIsManaged', '*')
dofunction('void', 'XtRealizeWidget', '*')
dofunction('void', 'XtUnrealizeWidget', '*')
dofunction('Boolean', 'XtIsRealized', '*')
dofunction('void', 'XtMapWidget', '*')
dofunction('void', 'XtUnmapWidget', '*')
dofunction('void', 'XtSetMappedWhenManaged', '*', 'Boolean')
dofunction('void', 'XtSetSensitive', '*', 'Boolean')
dofunction('Boolean', 'XtIsSensitive', '*')
dofunction('Widget', 'XtCreateWidget',
	   'String', 'WidgetClass', '*', 'argdict')
dofunction('Widget', 'XtCreateManagedWidget',
	   'String', 'WidgetClass', '*', 'argdict')
myfunction('Widget', 'XtCreatePopupShell',
	   'String', 'WidgetClass', '*', 'argdict')
myfunction('void', 'XtDestroyWidget', '*')
dofunction('WidgetClass', 'XtClass', '*')
dofunction('WidgetClass', 'XtSuperclass', '*')
dofunction('Boolean', 'XtIsSubclass', '*', 'WidgetClass')
dofunction('Boolean', 'XtIsComposite', '*')
dofunction('Widget', 'XtNameToWidget', '*', 'String')
dofunction('void', 'XtSetValues', '*', 'argdict')
myfunction('argdict', 'XtGetValues', '*', 'stringlist')
dofunction('void', 'XtAddCallback', '*', 'String', 'cbfunc', 'cbarg')
dofunction('void', 'XtRemoveCallback', '*', 'String', 'cbfunc', 'cbarg')
dofunction('void', 'XtRemoveAllCallbacks', '*', 'String')
dofunction('void', 'XtCallCallbacks', '*', 'String', 'String')
dofunction('Boolean', 'XtHasCallbacks', '*', 'String')
dofunction('void', 'XtAddEventHandler',
	  '*', 'EventMask', 'Boolean', 'cbeventfunc', 'cbeventarg')
dofunction('void', 'XtRemoveEventHandler',
	   '*', 'EventMask', 'Boolean', 'cbeventfunc', 'cbeventarg')
dofunction('void', 'XtAddRawEventHandler',
	  '*', 'EventMask', 'Boolean', 'cbeventfunc', 'cbeventarg')
dofunction('void', 'XtRemoveRawEventHandler',
	   '*', 'EventMask', 'Boolean', 'cbeventfunc', 'cbeventarg')
dofunction('EventMask', 'XtBuildEventMask', '*')
dofunction('void', 'XtPopup', '*', 'XtGrabKind')
dofunction('void', 'XtPopdown', '*')
dofunction('void', 'XtInstallAccelerators', '*', 'Widget')
dofunction('void', 'XtInstallAllAccelerators', '*', 'Widget')
myfunction('object*', 'XtConvert', 'object*', 'String')
myfunction('void', 'XtTranslateCoords', '*', 'Position', 'Position')
myfunction('GC', 'XtGetGC', '*', 'XGCValues#')
myfunction('GC', 'XtCreateGC', '*', 'XGCValues#')
myfunction('char*[]', 'XtListFonts', 'pattern')
myfunction('Font', 'XtLoadQueryFont', 'char*')
dolist()

write('static void\n')
write('makewidgets(d)\n')
write('\tobject *d;\n')
write('{\n')
makewidgets()
write('}\n')
write('\n')
