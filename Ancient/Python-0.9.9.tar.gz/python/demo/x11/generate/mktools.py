# Tools for generating files of C functions.

import sys

# Output functions

Outfp = sys.stdout

def setfile(filename):
	global Outfp
	Outfp = open(filename, 'w')

def write(*args):
	for s in args:
		Outfp.write(s)

def writef(fmt, *args):
	write(fmt % args)

# Stuff for doing various things to types defined in typedefs

from typedefs import *

def declare(type, name):

	s = typedefs[type][DCL]
	if s:
		write('\t', s%name, ';\n')

def check(type, name):
	s = typedefs[type][CHK]
	if not s:
		pass
	elif s[-1] == ';':
		write('\t', s%name, '\n')
	else:
		write('\tif (!', s%name, ') {\n')
		write('\t\tif (!err_occurred())\n')
		write('\t\t\terr_setstr(TypeError, "', name,
			  ' should be ', type, '");\n')
		write('\t\treturn NULL;\n')
		write('\t}\n')

def extract(type, name):
	s = typedefs[type][EXT]
	if '%' in s:
		return s%name
	elif s:
		return s
	else:
		return name

def create(type, name):
	s = typedefs[type][CRE]
	if s:
		return s%name
	else:
		return 'None'

def cleanup(type, name):
	item = typedefs[type]
	if len(item) > CLE:
		s = item[CLE]
		if s:
			write('\t', s, ';\n')

# Stuff to generate wrappers around C functions and add them to method lists

Prefix = None
List = None
Skip = None

def setprefix(prefix, skip):
	global Prefix, List, Skip
	Prefix = prefix
	Skip = skip
	List = []
	write('\n')
	write('/* ', 'Methods for ', Prefix, ' objects */\n')
	write('\n')

def dofunction(returntype, fname, *argtypes):
	pname = fname
	if pname[:len(Skip)] == Skip: pname = pname[len(Skip):]
	if '*' in argtypes:
		otype = Prefix
	else:
		otype = ''
	#
	# -- function heading
	write('static object *\n')
	write(Prefix, '_', pname, '(self, args)\n')
	write('\t', otype, 'object *self;\n')
	write('\tobject *args;\n')
	write('{\n')
	#
	# -- declare result
	if returntype <> 'void':
		write('\t', returntype, ' result;\n')
	#
	# -- declare widget for argdict
	if 'argdict' in argtypes:
		if '*' in argtypes:
			write('\tWidget w = self->ob_widget;\n')
			write('\tWidgetClass wC = XtClass(self->ob_widget);\n')
			wCstate = 1
		else:
			write('\tWidget w;\n')
			write('\tWidgetClass wC;\n')
			wCstate = -1
	else:
		wCstate = 0
	#
	# -- declare arguments, collect argument info
	arglist = []
	fmtlist = ''
	nextarg = 1
	for argtype in argtypes:
		if argtype == '*':
			argname = 'self'
		elif argtype == '0':
			argname = '0'
		else:
			argname = 'arg%d' % nextarg
			nextarg = nextarg + 1
		declare(argtype, argname)
		fmtlist = fmtlist + typedefs[argtype][FMT]
		arglist.append(argtype, argname)
	#
	# -- extract arguments, return if failure
	if len(fmtlist) > 1:
		fmtlist = '(%s)' % fmtlist
	write('\tif (!getargs(args, "', fmtlist, '"')
	for argtype, argname in arglist:
		if argname not in ('0', 'self'):
			write(',\n')
			write('\t\t\t&', argname)
	write('))\n')
	write('\t\treturn NULL;\n')
	#
	# -- check structure arguments, return if failure
	for argtype, argname in arglist:
		check(argtype, argname)
		if wCstate == -1:
			if argtype == 'Widget':
				write('\tw = getwidgetvalue(', argname, ');\n')
				write('\twC = XtClass(w);\n')
				wCstate = 1
			elif argtype == 'WidgetClass':
				write('\tw = NULL;\n')
				write('\twC = getwclassvalue(',
					  argname, ');\n')
				wCstate = 1
	#
	# -- call the function, with setjmp handling around
	write('\tif (!setjmp(jump_where)) {\n')
	write('\t\tjump_flag = 1;\n')
	write('\t\t')
	if returntype != 'void':
		write('result = ')
	write(fname, '(')
	sep = ''
	for argtype, argname in arglist:
		if argtype == 'argdict':
			if wCstate != 1:
				raise RuntimeError, \
		  '\'argdict\' must be preceded by Widget or WidgetClass arg'
		write(sep, extract(argtype, argname))
		sep = ',\n\t\t\t'
	write(');\n')
	write('\t\tjump_flag = 0;\n')
	write('\t}\n')
	#
	# -- clean up afterwards
	for argtype, argname in arglist:
		cleanup(argtype, argname)
	#
	# -- error return if long-jumped
	write('\tif (jump_flag) { jump_flag = 0; return NULL; }\n')
	#
	# -- return result
	if returntype == 'void':
		write('\tINCREF(None);\n')
	write('\treturn ', create(returntype, 'result'), ';\n')
	#
	# -- end of function body
	write('}\n')
	write('\n')
	#
	# -- administration
	List.append(pname)

def myfunction(returntype_unused, fname, *args_unused):
	pname = fname
	if pname[:len(Skip)] == Skip: pname = pname[len(Skip):]
	List.append(pname)

def dolist():
	write('struct methodlist ', Prefix, '_methods[] = {\n')
	for pname in List:
		writef('\t{"%s", %s_%s},\n', pname, Prefix, pname)
	write('\t{0, 0} /* Sentinel */\n')
	write('};\n')
	write('\n')

# Stuff to generate complete widget set modules (e.g. Xm, Xaw)

Widgets = None
Mname, Wname, Cname, Includef, Classnamef, Mskip = \
	  None, None, None, None, None, None

def initwidgetset(mname, wname, cname, includef, classnamef, mskip):
	global Mname, Wname, Cname, Includef, Classnamef, Widgets, Mskip
	Mname, Wname, Cname, Includef, Classnamef, Mskip = \
		  mname, wname, cname, includef, classnamef, mskip
	Widgets = []

def widgetset(mname, wname, cname, includef, classnamef, mskip):
	initwidgetset(mname, wname, cname, includef, classnamef, mskip)
	setfile(Mname + 'module.c')
	write('/* Widget Set ', Mname, ' */\n')
	write('\n')
	write('#include "allobjects.h"\n')
	write('#include "modsupport.h"\n')
	write('#include "widgetobject.h"\n')
	write('\n')

def setmoduleprefix():
	setprefix(Mname, Mskip)

def setwidgetprefix():
	setprefix(Wname, Mskip)

def setwclassprefix():
	setprefix(Cname, Mskip)

def dowidget(name, *args):
	if len(args) > 1: raise TypeError, 'too many args'
	if len(args) == 1: fname = args[0]
	else: fname = name
	if type(Classnamef) == type(''):
		cname = Classnamef % name
	else:
		cname = Classnamef(name)
	cname = cname + 'WidgetClass'
	if fname <> None:
		include = Includef % fname
		write('#include ', include, '\n')
		write('\n')
	Widgets.append(name, cname)

def dogadget(name, fname):
	cname = Classnamef % name + 'GadgetClass'
	include = Includef % fname
	write('#include ', include, '\n')
	write('\n')
	Widgets.append(name + 'Gadget', cname)
	dofunction('Widget', 'XmCreate%sGadget' % name,
		  'Widget', 'String', 'argdict')

initextras = []

def endwidgetset():
	write('\n')
	write('struct methodlist *', Wname, '_methodlists[] = {\n')
	write('\t', Wname, '_methods,\n')
	write('\t0\n')
	write('};\n')
	write('\n')
	write('void\ninit', Mname, '()\n{\n')
	write('\tobject *m, *d;\n')
	write('\tm = initmodule("', Mname, '", ', Mname, '_methods);\n')
	write('\td = getmoduledict(m);\n')
	makewidgets()
	for line in initextras:
		write('\t' + line + '\n');
	write('}\n')

def makewidgets():
	for name, cname in Widgets:
		write('\tdictinsert(d, "', name, '",\n')
		write('\t\t(object*)newwclassobject(', cname, ',\n')
		write('\t\t\twclass_methodlists));\n')
