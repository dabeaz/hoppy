#! /ufs/guido/bin/sgi/python

# XXX Bugs:
# - on assignment to text/headerText/etc resources: the value assigned
#   must remain alive until the next assignment to the same resource
# - HTML.GetText leaks a copy of the text each time it is called

from mktools import *

widgetset('HTML', 'HTMLw', 'HTMLwc',
	  '"/ufs/guido/src/xmosaic/libhtmlw/%s.h"', '%s', 'HTML')

setmoduleprefix()

dowidget('html', 'HTML')

dofunction('char*', 'HTMLGetText', 'Widget', 'int')

myfunction('char*', 'HTMLGetTextAndSelection',
	   'Widget', '>char*', '>char*', '>char*')

myfunction('char**', 'HTMLGetHRefs', 'Widget', '>int')

dofunction('int', 'HTMLPositionToId', 'Widget', 'int', 'int')

myfunction('int', 'HTMLIdToPosition', 'w', 'int', '>int', '>int')

myfunction('int', 'HTMLAnchorToPosition', 'Widget', 'char*', '>int', '>int')

##dofunction('void', 'HTMLRetestAnchors', 'Widget', 'visitTestProc')

dofunction('void', 'HTMLClearSelection', 'Widget')

myfunction('void', 'HTMLSetSelection', 'Widget', 'ElementRef*', 'ElementRef*')

dofunction('void', 'HTMLSetText', 'Widget', 'char*', 'char*', 'char*')

myfunction('int', 'HTMLSearchText', 'Widget', 'char*',
	   '<>ElementRef*', '>ElementRef*', 'int', 'int')

myfunction('tuple(siiss)', 'cbarg', 'char[100]')

write('#include "HTMLmanual.h"\n')

dolist()

setwclassprefix()
dolist()

setwidgetprefix()
dolist()

endwidgetset()
