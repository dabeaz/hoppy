#! /ufs/guido/bin/sgi/python

def drawfn(pname, *argtypes):
	returntype = 'void'
	fname = 'X' + pname
	otype = 'GC'
	#
	# -- function heading
	write('static object *\n')
	write(Prefix, '_', pname, '(self, args)\n')
	write('\t', otype, 'object *self;\n')
	write('\tobject *args;\n')
	write('{\n')
	#
	# -- declare result
	if returntype <> 'void':
		write('\t', returntype, ' result;\n')
	#
	# -- declare arguments, collect argument info
	arglist = []
	fmtlist = ''
	nextarg = 1
	for argtype in argtypes:
		if argtype == '*':
			argname = 'self'
		elif argtype == '0':
			argname = '0'
		else:
			argname = 'arg%d' % nextarg
			nextarg = nextarg + 1
		declare(argtype, argname)
		fmtlist = fmtlist + typedefs[argtype][FMT]
		arglist.append(argtype, argname)
	#
	# -- extract arguments, return if failure
	if len(fmtlist) > 1:
		fmtlist = '(%s)' % fmtlist
	write('\tif (!getargs(args, "', fmtlist, '"')
	for argtype, argname in arglist:
		if argname not in ('0', 'self'):
			write(',\n')
			write('\t\t\t&', argname)
	write('))\n')
	write('\t\treturn NULL;\n')
	#
	# -- check structure arguments, return if failure
	for argtype, argname in arglist:
		check(argtype, argname)
	#
	# -- call the function, with setjmp handling around
	write('\tif (!setjmp(jump_where)) {\n')
	write('\t\tjump_flag = 1;\n')
	write('\t\t')
	if returntype != 'void':
		write('result = ')
	write(fname, '(self->gc_display, self->gc_drawable, self->gc_gc')
	sep = ',\n\t\t\t'
	for argtype, argname in arglist:
		write(sep, extract(argtype, argname))
	write(');\n')
	write('\t\tjump_flag = 0;\n')
	write('\t}\n')
	#
	# -- clean up afterwards
	for argtype, argname in arglist:
		cleanup(argtype, argname)
	#
	# -- error return if long-jumped
	write('\tif (jump_flag) { jump_flag = 0; return NULL; }\n')
	#
	# -- return result
	if returntype == 'void':
		write('\tINCREF(None);\n')
	write('\treturn ', create(returntype, 'result'), ';\n')
	#
	# -- end of function body
	write('}\n')
	write('\n')
	#
	# -- administration
	List.append(pname)

def gcfn(pname, *argtypes):
	returntype = 'void'
	fname = 'X' + pname
	otype = 'GC'
	#
	# -- function heading
	write('static object *\n')
	write(Prefix, '_', pname, '(self, args)\n')
	write('\t', otype, 'object *self;\n')
	write('\tobject *args;\n')
	write('{\n')
	#
	# -- declare result
	if returntype <> 'void':
		write('\t', returntype, ' result;\n')
	#
	# -- declare arguments, collect argument info
	arglist = []
	fmtlist = ''
	nextarg = 1
	for argtype in argtypes:
		if argtype == '*':
			argname = 'self'
		elif argtype == '0':
			argname = '0'
		else:
			argname = 'arg%d' % nextarg
			nextarg = nextarg + 1
		declare(argtype, argname)
		fmtlist = fmtlist + typedefs[argtype][FMT]
		arglist.append(argtype, argname)
	#
	# -- check non-shared object
	write('\tif (self->gc_widget) {\n')
	write('\t\terr_setstr(TypeError, "can\'t modify shared GC");\n')
	write('\t\treturn NULL;\n')
	write('\t}\n')
	#
	# -- extract arguments, return if failure
	if len(fmtlist) > 1:
		fmtlist = '(%s)' % fmtlist
	write('\tif (!getargs(args, "', fmtlist, '"')
	for argtype, argname in arglist:
		if argname not in ('0', 'self'):
			write(',\n')
			write('\t\t\t&', argname)
	write('))\n')
	write('\t\treturn NULL;\n')
	#
	# -- check structure arguments, return if failure
	for argtype, argname in arglist:
		check(argtype, argname)
	#
	# -- call the function, with setjmp handling around
	write('\tif (!setjmp(jump_where)) {\n')
	write('\t\tjump_flag = 1;\n')
	write('\t\t')
	if returntype != 'void':
		write('result = ')
	write(fname, '(self->gc_display, self->gc_gc')
	sep = ',\n\t\t\t'
	for argtype, argname in arglist:
		write(sep, extract(argtype, argname))
	write(');\n')
	write('\t\tjump_flag = 0;\n')
	write('\t}\n')
	#
	# -- clean up afterwards
	for argtype, argname in arglist:
		cleanup(argtype, argname)
	#
	# -- error return if long-jumped
	write('\tif (jump_flag) { jump_flag = 0; return NULL; }\n')
	#
	# -- return result
	if returntype == 'void':
		write('\tINCREF(None);\n')
	write('\treturn ', create(returntype, 'result'), ';\n')
	#
	# -- end of function body
	write('}\n')
	write('\n')
	#
	# -- administration
	List.append(pname)

from mktools import setprefix, setfile
setfile('GCmethods.h')
setprefix('PyGC', 'X')

from mktools import *

drawfn('DrawArc', 'Position', 'Position', 'Dimension', 'Dimension',
       'int', 'int')
drawfn('DrawArcs', 'XArc[]')
drawfn('DrawImageString', 'int', 'int', 'char[]')
drawfn('DrawLine', 'Position', 'Position', 'Position', 'Position')
drawfn('DrawLines', 'XPoint[]', 'int')
drawfn('DrawPoint', 'Position', 'Position')
drawfn('DrawPoints', 'XPoint[]', 'int')
drawfn('DrawRectangle', 'Position', 'Position', 'Dimension', 'Dimension')
drawfn('DrawRectangles', 'XRectangle[]')
drawfn('DrawSegments', 'XSegment[]')
drawfn('DrawString', 'int', 'int', 'char[]')
#drawfn('DrawText', 'int', 'int', 'XTextItem[]')
drawfn('FillArc', 'Position', 'Position', 'Dimension', 'Dimension',
       'int', 'int')
drawfn('FillArcs', 'XArc[]')
drawfn('FillPolygon', 'XPoint[]', 'int', 'int')
drawfn('FillRectangle', 'Position', 'Position', 'Dimension', 'Dimension')
drawfn('FillRectangles', 'XRectangle[]')
# XXX omitted Text16/String16 variants

gcfn('ChangeGC', 'XGCValues#')
gcfn('SetArcMode', 'int')
gcfn('SetBackground', 'unsigned long')
gcfn('SetClipMask', 'Pixmap')
gcfn('SetClipOrigin', 'int', 'int')
gcfn('SetClipRectangles', 'int', 'int', 'XRectangle[]', 'int')
gcfn('SetDashes', 'int', 'char[]')
gcfn('SetFillRule', 'int')
gcfn('SetFillStyle', 'int')
gcfn('SetFont', 'Font')
gcfn('SetForeground', 'unsigned long')
gcfn('SetFunction', 'int')
gcfn('SetGraphicsExposures', 'Bool')
gcfn('SetLineAttributes', 'unsigned int', 'int', 'int', 'int')
gcfn('SetPlaneMask', 'unsigned long')
gcfn('SetState', 'unsigned long', 'unsigned long', 'int', 'unsigned long')
gcfn('SetStipple', 'Pixmap')
gcfn('SetSubwindowMode', 'int')
gcfn('SetTSOrigin', 'int', 'int')
gcfn('SetTile', 'Pixmap')

dolist()
