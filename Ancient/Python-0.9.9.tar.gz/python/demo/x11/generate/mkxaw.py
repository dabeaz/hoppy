#! /ufs/guido/bin/sgi/python

import string
from mktools import *

def makename(name):
	return string.lower(name[0]) + name[1:]

widgetset('Xaw', 'Xaww', 'Xawwc', '<X11/Xaw/%s.h>', makename, 'Xt')

setmoduleprefix()

#dowidget('AsciiSink')
#dowidget('AsciiSrc')
#dowidget('AsciiText')
#dowidget('Scroll')
#dowidget('TextI')
#dowidget('TextSink')
#dowidget('TextSrc')
#dowidget('VPaned')
dowidget('Box')
dowidget('Clock')
dowidget('Command')
dowidget('Dialog')
dowidget('Form')
dowidget('Grip')
dowidget('Label')
dowidget('List')
dowidget('Logo')
dowidget('Mailbox')
dowidget('MenuButton')
dowidget('Paned')
dowidget('Panner')
dowidget('Porthole')
dowidget('Repeater')
dowidget('Scrollbar')
dowidget('Simple')
dowidget('SimpleMenu')
dowidget('StripChart')
dowidget('Text')
dowidget('Toggle')
dowidget('Tree')
dowidget('Viewport')

dolist()

setwclassprefix()
dolist()

setwidgetprefix()
dolist()

endwidgetset()
