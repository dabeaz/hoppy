import sunaudiodev
import audioop

BUFFERSIZE = 8192

Error = 'SunAudioSink.Error'

class SunAudioSink:

	# Private instance variables
	access converter, bytes, fp: private

	def __init__(self, *args):
		if args:
			if args[1:]: raise TypeErrors, 'too many init args'
			self.setsourceparams(args[0])

	def __del__(self):
		self.close()

	def close(self):
		try:
			try:
				self.fp.flush()
				self.fp.close()
			except:
				pass
		finally:
			self.fp = None

	def getfilled(self):
		if self.fp:
			return self.fp.obufcount()
		else:
			return 0

	def getfillable(self):
		if self.fp:
			return BUFFERSIZE - self.fp.obufcount()
		else:
			return BUFFERSIZE

	def reset(self):
		left = self.getfilled()
		self.close()
		return left

	def writeframes(self, data):
		if self.converter:
			data = self.converter(data)
		self.fp.write(data)

	def setsourceparams(self, params):
		fmt, bytes, bits, nch, rate, nfr = params
		if rate <> 8000:
			raise Error, 'only 8000 frames/sec is supported'
		if nch <> 1:
			raise Error, 'only one channel is supported'
		if fmt == 'ulaw':
			self.converter = None
			self.bytes = 0
		elif fmt == 'linear':
			self.converter = self.lin2ulaw
			self.bytes = bytes
		# (Re)open the device
		self.fp = None
		self.fp = sunaudiodev.open('w')

	# Private methods
	access *: private

	def lin2ulaw(self, data):
		return audioop.lin2ulaw(data, self.bytes)
