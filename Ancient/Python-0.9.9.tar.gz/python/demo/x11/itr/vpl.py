#! /ufs/guido/src/python/xt/python
import os
from VideoPlayer import test
sts = os.system('xrdb -merge /ufs/guido/src/python/xt/Vpl.resources')
test()
