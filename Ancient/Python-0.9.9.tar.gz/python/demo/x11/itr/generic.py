# Generic main program for anp, itr and abr
import os
import sys
import string
name = os.path.basename(sys.argv[0])
i = string.find(name, '.')
if i >= 0: name = name[:i]
if name == 'anp':
	import anp
elif name == 'itr':
	import itr
elif name == 'abr':
	import abr
else:
	print 'This file should be called either "itr" or "anp" or "abr"'
	sys.exit(1)
