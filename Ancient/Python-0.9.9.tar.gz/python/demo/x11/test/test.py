import sys
import Xaw
import Xt

def listvalues(w):
	c = w.Class()
	list = c.GetResourceList()
	list.sort()
	dict = {}
	names = []
	for item in list:
		names.append(item[0])
		dict[item[0]] = item
	valuesdict = w.GetValues(names)
	for name in valuesdict.keys():
		cls = dict[name][1]
		type = dict[name][2]
		values = valuesdict[name]
		print '%-19s %-19s %-19s %s' % (name, cls, type, `value`)

def test():
	top = Xt.Initialize('Test', [], sys.argv)
	form = top.CreateManagedWidget('form', Xaw.Form, {})
	logo = form.CreateManagedWidget('logo', Xaw.Logo, {})
	if logo <> top.NameToWidget('form.logo'): print 'Heh?'
#	print '--- top ---'
#	listvalues(top)
	print '--- form ---'
	listvalues(form)
	print '--- logo ---'
	listvalues(logo)

test()
