import sys
import HTML
import Xt
import Xm
import Xmd
import XEvent

def cb_anchor(widget, userdata, calldata):
	print 'anchor callback:', widget, userdata
	rawevent, page, elid, text, href = HTML.cbarg(calldata)
	event = XEvent.mkevent(rawevent)
	print 'event =', event
	print 'page =', page, 'id =', elid
	print 'text =', `text`
	print 'href =', `href`
	print 'pos =', HTML.IdToPosition(widget, elid)

def main():
	top = Xt.Initialize()

	file = '../../www/test.html'
	if sys.argv[1:]: file = sys.argv[1]
	fp = open(file, 'r')
	text = fp.read()
	fp.close()

	sw = Xm.CreateScrolledWindow(top, 'sw',
		  {'scrollingPolicy': Xmd.AUTOMATIC,
		  'width':400, 'height': 300})
	sw.ManageChild()

	h = sw.CreateManagedWidget('h', HTML.html,
		  {'autoSize': 1, 'width': 800})
	h.AddCallback('anchorCallback', cb_anchor, None)
	h.text = text

	top.RealizeWidget()

	Xt.MainLoop()

main()
