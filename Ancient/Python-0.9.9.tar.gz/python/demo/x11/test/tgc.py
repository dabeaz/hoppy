# test GC ops

import sys
import Xt
import Xm
import X

Count = 0
R = [(10,10,10,10), (20,20,20,20), (30,30,30,30)]
Color = 0

def cb_expose(widget, user_data, call_data):
	global Count, Color
	Count = Count + 1
	if Count % 100 == 0:
		print Count, 'expose callbacks'
	g = widget.GetGC({'foreground': Color, 'line_width': 5})
	Color = Color+1
	g.DrawString(10, 50, 'Hello, world')
	g.DrawRectangle(5, 30, 195, 60)
	g.DrawRectangles(R)
	g.DrawSegments(R)
	g = widget.CreateGC({})
	Color = Color+1
	g.ChangeGC({'line_width': 0, 'foreground': Color})
	showgc(g)
	g.line_style = X.LineOnOffDash
	g.SetDashes(0, '\002\010\002\002')
	g.DrawRectangle(5, 30, 195, 60)
	g.DrawSegments(R)
	# Cause another expose...
##	widget.UnmapWidget()
	widget.MapWidget()

def showgc(g):
	attrs = g.__members__
	for attr in attrs:
		try:
			value = getattr(g, attr)
		except TypeError, msg:
			print '%-20s (%s)' % (attr, str(msg))
			continue
		print '%-20s %10d' % (attr, value)

def main():
	t = Xt.Initialize('t', [], sys.argv)
	d = Xm.CreateDrawingArea(t, 'd', {})
	d.SetValues({'background': 'white', 'foreground': 'red',
		     'width': 200, 'height': 200})
	d.AddCallback('exposeCallback', cb_expose, None)
	d.ManageChild()
	t.RealizeWidget()
	Xt.MainLoop()

main()
