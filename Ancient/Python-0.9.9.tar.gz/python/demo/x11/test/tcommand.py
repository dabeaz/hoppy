# test Command widget

import sys
import Xt
import Xm

def main():
	toplevel = Xt.Initialize('tcommand', [], sys.argv)
	command = Xm.CreateCommand(toplevel, 'command', {})
	command.promptString = '%%%'
	command.ManageChild()
	toplevel.RealizeWidget()
	Xm.CommandError(command, 'no command entered yet')
	Xt.MainLoop()

main()
