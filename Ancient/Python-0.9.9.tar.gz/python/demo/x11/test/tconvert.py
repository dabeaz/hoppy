# Test Xt.Convert()

import Xt, Xm
import sys

t = Xt.Initialize('T', [], sys.argv)

for i in -1000, -100, -10, -1, 1, 10, 100, 1000, 10000, 100000, 1000000:
	print i,
	print t.Convert(i, 'Int'),
	print t.Convert(`i`, 'Int'),
	print

trans = '#override \n' + \
	'<Key>Home:		scroll-back(1000,page)\n' + \
	'<Key>End:		scroll-forw(1000,page)\n' + \
	'<Key>Insert:		insert-selection(PRIMARY, CUT_BUFFER0)\n' + \
	'~Meta<Key>Prior:	scroll-back(1,page)\n' + \
	'Meta<Key>Prior:		scroll-back(1,halfpage)\n' + \
	'~Meta<Key>Next:		scroll-forw(1,page)\n' + \
	'Meta<Key>Next:		scroll-forw(1,halfpage)\n' + \
	'Meta<KeyPress>:		string(0x1b) insert-seven-bit()'

#print t.Convert(trans, 'TranslationTable')

t1 = t.Convert(t, 'Widget')
(t is t1)
print t.Convert('abc', 'XmString')
