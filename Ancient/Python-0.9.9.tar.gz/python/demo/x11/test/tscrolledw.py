# test scrolled window

import sys
import Xt
import Xm
import Xmd

def main():
	pixmapname = 'escherknot'
	t = Xt.Initialize()
	if sys.argv[1:]: pixmapname = sys.argv[1]
	#
	args = {}
	args['scrollingPolicy'] = Xmd.AUTOMATIC
	sw = t.CreateManagedWidget('sw', Xm.ScrolledWindow, args)
##	sw = Xm.CreateScrolledWindow(t, 'sw', args)
##	sw.ManageChild()
	#
	args = {}
	document = Xm.CreateLabel(sw, 'document', args)
	document.labelType = Xmd.PIXMAP
	document.labelPixmap = pixmapname
	document.ManageChild()
	#
	t.RealizeWidget()
	Xt.MainLoop()

main()
