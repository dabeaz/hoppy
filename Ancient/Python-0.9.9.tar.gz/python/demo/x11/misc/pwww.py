# Python WWW browser (built out of existing components mostly)

import sys
import HTML
import Xt
import Xm
import Xmd
import XEvent

sys.path.append('/ufs/guido/src/www')
import wwwlib
import wwwutil

def cb_anchor(widget, userdata, calldata):
	global url, text
	rawevent, page, elid, text, href = HTML.cbarg(calldata)
	event = XEvent.mkevent(rawevent)
	newurl = wwwlib.full_addr(url, href)
	print 'Following link to', `newurl`
	try:
		newtext = wwwlib.get_document(newurl)
	except:
		print 'Exception:', sys.exc_type, sys.exc_value
		return
	widget.headerText = newurl
	widget.text = newtext
	widget.footerText = footerText
	url = newurl
	text = newtext
##	fancytext = HTML.GetText(widget, 0)
##	s = `fancytext`
##	if len(s) >= 72:
##		print 'text =', s[:34] + '...' + s[-34:]
##	else:
##		print 'text =', s

def main():
	global url, text, footerText
	top = Xt.Initialize()

	url = wwwutil.user_home
	if sys.argv[1:]:
		url = sys.argv[1]
	footerText = ''
	labels = 'Initial Page', 'User Home Page', 'System Home Page'
	urls = url, wwwutil.user_home, wwwutil.system_home
	for i in range(len(urls)):
		u = urls[i]
		if u not in urls[:i]:
			footerText = footerText + '<P>(<A HREF="' \
				   + urls[i] + '">' \
				   + labels[i] + '</A>)'
	text = wwwlib.get_document(url)

	sw = Xm.CreateScrolledWindow(top, 'sw',
		  {'scrollingPolicy': Xmd.AUTOMATIC,
		  'width':400, 'height': 300})
	sw.ManageChild()

	h = sw.CreateManagedWidget('h', HTML.html,
		  {'autoSize': 1,
		   'fanceSelections': 1,
		   'width': 800,
		  })
	h.AddCallback('anchorCallback', cb_anchor, None)
	h.headerText = url
	h.text = text
	h.footerText = footerText

	top.RealizeWidget()

	Xt.MainLoop()

main()
