import al
import AL
import gsm

def main():
	g1 = gsm.create()
	g2 = gsm.create()
	#
	c = al.newconfig()
	c.setchannels(AL.MONO)
	c.setwidth(AL.SAMPLE_16)
	c.setqueuesize(1024)
	output = al.openport('GSM out', 'w', c)
	input = al.openport('GSM in', 'r', c)
	#
	N = 160
	while 1:
		samples = input.readsamps(N)
		frame = g1.encode(samples)
		newsamples = g2.decode(frame)
		output.writesamps(newsamples)

main()
