emacs -batch -l fix.el -f save-buffer -kill
makeinfo +footnote-style end +fill-column 72 +paragraph-indent 0 @out.texi
