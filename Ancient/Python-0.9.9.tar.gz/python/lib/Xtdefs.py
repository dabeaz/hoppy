XtInputNoneMask = 0
XtInputReadMask = (1<<0)
XtInputWriteMask = (1<<1)
XtInputExceptMask = (1<<2)
