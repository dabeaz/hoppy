#-----------------------------------------------------------------------
# DESCRIPTION:
#     Constant definitions for the Xm module. The definitions have been taken 
#     from the <Xm/Xm.h> file. The constants in that file have been 
#     stripped of their "Xm" prefixes.
#
# NOTE: 
#     Contains only the numerical constants defined in Xm.h. The string
#     constants (resource names) have been left out.
#
# USAGE: > import Xmd
#

# change policy values

CHANGE_ALL             = 0
CHANGE_NONE            = 1
CHANGE_WIDTH           = 2
CHANGE_HEIGHT          = 3

# unit type values 

PIXELS                 = 0
MILLIMETERS            = 1
INCHES                 = 2
POINTS                 = 3
FONT_UNITS             = 4

#-----------------------------------------------------------------------
# Menu defines
#
NO_ORIENTATION         = 0
VERTICAL               = 1
HORIZONTAL             = 2

WORK_AREA              = 0
MENU_BAR               = 1
MENU_PULLDOWN          = 2
MENU_POPUP             = 3
MENU_OPTION            = 4

NO_PACKING             = 0
PACK_TIGHT             = 1
PACK_COLUMN            = 2
PACK_NONE              = 3


#-----------------------------------------------------------------------
# Label defines
#
ALIGNMENT_BEGINNING    = 0
ALIGNMENT_CENTER       = 1
ALIGNMENT_END          = 2


#-----------------------------------------------------------------------
# ToggleButton  defines
#
N_OF_MANY              = 1
ONE_OF_MANY            = 2


#-----------------------------------------------------------------------
# Layout defines:
#
HORIZONTAL             = 2
VERTICAL               = 1

NO_PACKING             = 0
PACK_TIGHT             = 1
PACK_COLUMN            = 2
PACK_NONE              = 3

# Form defines  

ATTACH_NONE            = 0
ATTACH_FORM            = 1
ATTACH_OPPOSITE_FORM   = 2
ATTACH_WIDGET          = 3
ATTACH_OPPOSITE_WIDGET = 4
ATTACH_POSITION        = 5
ATTACH_SELF            = 6

RESIZE_NONE            = 0
RESIZE_GROW            = 1
RESIZE_ANY             = 2      #  for BulletinBoard, DrawingArea  

#-----------------------------------------------------------------------
# Callback reasons:
#
CR_NONE                      = 0
CR_HELP                      = 1
CR_VALUE_CHANGED             = 2
CR_INCREMENT                 = 3
CR_DECREMENT                 = 4
CR_PAGE_INCREMENT            = 5
CR_PAGE_DECREMENT            = 6
CR_TO_TOP                    = 7
CR_TO_BOTTOM                 = 8
CR_DRAG                      = 9
CR_ACTIVATE                  = 10
CR_ARM                       = 11
CR_DISARM                    = 12
CR_MAP                       = 16
CR_UNMAP                     = 17
CR_FOCUS                     = 18
CR_LOSING_FOCUS              = 19
CR_MODIFYING_TEXT_VALUE      = 20
CR_MOVING_INSERT_CURSOR      = 21
CR_EXECUTE                   = 22
CR_SINGLE_SELECT             = 23
CR_MULTIPLE_SELECT           = 24
CR_EXTENDED_SELECT           = 25
CR_BROWSE_SELECT             = 26
CR_DEFAULT_ACTION            = 27
CR_CLIPBOARD_DATA_REQUEST    = 28
CR_CLIPBOARD_DATA_DELETE     = 29
CR_CASCADING                 = 30
CR_OK                        = 31
CR_CANCEL                    = 32
CR_APPLY                     = 34
CR_NO_MATCH                  = 35
CR_COMMAND_ENTERED           = 36
CR_COMMAND_CHANGED           = 37
CR_EXPOSE                    = 38
CR_RESIZE                    = 39
CR_INPUT                     = 40
CR_GAIN_PRIMARY              = 41
CR_LOSE_PRIMARY              = 42
CR_CREATE                    = 43

#-----------------------------------------------------------------------
# DrawnButton defines
#
SHADOW_IN            = 7
SHADOW_OUT           = 8

#-----------------------------------------------------------------------
# Arrow defines
#
ARROW_UP             = 0
ARROW_DOWN           = 1
ARROW_LEFT           = 2
ARROW_RIGHT          = 3

#-----------------------------------------------------------------------
# Separator defines
#
NO_LINE              = 0
SINGLE_LINE          = 1
DOUBLE_LINE          = 2
SINGLE_DASHED_LINE   = 3
DOUBLE_DASHED_LINE   = 4
SHADOW_ETCHED_IN     = 5
SHADOW_ETCHED_OUT    = 6

PIXMAP               = 1
STRING               = 2

#-----------------------------------------------------------------------
# ScrollBar defines
#
MAX_ON_TOP        = 0
MAX_ON_BOTTOM     = 1
MAX_ON_LEFT       = 2
MAX_ON_RIGHT      = 3

#-----------------------------------------------------------------------
# Selection types
#
SINGLE_SELECT     = 0
MULTIPLE_SELECT   = 1
EXTENDED_SELECT   = 2
BROWSE_SELECT     = 3

STATIC            = 0
DYNAMIC           = 1

#-----------------------------------------------------------------------
# Scrolled Window defines.                                             
#                                                                     
VARIABLE             = 0
CONSTANT             = 1
RESIZE_IF_POSSIBLE   = 2
AUTOMATIC            = 0
APPLICATION_DEFINED  = 1
STATIC               = 0     # This is already defined by List 
AS_NEEDED            = 1

SW_TOP               = 1
SW_BOTTOM            = 0
SW_LEFT              = 2
SW_RIGHT             = 0

TOP_LEFT             = (SW_TOP | SW_LEFT)
BOTTOM_LEFT          = (SW_BOTTOM  | SW_LEFT)
TOP_RIGHT            = (SW_TOP | SW_RIGHT)
BOTTOM_RIGHT         = (SW_BOTTOM  | SW_RIGHT)

#-----------------------------------------------------------------------
# Text Widget defines                                                  
#
MULTI_LINE_EDIT              = 0
SINGLE_LINE_EDIT             = 1

#typedef enum { XmSELECT_POSITION, XmSELECT_WHITESPACE, XmSELECT_WORD,
#             XmSELECT_LINE, XmSELECT_ALL, XmSELECT_PARAGRAPH } XmTextScanType;

SELECT_POSITION              = 0
SELECT_WHITESPACE            = 1
SELECT_WORD                  = 2
SELECT_LINE                  = 3
SELECT_ALL                   = 4
SELECT_PARAGRAPH             = 5

#typedef enum {XmHIGHLIGHT_NORMAL, XmHIGHLIGHT_SELECTED,
#              XmHIGHLIGHT_SECONDARY_SELECTED} XmHighlightMode;

HIGHLIGHT_NORMAL             = 0
HIGHLIGHT_SELECTED           = 1
HIGHLIGHT_SECONDARY_SELECTED = 2

#-----------------------------------------------------------------------
# DIALOG defines..  BulletinBoard and things common to its subclasses 
#         CommandBox    MessageBox    Selection    FileSelection      
#                                                                     

# child type defines for Xm...GetChild() 

DIALOG_NONE             = 0       # a valid default button type 
DIALOG_APPLY_BUTTON     = 1
DIALOG_CANCEL_BUTTON    = 2
DIALOG_DEFAULT_BUTTON   = 3
DIALOG_OK_BUTTON        = 4
DIALOG_FILTER_LABEL     = 5
DIALOG_FILTER_TEXT      = 6
DIALOG_HELP_BUTTON      = 7
DIALOG_LIST             = 8
DIALOG_HISTORY_LIST     = DIALOG_LIST
DIALOG_LIST_LABEL       = 9
DIALOG_MESSAGE_LABEL    = 10
DIALOG_SELECTION_LABEL  = 11
DIALOG_PROMPT_LABEL     = DIALOG_SELECTION_LABEL
DIALOG_SYMBOL_LABEL     = 12
DIALOG_TEXT             = 13
DIALOG_VALUE_TEXT       = DIALOG_TEXT
DIALOG_COMMAND_TEXT     = DIALOG_TEXT
DIALOG_SEPARATOR        = 14
DIALOG_DIR_LIST         = 15
DIALOG_DIR_LIST_LABEL   = 16
DIALOG_FILE_LIST        = DIALOG_LIST
DIALOG_FILE_LIST_LABEL  = DIALOG_LIST_LABEL

# dialog style defines  

DIALOG_MODELESS                  = 0
DIALOG_PRIMARY_APPLICATION_MODAL = 1
DIALOG_FULL_APPLICATION_MODAL    = 2
DIALOG_SYSTEM_MODAL              = 3

#-----------------------------------------------------------------------
# XmSelectionBox, XmFileSelectionBox and XmCommand - misc. stuff       
#

# Defines for file type mask:

FILE_DIRECTORY        = (1 << 0)
FILE_REGULAR          = (1 << 1)
FILE_ANY_TYPE         = (FILE_DIRECTORY | FILE_REGULAR)

# Defines for selection dialog type:

DIALOG_WORK_AREA      = 0
DIALOG_PROMPT         = 1
DIALOG_SELECTION      = 2
DIALOG_COMMAND        = 3
DIALOG_FILE_SELECTION = 4

#-----------------------------------------------------------------------
# XmMessageBox           stuff not common to other dialogs            
#

# defines for dialog type 

DIALOG_ERROR           = 1
DIALOG_INFORMATION     = 2
DIALOG_MESSAGE         = 3
DIALOG_QUESTION        = 4
DIALOG_WARNING         = 5
DIALOG_WORKING         = 6

# Traversal direction defines  

TRAVERSE_CURRENT           = 0
TRAVERSE_NEXT              = 1
TRAVERSE_PREV              = 2
TRAVERSE_HOME              = 3
TRAVERSE_NEXT_TAB_GROUP    = 4
TRAVERSE_PREV_TAB_GROUP    = 5
TRAVERSE_UP                = 6
TRAVERSE_DOWN              = 7
TRAVERSE_LEFT              = 8
TRAVERSE_RIGHT             = 9

#-----------------------------------------------------------------------
# SimpleMenu declarations and definitions.
#
PUSHBUTTON            = 1
TOGGLEBUTTON          = 2
CHECKBUTTON           = 2
RADIOBUTTON           = 3
CASCADEBUTTON         = 4
SEPARATOR             = 5
DOUBLE_SEPARATOR      = 6
TITLE                 = 7

#-----------------------------------------------------------------------
# VendorE.h contents
#-----------------------------------------------------------------------
# DeleteResponse values
DESTROY               = 0
UNMAP 	              = 1
DO_NOTHING            = 2
