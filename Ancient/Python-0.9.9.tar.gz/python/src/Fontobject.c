#include "allobjects.h"
#include "modsupport.h"

#include "widgetobject.h"
#include "Fontobject.h"

#ifndef offsetof
#define offsetof(type, member) ( (int) & ((type*)0) -> member )
#endif

typedef struct {
	OB_HEAD
	Display *f_display;
	XFontStruct *f_struct;
} FontObject;

#define OFF(member) offsetof(XFontStruct, member)
static struct Fontattr {
	char *type;
	char *name;
	int offset;
} Fontattrdefs[] = {
	{"Font", "fid", OFF(fid)},
	{"unsigned", "direction", OFF(direction)},
	{"unsigned", "min_char_or_byte2", OFF(min_char_or_byte2)},
	{"unsigned", "max_char_or_byte2", OFF(max_char_or_byte2)},
	{"unsigned", "min_byte1", OFF(min_byte1)},
	{"unsigned", "max_byte1", OFF(max_byte1)},
	{"Bool", "all_chars_exist", OFF(all_chars_exist)},
	{"unsigned", "default_char", OFF(default_char)},
	{"int", "n_properties", OFF(n_properties)},
	{"XFontProp[]", "properties", OFF(properties)},
	{"XCharStruct", "min_bounds", OFF(min_bounds)},
	{"XCharStruct", "max_bounds", OFF(max_bounds)},
	{"XCharStruct[]", "per_char", OFF(per_char)},
	{"int", "ascent", OFF(ascent)},
	{"int", "descent", OFF(descent)},
	{0, 0, 0}
};
#undef OFF

extern typeobject Fonttype; /* Really static forward */

object *
PyFont_New(display, name)
	Display *display;
	char *name;
{
	FontObject *f = NEWOBJ(FontObject, &Fonttype);
	if (f == NULL)
		return NULL;
	f->f_display = display;
	f->f_struct = XLoadQueryFont(display, name);
	return (object *)f;
}

static object *
MemberList()
{
	int i, n;
	object *v;
	for (n = 0; Fontattrdefs[n].name != NULL; n++)
		;
	v = newlistobject(n);
	if (v != NULL) {
		for (i = 0; i < n; i++)
			setlistitem(v, i,
				    newstringobject(Fontattrdefs[i].name));
		if (err_occurred()) {
			DECREF(v);
			v = NULL;
		}
		else {
			sortlist(v);
		}
	}
	return v;
}

static object *
TextWidth(self, args)
	FontObject *self;
	object *args;
{
	char *string;
	int nchars;
	if (!getargs(args, "s#", &string, &nchars))
		return NULL;
	return newintobject(XTextWidth(self->f_struct, string, nchars));
}

static object *
TextExtents(self, args)
	FontObject *self;
	object *args;
{
	char *string;
	int nchars;
	int direction, font_ascent, font_descent;
	XCharStruct overall;
	if (!getargs(args, "s#", &string, &nchars))
		return NULL;
	XTextExtents(self->f_struct, string, nchars,
		     &direction, &font_ascent, &font_descent, &overall);
	return mkvalue("(iii(iiiiii))",
		       direction,
		       font_ascent,
		       font_descent,
		       overall.lbearing,
		       overall.rbearing,
		       overall.width,
		       overall.ascent,
		       overall.descent,
		       overall.attributes);
}

static struct methodlist FontMethods[] = {
	{"TextExtents", TextExtents},
	{"TextWidth", TextWidth},
	{0, 0}
};

static object *
GetAttr(self, name)
	FontObject *self;
	char *name;
{
	struct Fontattr *p;
	object *result;
	if (name[0] == '_' && strcmp(name, "__members__") == 0)
		return MemberList();
	result = findmethod(FontMethods, (object *)self, name);
	if (result != NULL)
		return result;
	err_clear();
	for (p = Fontattrdefs; ; p++) {
		if (p->name == NULL) {
			err_setstr(AttributeError, name);
			return NULL;
		}
		if (strcmp(name, p->name) == 0)
			break;
	}
	if (p->type[0] == 'X') {
		err_setstr(AttributeError, "non-int attr not yet supported");
		return NULL;
	}
	return newintobject(* (long *) ((char *)(self->f_struct) + p->offset));
}

static void
Dealloc(self)
	FontObject *self;
{
	XFreeFont(self->f_display, self->f_struct);
	DEL(self);
}

static typeobject Fonttype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"font",			/*tp_name*/
	sizeof(FontObject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	(void (*) PROTO((object *)))
	Dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	GetAttr,		/*tp_getattr*/
	0,			/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
	0,			/*tp_hash*/
};
