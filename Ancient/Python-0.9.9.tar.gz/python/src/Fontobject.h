extern object *PyFont_New PROTO((Display *, char *));
