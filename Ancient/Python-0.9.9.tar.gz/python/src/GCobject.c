#include "allobjects.h"
#include "widgetobject.h"
#include "GCobject.h"

#ifndef offsetof
#define offsetof(type, member) ( (int) & ((type*)0) -> member )
#endif

typedef struct {
	OB_HEAD
	Display *gc_display;
	Drawable gc_drawable;
	GC gc_gc;
	Widget gc_widget;
} GCobject;

#define OFF(member) offsetof(XGCValues, member)
static struct GCattr {
	char *type;
	char *name;
	int offset;
	unsigned long mask;
} GCattrdefs[] = {
	{"int", "function", OFF(function), GCFunction},
	{"unsigned long", "plane_mask", OFF(plane_mask), GCPlaneMask},
	{"unsigned long", "foreground", OFF(foreground), GCForeground},
	{"unsigned long", "background", OFF(background), GCBackground},
	{"int", "line_width", OFF(line_width), GCLineWidth},
	{"int", "line_style", OFF(line_style), GCLineStyle},
	{"int", "cap_style", OFF(cap_style), GCCapStyle},
	{"int", "join_style", OFF(join_style), GCJoinStyle},
	{"int", "fill_style", OFF(fill_style), GCFillStyle},
	{"int", "fill_rule", OFF(fill_rule), GCFillRule},
	{"int", "arc_mode", OFF(arc_mode), GCArcMode},
	{"Pixmap", "tile", OFF(tile), GCTile},
	{"Pixmap", "stipple", OFF(stipple), GCStipple},
	{"int", "ts_x_origin", OFF(ts_x_origin), GCTileStipXOrigin},
	{"int", "ts_y_origin", OFF(ts_y_origin), GCTileStipYOrigin},
	{"Font", "font", OFF(font), GCFont},
	{"int", "subwindow_mode", OFF(subwindow_mode), GCSubwindowMode},
	{"Bool", "graphics_exposures", OFF(graphics_exposures),
		 					GCGraphicsExposures},
	{"int", "clip_x_origin", OFF(clip_x_origin), GCClipXOrigin},
	{"int", "clip_y_origin", OFF(clip_y_origin), GCClipYOrigin},
	{"Pixmask", "clip_mask", OFF(clip_mask), GCClipMask},
	{"int", "dash_offset", OFF(dash_offset), GCDashOffset},
	/* XXX We don't do dashes since the type is not integer */
/*	{"char", "dashes", OFF(dashes), GCDashList},	*/
	0,
};
#undef OFF

int
PyGC_MakeValues(dict, pmask, pvalues)
	object *dict;
	unsigned long *pmask;
	XGCValues *pvalues;
{
	int pos;
	struct GCattr *p;
	object *key, *value;
	if (dict == NULL || !is_dictobject(dict)) {
		err_setstr(TypeError, "XGCValues should be dictionary");
		return 0;
	}
	*pmask = 0;
	pos = 0;
	while (mappinggetnext(dict, &pos, &key, &value)) {
		char *name;
		if (!is_stringobject(key) || !is_intobject(value)) {
			err_setstr(TypeError,
				   "XGCValues should map string->int");
			return 0;
		}
		name = getstringvalue(key);
		for (p = GCattrdefs; ; p++) {
			if (p->name == NULL) {
				err_setstr(TypeError,
					   "XGCValues contains unknown name");
				return 0;
			}
			if (strcmp(name, p->name) != 0)
				continue;
			*pmask |= p->mask;
			/* XXX Assume sizeof(int) == sizeof(long)! */
			* (long *) ( (char *)pvalues + p->offset ) =
				getintvalue(value);
			break;
		}
	}
	return 1;
}

int
checkshortlist(width, list, parray, pnitems)
	int width;
	object *list;
	short **parray;
	int *pnitems;
{
	int i, n;
	if (!is_listobject(list)) {
		err_setstr(TypeError, "list of tuples expected");
		return 0;
	}
	n = getlistsize(list);
	*pnitems = n;
	*parray = NEW(short, n*width);
	if (*parray == NULL) {
		err_nomem();
		return 0;
	}
	for (i = 0; i < n; i++) {
		object *item = getlistitem(list, i);
		int j;
		if (!is_tupleobject(item) || gettuplesize(item) != width) {
			char buf[100];
			DEL(*parray);
			sprintf(buf, "list of %d-tuples expected", width);
			err_setstr(TypeError, buf);
			return 0;
		}
		for (j = 0; j < width; j++) {
			object *elem = gettupleitem(item, j);
			if (!is_intobject(elem)) {
				DEL(*parray);
				err_setstr(TypeError,
					   "list of tuples of ints expected");
				return 0;
			}
			(*parray)[i*width+j] = getintvalue(elem);
		}
	}
	return 1;
}

extern typeobject GCtype; /* Really forward */

object *
PyGC_New(display, drawable, gc, widget)
	Display *display;
	Drawable drawable;
	GC gc;
	Widget widget;
{
	GCobject *gp = NEWOBJ(GCobject, &GCtype);
	if (gp == NULL)
		return NULL;
	gp->gc_display = display;
	gp->gc_drawable = drawable;
	gp->gc_gc = gc;
	gp->gc_widget = widget;
	return (object *)gp;
}

#include "GCmethods.h"

static object *
MemberList()
{
	int i, n;
	object *v;
	for (n = 0; GCattrdefs[n].name != NULL; n++)
		;
	v = newlistobject(n);
	if (v != NULL) {
		for (i = 0; i < n; i++)
			setlistitem(v, i, newstringobject(GCattrdefs[i].name));
		if (err_occurred()) {
			DECREF(v);
			v = NULL;
		}
		else {
			sortlist(v);
		}
	}
	return v;
}

static object *
GetAttr(self, name)
	GCobject *self;
	char *name;
{
	struct GCattr *p;
	XGCValues values;
	object *result;
	if (name[0] == '_' && strcmp(name, "__members__") == 0)
		return MemberList();
	result = findmethod(PyGC_methods, (object *)self, name);
	if (result != NULL)
		return result;
	err_clear();
	for (p = GCattrdefs; ; p++) {
		if (p->name == NULL) {
			err_setstr(AttributeError, name);
			return NULL;
		}
		if (strcmp(name, p->name) == 0)
			break;
	}
	if (!XGetGCValues(self->gc_display, self->gc_gc, p->mask, &values)) {
		err_setstr(TypeError, "write-only (!) GC attribute");
		return NULL;
	}
	/* XXX Assume sizeof(int) == sizeof(long) */
	return newintobject(* (long *) ((char *)(&values) + p->offset));
}

static int
SetAttr(self, name, value)
	GCobject *self;
	char *name;
	object *value;
{
	struct GCattr *p;
	XGCValues values;
	object *result;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return -1;
	}
	if (value == NULL) {
		err_setstr(TypeError, "can't delete GC attribute");
		return -1;
	}
	if (!is_intobject(value)) {
		err_setstr(TypeError, "GC attribute value must be integer");
		return -1;
	}
	for (p = GCattrdefs; ; p++) {
		if (p->name == NULL) {
			err_setstr(AttributeError, name);
			return -1;
		}
		if (strcmp(name, p->name) == 0)
			break;
	}
	/* XXX Assume sizeof(int) == sizeof(long) */
	* (long *) ((char *)(&values) + p->offset) = getintvalue(value);
	XChangeGC(self->gc_display, self->gc_gc, p->mask, &values);
	return 0;
}

void
Dealloc(self)
	GCobject *self;
{
	if (self->gc_widget)
		XtReleaseGC(self->gc_widget, self->gc_gc);
	else
		XFreeGC(self->gc_display, self->gc_gc);
	DEL(self);
}

typeobject GCtype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"GC",			/*tp_name*/
	sizeof(GCobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	(void (*) PROTO((object *)))
	Dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	GetAttr,		/*tp_getattr*/
	SetAttr,		/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
	0,			/*tp_hash*/
};
