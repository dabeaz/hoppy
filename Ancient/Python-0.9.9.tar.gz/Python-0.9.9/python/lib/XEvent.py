# This module contains one public function, mkevent().  Called with a
# string argument containing the binary, in-core representation of an
# XEvent structure (such as passed to Xt event handlers), mkevent()
# returns an instance of the class XEvent with fields appropriate to
# the event type set to the corresponding value.  At the very least,
# the following fields are defined: type, serial, send_event, display,
# and window.  For selected event types, more fields are defined (e.g.
# see the definition of XKeyEvent below).
#
# Example:
#
# import XEvent
# def mouse_handler(widget, closure, event, *rest):
#     e = XEvent.mkevent(event)
#     print 'Mouse event: (x, y) =', (e.x, e.y)
#
# (The '*rest' argument is for future compatibility.  Currently
# Python event handlers are called without the fourth argument that is
# passed to C event handlers specifying 'continue_to_dispatch', but I
# expect that this argument will be added in the future.  Making the
# function accept a variable number of arguments beyond the first
# three will keep your code working when this change is made.)

# XXX The 'display' field is returned as an integer, since we have no
# objects corresponding to Xlib display structures yet.

# XXX It would be nice if this was already done by the C glue for
# event handlers.  Maybe later...  (The definitions in this module
# may be usable to automatically generate the necessary C code.)

import struct
import X

# The X...Event tuples below are definitions of how to unpack various
# event types.  The first item is a format string to be passed to
# struct.unpack(); the rest are the names of the corresponding fields.

# XXX Should type in the definitions of all X event structures...

XKeyEvent = ('ilbllllliiiiiib', 
	  'type', 'serial', 'send_event', 'display', 'window', 'root',
	  'subwindow', 'time', 'x', 'y', 'x_root', 'y_root',
	  'state', 'keycode', 'same_screen')

XButtonEvent = ('ilbllllliiiiiib',
	  'type', 'serial', 'send_event', 'display', 'window', 'root',
	  'subwindow', 'time', 'x', 'y', 'x_root', 'y_root',
	  'state', 'button', 'same_screen')

XMotionEvent = ('ilbllllliiiiicb',
	  'type', 'serial', 'send_event', 'display', 'window', 'root',
	  'subwindow', 'time', 'x', 'y', 'x_root', 'y_root',
	  'state', 'is_hint', 'same_screen')

XPropertyEvent = ('ilblllli',
	  'type', 'serial', 'send_event', 'display', 'window',
	  'atom', 'time', 'state')

XAnyEvent = ('ilbll',
	  'type', 'serial', 'send_event', 'display', 'window')

# Map event types to event structure definitions
eventswitch = {
	  X.ButtonPress: XButtonEvent,
	  X.ButtonRelease: XButtonEvent,
	  X.KeyPress: XKeyEvent,
	  X.KeyRelease: XKeyEvent,
	  X.MotionNotify: XMotionEvent,
	  X.PropertyNotify: XPropertyEvent,
	  }

# The number of bytes occupied by an XEvent's type field
typesize = struct.calcsize('i')

# The class containing XEvent structures
class XEvent:
	def __init__(self, *rest):
		if len(rest) > 1: raise TypeError, 'too many args'
		if len(rest) == 1:
			self._setevent(rest[0])
	def init(self, event):
		self._setevent(event)
		return self
	def _setevent(self, event):
		self.type = struct.unpack('i', event[:typesize])[0]
		if eventswitch.has_key(self.type):
			form = eventswitch[self.type]
		else:
			form = XAnyEvent
		fmt, names = form[0], form[1:]
		size = struct.calcsize(fmt)
		tuple = struct.unpack(fmt, event[:size])
		if len(tuple) <> len(names):
			print 'tuple:', tuple
			print 'names:', names
			raise SystemError, 'inconsistent X event definition'
		for i in range(len(tuple)):
			setattr(self, names[i], tuple[i])
	def __repr__(self):
		if eventswitch.has_key(self.type):
			form = eventswitch[self.type]
		else:
			form = XAnyEvent
		fmt, names = form[0], form[1:]
		s = '<XEvent'
		for name in names:
			if name == 'display': continue
			s = s + ', %s=%s' % (name, `getattr(self, name)`)
		s = s + '>'
		return s

# The only public function in this module
def mkevent(event):
	return XEvent(event)
