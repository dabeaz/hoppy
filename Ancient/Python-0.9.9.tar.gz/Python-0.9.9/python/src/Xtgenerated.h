
/* Methods for Xt objects */

#include <X11/Composite.h>

#include <X11/Constraint.h>

#include <X11/Shell.h>

#include <X11/Vendor.h>

static object *
Xt_AddInput(self, args)
	object *self;
	object *args;
{
	XtInputId result;
	int arg1;
	int arg2;
	object *arg3, *cbfunc;
	object *arg4, *cbarg;
	if (!getargs(args, "(iiOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	cbfunc = arg3;
	cbarg = mkvalue("(OO)", cbfunc, arg4);
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtAddInput(arg1,
			(void*)arg2,
			univ_inputhandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xt_RemoveInput(self, args)
	object *self;
	object *args;
{
	XtIntervalId arg1;
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveInput(arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xt_AddTimeOut(self, args)
	object *self;
	object *args;
{
	XtIntervalId result;
	unsigned long arg1;
	object *arg2, *cbfunc;
	object *arg3, *cbarg;
	if (!getargs(args, "(lOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	cbfunc = arg2;
	cbarg = mkvalue("(OO)", cbfunc, arg3);
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtAddTimeOut(arg1,
			univ_timeouthandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xt_RemoveTimeOut(self, args)
	object *self;
	object *args;
{
	XtIntervalId arg1;
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveTimeOut(arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xt_AddWorkProc(self, args)
	object *self;
	object *args;
{
	XtWorkProcId result;
	object *arg1, *cbfunc;
	object *arg2, *cbarg;
	if (!getargs(args, "(OO)",
			&arg1,
			&arg2))
		return NULL;
	cbfunc = arg1;
	cbarg = mkvalue("(OO)", cbfunc, arg2);
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtAddWorkProc(univ_workproc,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xt_RemoveWorkProc(self, args)
	object *self;
	object *args;
{
	XtIntervalId arg1;
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveWorkProc(arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xt_MainLoop(self, args)
	object *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtMainLoop();
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

struct methodlist Xt_methods[] = {
	{"Initialize", Xt_Initialize},
	{"CreateApplicationShell", Xt_CreateApplicationShell},
	{"AddInput", Xt_AddInput},
	{"RemoveInput", Xt_RemoveInput},
	{"AddTimeOut", Xt_AddTimeOut},
	{"RemoveTimeOut", Xt_RemoveTimeOut},
	{"AddWorkProc", Xt_AddWorkProc},
	{"RemoveWorkProc", Xt_RemoveWorkProc},
	{"MainLoop", Xt_MainLoop},
	{0, 0} /* Sentinel */
};


/* Methods for wclass objects */

struct methodlist wclass_methods[] = {
	{"GetResourceList", wclass_GetResourceList},
	{0, 0} /* Sentinel */
};


/* Methods for widget objects */

static object *
widget_Parent(self, args)
	widgetobject *self;
	object *args;
{
	Widget result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtParent(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
widget_ManageChild(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtManageChild(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_UnmanageChild(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtUnmanageChild(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_IsManaged(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtIsManaged(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_RealizeWidget(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRealizeWidget(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_UnrealizeWidget(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtUnrealizeWidget(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_IsRealized(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtIsRealized(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_MapWidget(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtMapWidget(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_UnmapWidget(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtUnmapWidget(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_SetMappedWhenManaged(self, args)
	widgetobject *self;
	object *args;
{
	int arg1;
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtSetMappedWhenManaged(self->ob_widget,
			(Boolean)arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_SetSensitive(self, args)
	widgetobject *self;
	object *args;
{
	int arg1;
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtSetSensitive(self->ob_widget,
			(Boolean)arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_IsSensitive(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtIsSensitive(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_CreateWidget(self, args)
	widgetobject *self;
	object *args;
{
	Widget result;
	Widget w = self->ob_widget;
	WidgetClass wC = XtClass(self->ob_widget);
	String arg1;
	object *arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_wclassobject(arg2)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be WidgetClass");
		return NULL;
	}
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtCreateWidget(arg1,
			getwclassvalue(arg2),
			self->ob_widget,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
widget_CreateManagedWidget(self, args)
	widgetobject *self;
	object *args;
{
	Widget result;
	Widget w = self->ob_widget;
	WidgetClass wC = XtClass(self->ob_widget);
	String arg1;
	object *arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_wclassobject(arg2)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be WidgetClass");
		return NULL;
	}
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtCreateManagedWidget(arg1,
			getwclassvalue(arg2),
			self->ob_widget,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
widget_Class(self, args)
	widgetobject *self;
	object *args;
{
	WidgetClass result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtClass(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwclassobject(result, wclass_methodlists);
}

static object *
widget_Superclass(self, args)
	widgetobject *self;
	object *args;
{
	WidgetClass result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtSuperclass(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwclassobject(result, wclass_methodlists);
}

static object *
widget_IsSubclass(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_wclassobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be WidgetClass");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtIsSubclass(self->ob_widget,
			getwclassvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_IsComposite(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtIsComposite(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_NameToWidget(self, args)
	widgetobject *self;
	object *args;
{
	Widget result;
	String arg1;
	if (!getargs(args, "s",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtNameToWidget(self->ob_widget,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
widget_SetValues(self, args)
	widgetobject *self;
	object *args;
{
	Widget w = self->ob_widget;
	WidgetClass wC = XtClass(self->ob_widget);
	object *arg1; ArgList a; int nargs;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkargdict(wC, w, arg1, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtSetValues(self->ob_widget,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_AddCallback(self, args)
	widgetobject *self;
	object *args;
{
	String arg1;
	object *arg2, *cbfunc;
	object *arg3, *cbarg;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	cbfunc = arg2;
	cbarg = make_closure(cbfunc, arg3, sizeof(int)+sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtAddCallback(self->ob_widget,
			arg1,
			univ_callback,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_RemoveCallback(self, args)
	widgetobject *self;
	object *args;
{
	String arg1;
	object *arg2, *cbfunc;
	object *arg3, *cbarg;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	cbfunc = arg2;
	cbarg = make_closure(cbfunc, arg3, sizeof(int)+sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveCallback(self->ob_widget,
			arg1,
			univ_callback,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_RemoveAllCallbacks(self, args)
	widgetobject *self;
	object *args;
{
	String arg1;
	if (!getargs(args, "s",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveAllCallbacks(self->ob_widget,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_CallCallbacks(self, args)
	widgetobject *self;
	object *args;
{
	String arg1;
	String arg2;
	if (!getargs(args, "(ss)",
			&arg1,
			&arg2))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtCallCallbacks(self->ob_widget,
			arg1,
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_HasCallbacks(self, args)
	widgetobject *self;
	object *args;
{
	Boolean result;
	String arg1;
	if (!getargs(args, "s",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtHasCallbacks(self->ob_widget,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_AddEventHandler(self, args)
	widgetobject *self;
	object *args;
{
	EventMask arg1;
	int arg2;
	object *arg3, *cbfunc;
	object *arg4, *cbarg;
	if (!getargs(args, "(liOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	cbfunc = arg3;
	cbarg = make_closure(cbfunc, arg4, sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtAddEventHandler(self->ob_widget,
			arg1,
			(Boolean)arg2,
			univ_eventhandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_RemoveEventHandler(self, args)
	widgetobject *self;
	object *args;
{
	EventMask arg1;
	int arg2;
	object *arg3, *cbfunc;
	object *arg4, *cbarg;
	if (!getargs(args, "(liOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	cbfunc = arg3;
	cbarg = make_closure(cbfunc, arg4, sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveEventHandler(self->ob_widget,
			arg1,
			(Boolean)arg2,
			univ_eventhandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_AddRawEventHandler(self, args)
	widgetobject *self;
	object *args;
{
	EventMask arg1;
	int arg2;
	object *arg3, *cbfunc;
	object *arg4, *cbarg;
	if (!getargs(args, "(liOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	cbfunc = arg3;
	cbarg = make_closure(cbfunc, arg4, sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtAddRawEventHandler(self->ob_widget,
			arg1,
			(Boolean)arg2,
			univ_eventhandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_RemoveRawEventHandler(self, args)
	widgetobject *self;
	object *args;
{
	EventMask arg1;
	int arg2;
	object *arg3, *cbfunc;
	object *arg4, *cbarg;
	if (!getargs(args, "(liOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	cbfunc = arg3;
	cbarg = make_closure(cbfunc, arg4, sizeof(XEvent));
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtRemoveRawEventHandler(self->ob_widget,
			arg1,
			(Boolean)arg2,
			univ_eventhandler,
			(XtPointer)cbarg);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_BuildEventMask(self, args)
	widgetobject *self;
	object *args;
{
	EventMask result;
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtBuildEventMask(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
widget_Popup(self, args)
	widgetobject *self;
	object *args;
{
	XtGrabKind arg1;
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtPopup(self->ob_widget,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_Popdown(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtPopdown(self->ob_widget);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_InstallAccelerators(self, args)
	widgetobject *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtInstallAccelerators(self->ob_widget,
			getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
widget_InstallAllAccelerators(self, args)
	widgetobject *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtInstallAllAccelerators(self->ob_widget,
			getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

struct methodlist widget_methods[] = {
	{"Parent", widget_Parent},
	{"ManageChild", widget_ManageChild},
	{"UnmanageChild", widget_UnmanageChild},
	{"IsManaged", widget_IsManaged},
	{"RealizeWidget", widget_RealizeWidget},
	{"UnrealizeWidget", widget_UnrealizeWidget},
	{"IsRealized", widget_IsRealized},
	{"MapWidget", widget_MapWidget},
	{"UnmapWidget", widget_UnmapWidget},
	{"SetMappedWhenManaged", widget_SetMappedWhenManaged},
	{"SetSensitive", widget_SetSensitive},
	{"IsSensitive", widget_IsSensitive},
	{"CreateWidget", widget_CreateWidget},
	{"CreateManagedWidget", widget_CreateManagedWidget},
	{"CreatePopupShell", widget_CreatePopupShell},
	{"DestroyWidget", widget_DestroyWidget},
	{"Class", widget_Class},
	{"Superclass", widget_Superclass},
	{"IsSubclass", widget_IsSubclass},
	{"IsComposite", widget_IsComposite},
	{"NameToWidget", widget_NameToWidget},
	{"SetValues", widget_SetValues},
	{"GetValues", widget_GetValues},
	{"AddCallback", widget_AddCallback},
	{"RemoveCallback", widget_RemoveCallback},
	{"RemoveAllCallbacks", widget_RemoveAllCallbacks},
	{"CallCallbacks", widget_CallCallbacks},
	{"HasCallbacks", widget_HasCallbacks},
	{"AddEventHandler", widget_AddEventHandler},
	{"RemoveEventHandler", widget_RemoveEventHandler},
	{"AddRawEventHandler", widget_AddRawEventHandler},
	{"RemoveRawEventHandler", widget_RemoveRawEventHandler},
	{"BuildEventMask", widget_BuildEventMask},
	{"Popup", widget_Popup},
	{"Popdown", widget_Popdown},
	{"InstallAccelerators", widget_InstallAccelerators},
	{"InstallAllAccelerators", widget_InstallAllAccelerators},
	{"Convert", widget_Convert},
	{"TranslateCoords", widget_TranslateCoords},
	{"GetGC", widget_GetGC},
	{"CreateGC", widget_CreateGC},
	{"ListFonts", widget_ListFonts},
	{"LoadQueryFont", widget_LoadQueryFont},
	{0, 0} /* Sentinel */
};

static void
makewidgets(d)
	object *d;
{
	dictinsert(d, "Composite",
		(object*)newwclassobject(compositeWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Constraint",
		(object*)newwclassobject(constraintWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Shell",
		(object*)newwclassobject(shellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "OverrideShell",
		(object*)newwclassobject(overrideShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "WMShell",
		(object*)newwclassobject(wmShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "VendorShell",
		(object*)newwclassobject(vendorShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "TopLevelShell",
		(object*)newwclassobject(topLevelShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "TransientShell",
		(object*)newwclassobject(transientShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ApplicationShell",
		(object*)newwclassobject(applicationShellWidgetClass,
			wclass_methodlists));
}

