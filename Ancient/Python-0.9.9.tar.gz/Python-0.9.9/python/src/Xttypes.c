/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Type converters for Xt */

#include "allobjects.h"
#include "modsupport.h"
#include "ceval.h"
#include "widgetobject.h" /* Implies <X11/Intrinsic.h> */
#include "Xttypes.h"

int
p2xtvalue(v, xtvalue, p_typename)
	object *v;
	XrmValue *xtvalue;
	char **p_typename;
{
	if (is_intobject(v)) {
		static int val;
		val = getintvalue(v);
		xtvalue->size = sizeof(int);
		xtvalue->addr = (XtPointer)&val;
		*p_typename = "Int";
		return 1;
	}
	if (is_stringobject(v)) {
		xtvalue->size = getstringsize(v);
		xtvalue->addr = getstringvalue(v);
		*p_typename = "String";
		return 1;
	}
	if (is_widgetobject(v)) {
		xtvalue->size = sizeof(Widget);
		xtvalue->addr = (XtPointer)getwidgetvalue(v);
		*p_typename = "Widget";
		return 1;
	}
	err_setstr(TypeError, "can't convert Python type to Xt type");
	return 0;
}

static char *inttypes[] = {
	"Int", "Short", "Bool", "Boolean", "Dimension", "Position",
	"Cardinal", "HorizontalInt", "VerticalInt",
	"Pixel", "InitialState",
	"ShellHorizDim", "ShellHorizPos", "ShellVertDim", "ShellVertPos",
	/* Xm specific enumeration types: */
	"Alignment", "ArrowDirection",
	"BooleanDimension",
	"DefaultButtonType", "DialogStyle", "DialogType",
	"EditMode",
	"FileTypeMask",
	"HorizontalDimension", "HorizontalPosition",
	"IndicatorType",
	"KeySym",
	"LabelType", "ListSizePolicy",
	"MultiClick",
	"NavigationType",
	"Orientation",
	"Packing", "ProcessingDirection",
	"ResizePolicy", "RowColumnType",
	"ScrollBarDisplayPolicy", "ScrollBarPlacement", "ScrollingPolicy",
	"SelectionPolicy", "SeparatorType", "ShadowType", "StringDirection",
	"TextPosition",
	"VerticalDimension", "VerticalPosition",
	"VisualPolicy",
	NULL
};

static struct x2p {
	char *typename;
	object * (*converter) PROTO((XrmValue*));
	struct x2p *next;
} *x2phead = NULL;

void
x2pregister(typename, converter)
	char *typename;
	object * (*converter) PROTO((XrmValue*));
{
	struct x2p *p = NEW(struct x2p, 1);
	if (p == NULL)
		fatal("can't register x2p converter");
	p->typename = typename;
	p->converter = converter;
	p->next = x2phead;
	x2phead = p;
}

object *
xtvalue2p(xtvalue, typename)
	XrmValue *xtvalue;
	char *typename;
{
	char buf[100];
	char **t;
	struct x2p *p;
	if (xtvalue->size == 0) {
		err_setstr(SystemError, "xtvalue2p: size==0");
		return NULL;
	}
	for (t = inttypes; *t != NULL; t++) {
		if (strcmp(typename, *t) == 0)
			return newintobject((long)*(int*)xtvalue->addr);
	}
	if (strcmp(typename, "String") == 0)
		return newsizedstringobject((char*)xtvalue->addr,
					    xtvalue->size);
	if (strcmp(typename, "Widget") == 0 ||
	    strcmp(typename, "MenuWidget") == 0)
		return (object *)newwidgetobject((Widget)xtvalue->addr,
				       widget_methodlists); /* XXX ??? */
	for (p = x2phead; p != NULL; p = p->next) {
		if (strcmp(typename, p->typename) == 0)
			return (*p->converter)(xtvalue);
	}
	sprintf(buf, "can't convert Xt type '%.50s' to Python", typename);
	err_setstr(TypeError, buf);
	return NULL;
}

int
xtvalue2xtargval(xtvalue, p_xtargval)
	XrmValue *xtvalue;
	XtArgVal *p_xtargval;
{
	if (xtvalue->size > sizeof(XtArgVal)) {
		*p_xtargval = (XtArgVal)xtvalue->addr;
		return 1;
	}
	if (xtvalue->size == sizeof(long)) {
		*p_xtargval = *(long*)xtvalue->addr;
		return 1;
	}
	if (xtvalue->size == sizeof(short)) {
		*p_xtargval = *(short*)xtvalue->addr;
		return 1;
	}
	if (xtvalue->size == sizeof(char)) {
		*p_xtargval = *(char*)xtvalue->addr;
		return 1;
	}
	err_setstr(SystemError, "xtvalue2xtargval: unknown size");
	return 0;
}

int
p2xtargval(v, p_xtargval, p_typename)
	object *v;
	XtArgVal *p_xtargval;
	char **p_typename;
{
	XrmValue xtvalue;
	if (is_intobject(v)) {
		*p_xtargval = (XtArgVal)getintvalue(v);
		return 1;
	}
	if (!p2xtvalue(v, &xtvalue, p_typename))
		return 0;
	return xtvalue2xtargval(&xtvalue, p_xtargval);
}

object *
xtargval2p(xtargval, typename, size)
	XtArgVal xtargval;
	char *typename;
	int size;
{
	XrmValue xtvalue;
	if (strcmp(typename, "String") == 0)
		return mkvalue("s", (char *)xtargval);
	if (size <= sizeof(XtArgVal) || strcmp(typename, "XmString") == 0)
		xtvalue.addr = (XtPointer)&xtargval;
	else
		xtvalue.addr = (XtPointer)xtargval;
	xtvalue.size = size;
	return xtvalue2p(&xtvalue, typename);
}
