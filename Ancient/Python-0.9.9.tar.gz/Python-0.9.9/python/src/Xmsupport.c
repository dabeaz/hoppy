/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Support routines for module Xm */

#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"
#include "Xttypes.h"
#include "Xmsupport.h"

object *
xmstring2pstring(s)
	XmString s;
{
	char *text;
	if (s != (XmString)(-1) &&
	    XmStringGetLtoR(s, XmSTRING_DEFAULT_CHARSET, &text))
		return newstringobject(text);
	INCREF(None);
	return None;
}

static object *
xmsconverter(xtvalue)
	XrmValue *xtvalue;
{
	return xmstring2pstring(*(XmString*)xtvalue->addr);
}

void
initxmsupport()
{
	x2pregister("XmString", xmsconverter);
}

#ifndef MOTIF_1_0
object *
Xm_ListGetSelectedPos(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	int *position_list;
	int position_count;
	object *list;
	int i;
	object *v;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmListGetSelectedPos(getwidgetvalue(arg1),
					      &position_list,
					      &position_count);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	if (!result) {
		INCREF(None);
		return None;
	}
	list = newlistobject(position_count);
	for (i = 0; i < position_count && list != NULL; i++) {
		v = newintobject(position_list[i]);
		if (v == NULL) {
			DECREF(list);
			list = NULL;
		}
		else
			setlistitem(list, i, v); /* Eats a ref */
	}
	DEL(position_list);
	return list;
}
#endif /* MOTIF_1_0 */
