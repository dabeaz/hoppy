#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"

#define extobject wclassobject
#define ob_ptr ob_wclass
#define EXTPTR WidgetClass
#define EXTNAME "WidgetClass"
#define newextobject newwclassobject
#define getextvalue getwclassvalue
#define ext_forget wclass_forget
#define Exttype Wclasstype

#include "extobject.c"
