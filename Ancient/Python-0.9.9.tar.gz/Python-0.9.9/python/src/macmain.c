/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Python interpreter main program -- Macintosh version (THINK C) */

#include "allobjects.h"

extern int debugging; /* Needed by parser.c */
extern int verbose; /* Needed by import.c */

main(argc, argv)
	int argc;
	char **argv;
{
	int c;
	int sts;
	char *filename = NULL;
	FILE *fp = stdin;
	
	initargs(&argc, &argv); /* Defined in config*.c */

	
	if (argc > 1)
		filename = argv[1];
	
	if (filename != NULL) {
		if ((fp = fopen(filename, "r")) == NULL) {
			fprintf(stderr, "%s: can't open file '%s'\n",
				argv[0], filename);
			exit(2);
		}
	}
	
	initall();
	
	setpythonargv(argc-1, argv+1);

	if (filename == NULL && isatty((int)fileno(fp))) {
		FILE *fp = fopen("PythonStartup", "r");
		if (fp != NULL) {
			(void) run_script(fp, "PythonStartup");
			err_clear();
		}
	}
	sts = run(fp, filename == NULL ? "<stdin>" : filename) != 0;

	goaway(sts);
	/*NOTREACHED*/
}
