/* Widget Set HTML */

#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"


/* Methods for HTML objects */

#include "/ufs/guido/src/xmosaic/libhtmlw/HTML.h"

static object *
HTML_GetText(self, args)
	object *self;
	object *args;
{
	char* result;
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = HTMLGetText(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newstringobject(result);
}

static object *
HTML_PositionToId(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = HTMLPositionToId(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
HTML_ClearSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		HTMLClearSelection(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
HTML_SetText(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	char *arg3;
	char *arg4;
	if (!getargs(args, "(Osss)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		HTMLSetText(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

#include "HTMLmanual.h"
struct methodlist HTML_methods[] = {
	{"GetText", HTML_GetText},
	{"GetTextAndSelection", HTML_GetTextAndSelection},
	{"GetHRefs", HTML_GetHRefs},
	{"PositionToId", HTML_PositionToId},
	{"IdToPosition", HTML_IdToPosition},
	{"AnchorToPosition", HTML_AnchorToPosition},
	{"ClearSelection", HTML_ClearSelection},
	{"SetSelection", HTML_SetSelection},
	{"SetText", HTML_SetText},
	{"SearchText", HTML_SearchText},
	{"cbarg", HTML_cbarg},
	{0, 0} /* Sentinel */
};


/* Methods for HTMLwc objects */

struct methodlist HTMLwc_methods[] = {
	{0, 0} /* Sentinel */
};


/* Methods for HTMLw objects */

struct methodlist HTMLw_methods[] = {
	{0, 0} /* Sentinel */
};


struct methodlist *HTMLw_methodlists[] = {
	HTMLw_methods,
	0
};

void
initHTML()
{
	object *m, *d;
	m = initmodule("HTML", HTML_methods);
	d = getmoduledict(m);
	dictinsert(d, "html",
		(object*)newwclassobject(htmlWidgetClass,
			wclass_methodlists));
}
