#undef None
#undef True
#undef False
#include <X11/Intrinsic.h>
#undef None
#undef True
#undef False
#define None (&NoObject)

#ifdef MOTIF_1_0
typedef char *XtPointer; /* Hack */
#endif

#include <setjmp.h>

extern jmp_buf jump_where;
extern int jump_flag; /* 1 if allowed to jump, 0 if not, -1 if jumped */

extern object *Xt_Error;

typedef struct {
	OB_HEAD
	Widget ob_widget;
	struct methodlist **ob_methodlists;
} widgetobject;

widgetobject *newwidgetobject PROTO((Widget, struct methodlist **));
Widget getwidgetvalue PROTO((object *));

extern typeobject Widgettype;
#define is_widgetobject(x) ((x)->ob_type == &Widgettype)

typedef struct {
	OB_HEAD
	WidgetClass ob_wclass;
	struct methodlist **ob_methodlists;
} wclassobject;

wclassobject *newwclassobject PROTO((WidgetClass, struct methodlist **));
WidgetClass getwclassvalue PROTO((object *));

extern typeobject Wclasstype;
#define is_wclassobject(x) ((x)->ob_type == &Wclasstype)

extern void univ_callback PROTO((Widget, void *, void *));
extern void univ_eventhandler PROTO((Widget, XtPointer, XEvent *, Boolean *));
extern void univ_inputhandler PROTO((XtPointer, int *, XtInputId *));
extern object *make_closure PROTO((object *, object *, int));
extern int checkargdict PROTO((WidgetClass, Widget,
			       object *, ArgList *, int *));
extern int checkstringlist PROTO((object *, char ***, int *));
object *res_to_python PROTO((WidgetClass, object *, XtArgVal));
int python_to_res PROTO((WidgetClass, Widget, object *, object *, XtArgVal *));

extern struct methodlist *widget_methodlists[];
extern struct methodlist *wclass_methodlists[];
