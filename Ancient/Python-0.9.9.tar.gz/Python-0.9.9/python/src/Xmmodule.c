/* Widget Set Xm */

#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"

#include "Xmsupport.h"

/* Methods for Xm objects */

#include <Xm/ArrowB.h>

static object *
Xm_CreateArrowButton(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateArrowButton(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/ArrowBG.h>

static object *
Xm_CreateArrowButtonGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateArrowButtonGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/BulletinB.h>

static object *
Xm_CreateBulletinBoard(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateBulletinBoard(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateBulletinBoardDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateBulletinBoardDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/CascadeB.h>

static object *
Xm_CreateCascadeButton(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateCascadeButton(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/CascadeBG.h>

static object *
Xm_CreateCascadeButtonGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateCascadeButtonGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Command.h>

static object *
Xm_CreateCommand(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateCommand(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CommandError(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmCommandError(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_CommandAppendValue(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmCommandAppendValue(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_CommandSetValue(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmCommandSetValue(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

#include <Xm/DialogS.h>

static object *
Xm_CreateDialogShell(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateDialogShell(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/DrawingA.h>

static object *
Xm_CreateDrawingArea(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateDrawingArea(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/DrawnB.h>

static object *
Xm_CreateDrawnButton(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateDrawnButton(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/FileSB.h>

static object *
Xm_CreateFileSelectionBox(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateFileSelectionBox(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateFileSelectionDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateFileSelectionDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_FileSelectionDoSearch(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmFileSelectionDoSearch(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

#include <Xm/Form.h>

static object *
Xm_CreateForm(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateForm(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateFormDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateFormDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Frame.h>

static object *
Xm_CreateFrame(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateFrame(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Label.h>

static object *
Xm_CreateLabel(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateLabel(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/LabelG.h>

static object *
Xm_CreateLabelGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateLabelGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/List.h>

static object *
Xm_CreateList(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateList(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/MainW.h>

static object *
Xm_CreateMainWindow(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateMainWindow(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/MenuShell.h>

static object *
Xm_CreateMenuShell(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateMenuShell(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/MessageB.h>

static object *
Xm_CreateMessageBox(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateMessageBox(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateErrorDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateErrorDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateInformationDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateInformationDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateMessageDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateMessageDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateQuestionDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateQuestionDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateWarningDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateWarningDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateWorkingDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateWorkingDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/PanedW.h>

static object *
Xm_CreatePanedWindow(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePanedWindow(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/PushB.h>

static object *
Xm_CreatePushButton(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePushButton(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/PushBG.h>

static object *
Xm_CreatePushButtonGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePushButtonGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/RowColumn.h>

static object *
Xm_CreateRowColumn(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateRowColumn(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateMenuBar(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateMenuBar(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateOptionMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateOptionMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreatePopupMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePopupMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreatePulldownMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePulldownMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateRadioBox(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateRadioBox(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Scale.h>

static object *
Xm_CreateScale(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateScale(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/ScrollBar.h>

static object *
Xm_CreateScrollBar(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateScrollBar(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateScrolledList(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateScrolledList(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/ScrolledW.h>

static object *
Xm_CreateScrolledWindow(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateScrolledWindow(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_ScrolledWindowSetAreas(self, args)
	object *self;
	object *args;
{
	object *arg1;
	object *arg2;
	object *arg3;
	object *arg4;
	if (!getargs(args, "(OOOO)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!is_widgetobject(arg2)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be Widget");
		return NULL;
	}
	if (!is_widgetobject(arg3)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be Widget");
		return NULL;
	}
	if (!is_widgetobject(arg4)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg4 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmScrolledWindowSetAreas(getwidgetvalue(arg1),
			getwidgetvalue(arg2),
			getwidgetvalue(arg3),
			getwidgetvalue(arg4));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

#include <Xm/SelectioB.h>

static object *
Xm_CreateSelectionBox(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSelectionBox(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreatePromptDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreatePromptDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateSelectionDialog(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSelectionDialog(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Separator.h>

static object *
Xm_CreateSeparator(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSeparator(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/SeparatoG.h>

static object *
Xm_CreateSeparatorGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSeparatorGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/Text.h>

static object *
Xm_CreateText(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateText(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateScrolledText(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateScrolledText(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/ToggleB.h>

static object *
Xm_CreateToggleButton(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateToggleButton(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_ToggleButtonGetState(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmToggleButtonGetState(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_ToggleButtonSetState(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmToggleButtonSetState(getwidgetvalue(arg1),
			(Boolean)arg2,
			(Boolean)arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

#include <Xm/ToggleBG.h>

static object *
Xm_CreateToggleButtonGadget(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateToggleButtonGadget(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_ToggleButtonGadgetGetState(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmToggleButtonGadgetGetState(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_ToggleButtonGadgetSetState(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmToggleButtonGadgetSetState(getwidgetvalue(arg1),
			(Boolean)arg2,
			(Boolean)arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_CreateSimpleMenuBar(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSimpleMenuBar(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateSimpleOptionMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSimpleOptionMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateSimplePopupMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSimplePopupMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateSimplePulldownMenu(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSimplePulldownMenu(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateSimpleRadioBox(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateSimpleRadioBox(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include <Xm/TextF.h>

static object *
Xm_CreateTextField(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateTextField(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_CreateWorkArea(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	object *arg1;
	String arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(OsO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	w = getwidgetvalue(arg1);
	wC = XtClass(w);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCreateWorkArea(getwidgetvalue(arg1),
			arg2,
			a, nargs);
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_MenuPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	object *arg2;
	if (!getargs(args, "(OS)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!getstringsize(arg2) == sizeof(XEvent)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be Event*");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmMenuPosition(getwidgetvalue(arg1),
			(XButtonPressedEvent *)getstringvalue(arg2));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_CommandGetChild(self, args)
	object *self;
	object *args;
{
	Widget result;
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmCommandGetChild(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_FileSelectionBoxGetChild(self, args)
	object *self;
	object *args;
{
	Widget result;
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmFileSelectionBoxGetChild(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_MessageBoxGetChild(self, args)
	object *self;
	object *args;
{
	Widget result;
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmMessageBoxGetChild(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_SelectionBoxGetChild(self, args)
	object *self;
	object *args;
{
	Widget result;
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmSelectionBoxGetChild(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xm_TextClearSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextClearSelection(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldClearSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldClearSelection(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextGetEditable(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetEditable(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldGetEditable(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetEditable(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetInsertionPosition(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetInsertionPosition(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldGetInsertionPosition(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetInsertionPosition(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetLastPosition(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetLastPosition(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldGetLastPosition(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetLastPosition(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetMaxLength(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetMaxLength(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldGetMaxLength(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetMaxLength(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetSelection(self, args)
	object *self;
	object *args;
{
	String result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetSelection(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newstringobject(result);
}

static object *
Xm_TextFieldGetSelection(self, args)
	object *self;
	object *args;
{
	String result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetSelection(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newstringobject(result);
}

static object *
Xm_TextGetString(self, args)
	object *self;
	object *args;
{
	String result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetString(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newstringobject(result);
}

static object *
Xm_TextFieldGetString(self, args)
	object *self;
	object *args;
{
	String result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetString(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newstringobject(result);
}

static object *
Xm_TextReplace(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	String arg4;
	if (!getargs(args, "(Olls)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextReplace(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldReplace(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	String arg4;
	if (!getargs(args, "(Olls)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldReplace(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextScroll(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextScroll(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetEditable(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetEditable(getwidgetvalue(arg1),
			(Boolean)arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetEditable(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetEditable(getwidgetvalue(arg1),
			(Boolean)arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetInsertionPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetInsertionPosition(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetInsertionPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetInsertionPosition(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetMaxLength(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetMaxLength(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetMaxLength(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetMaxLength(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	Time arg4;
	if (!getargs(args, "(Olll)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetSelection(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	Time arg4;
	if (!getargs(args, "(Olll)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetSelection(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetString(self, args)
	object *self;
	object *args;
{
	object *arg1;
	String arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetString(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetString(self, args)
	object *self;
	object *args;
{
	object *arg1;
	String arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetString(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextShowPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextShowPosition(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldShowPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldShowPosition(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextXYToPos(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	Position arg2;
	Position arg3;
	if (!getargs(args, "(Ohh)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextXYToPos(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldXYToPos(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	Position arg2;
	Position arg3;
	if (!getargs(args, "(Ohh)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldXYToPos(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextCopy(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextCopy(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldCopy(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldCopy(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextCut(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextCut(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldCut(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	Time arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldCut(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetBaseline(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetBaseline(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldGetBaseline(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldGetBaseline(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextGetTopCharacter(self, args)
	object *self;
	object *args;
{
	XmTextPosition result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextGetTopCharacter(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextInsert(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	String arg3;
	if (!getargs(args, "(Ols)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextInsert(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldInsert(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	String arg3;
	if (!getargs(args, "(Ols)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldInsert(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetAddMode(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetAddMode(getwidgetvalue(arg1),
			(Boolean)arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetAddMode(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetAddMode(getwidgetvalue(arg1),
			(Boolean)arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextSetHighlight(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	XmHighlightMode arg4;
	if (!getargs(args, "(Olli)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetHighlight(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextFieldSetHighlight(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	XmTextPosition arg3;
	XmHighlightMode arg4;
	if (!getargs(args, "(Olli)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextFieldSetHighlight(getwidgetvalue(arg1),
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_TextPaste(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextPaste(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldPaste(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldPaste(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextRemove(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextRemove(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextFieldRemove(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmTextFieldRemove(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_TextSetTopCharacter(self, args)
	object *self;
	object *args;
{
	object *arg1;
	XmTextPosition arg2;
	if (!getargs(args, "(Ol)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmTextSetTopCharacter(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListAddItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	int arg3;
	if (!getargs(args, "(Osi)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListAddItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET),
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListAddItemUnselected(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	int arg3;
	if (!getargs(args, "(Osi)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListAddItemUnselected(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET),
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeleteItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeleteItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeletePos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeletePos(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeselectAllItems(self, args)
	object *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeselectAllItems(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeselectItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeselectItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeselectPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeselectPos(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListItemExists(self, args)
	object *self;
	object *args;
{
	Boolean result;
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmListItemExists(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_ListSelectItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	int arg3;
	if (!getargs(args, "(Osi)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSelectItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET),
			(Boolean)arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSelectPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSelectPos(getwidgetvalue(arg1),
			arg2,
			(Boolean)arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSetBottomItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetBottomItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSetBottomPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetBottomPos(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSetHorizPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetHorizPos(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSetItem(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetItem(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListSetPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetPos(getwidgetvalue(arg1),
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeleteAllItems(self, args)
	object *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeleteAllItems(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListDeleteItemsPos(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListDeleteItemsPos(getwidgetvalue(arg1),
			arg2,
			arg3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
Xm_ListItemPos(self, args)
	object *self;
	object *args;
{
	int result;
	object *arg1;
	char *arg2;
	if (!getargs(args, "(Os)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XmListItemPos(getwidgetvalue(arg1),
			XmStringCreateLtoR(arg2, XmSTRING_DEFAULT_CHARSET));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return newintobject((long)result);
}

static object *
Xm_ListSetAddMode(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XmListSetAddMode(getwidgetvalue(arg1),
			(Boolean)arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

struct methodlist Xm_methods[] = {
	{"CreateArrowButton", Xm_CreateArrowButton},
	{"CreateArrowButtonGadget", Xm_CreateArrowButtonGadget},
	{"CreateBulletinBoard", Xm_CreateBulletinBoard},
	{"CreateBulletinBoardDialog", Xm_CreateBulletinBoardDialog},
	{"CreateCascadeButton", Xm_CreateCascadeButton},
	{"CreateCascadeButtonGadget", Xm_CreateCascadeButtonGadget},
	{"CreateCommand", Xm_CreateCommand},
	{"CommandError", Xm_CommandError},
	{"CommandAppendValue", Xm_CommandAppendValue},
	{"CommandSetValue", Xm_CommandSetValue},
	{"CreateDialogShell", Xm_CreateDialogShell},
	{"CreateDrawingArea", Xm_CreateDrawingArea},
	{"CreateDrawnButton", Xm_CreateDrawnButton},
	{"CreateFileSelectionBox", Xm_CreateFileSelectionBox},
	{"CreateFileSelectionDialog", Xm_CreateFileSelectionDialog},
	{"FileSelectionDoSearch", Xm_FileSelectionDoSearch},
	{"CreateForm", Xm_CreateForm},
	{"CreateFormDialog", Xm_CreateFormDialog},
	{"CreateFrame", Xm_CreateFrame},
	{"CreateLabel", Xm_CreateLabel},
	{"CreateLabelGadget", Xm_CreateLabelGadget},
	{"CreateList", Xm_CreateList},
	{"CreateMainWindow", Xm_CreateMainWindow},
	{"CreateMenuShell", Xm_CreateMenuShell},
	{"CreateMessageBox", Xm_CreateMessageBox},
	{"CreateErrorDialog", Xm_CreateErrorDialog},
	{"CreateInformationDialog", Xm_CreateInformationDialog},
	{"CreateMessageDialog", Xm_CreateMessageDialog},
	{"CreateQuestionDialog", Xm_CreateQuestionDialog},
	{"CreateWarningDialog", Xm_CreateWarningDialog},
	{"CreateWorkingDialog", Xm_CreateWorkingDialog},
	{"CreatePanedWindow", Xm_CreatePanedWindow},
	{"CreatePushButton", Xm_CreatePushButton},
	{"CreatePushButtonGadget", Xm_CreatePushButtonGadget},
	{"CreateRowColumn", Xm_CreateRowColumn},
	{"CreateMenuBar", Xm_CreateMenuBar},
	{"CreateOptionMenu", Xm_CreateOptionMenu},
	{"CreatePopupMenu", Xm_CreatePopupMenu},
	{"CreatePulldownMenu", Xm_CreatePulldownMenu},
	{"CreateRadioBox", Xm_CreateRadioBox},
	{"CreateScale", Xm_CreateScale},
	{"CreateScrollBar", Xm_CreateScrollBar},
	{"CreateScrolledList", Xm_CreateScrolledList},
	{"CreateScrolledWindow", Xm_CreateScrolledWindow},
	{"ScrolledWindowSetAreas", Xm_ScrolledWindowSetAreas},
	{"CreateSelectionBox", Xm_CreateSelectionBox},
	{"CreatePromptDialog", Xm_CreatePromptDialog},
	{"CreateSelectionDialog", Xm_CreateSelectionDialog},
	{"CreateSeparator", Xm_CreateSeparator},
	{"CreateSeparatorGadget", Xm_CreateSeparatorGadget},
	{"CreateText", Xm_CreateText},
	{"CreateScrolledText", Xm_CreateScrolledText},
	{"CreateToggleButton", Xm_CreateToggleButton},
	{"ToggleButtonGetState", Xm_ToggleButtonGetState},
	{"ToggleButtonSetState", Xm_ToggleButtonSetState},
	{"CreateToggleButtonGadget", Xm_CreateToggleButtonGadget},
	{"ToggleButtonGadgetGetState", Xm_ToggleButtonGadgetGetState},
	{"ToggleButtonGadgetSetState", Xm_ToggleButtonGadgetSetState},
	{"CreateSimpleMenuBar", Xm_CreateSimpleMenuBar},
	{"CreateSimpleOptionMenu", Xm_CreateSimpleOptionMenu},
	{"CreateSimplePopupMenu", Xm_CreateSimplePopupMenu},
	{"CreateSimplePulldownMenu", Xm_CreateSimplePulldownMenu},
	{"CreateSimpleRadioBox", Xm_CreateSimpleRadioBox},
	{"CreateTextField", Xm_CreateTextField},
	{"CreateWorkArea", Xm_CreateWorkArea},
	{"MenuPosition", Xm_MenuPosition},
	{"CommandGetChild", Xm_CommandGetChild},
	{"FileSelectionBoxGetChild", Xm_FileSelectionBoxGetChild},
	{"MessageBoxGetChild", Xm_MessageBoxGetChild},
	{"SelectionBoxGetChild", Xm_SelectionBoxGetChild},
	{"TextClearSelection", Xm_TextClearSelection},
	{"TextFieldClearSelection", Xm_TextFieldClearSelection},
	{"TextGetEditable", Xm_TextGetEditable},
	{"TextFieldGetEditable", Xm_TextFieldGetEditable},
	{"TextGetInsertionPosition", Xm_TextGetInsertionPosition},
	{"TextFieldGetInsertionPosition", Xm_TextFieldGetInsertionPosition},
	{"TextGetLastPosition", Xm_TextGetLastPosition},
	{"TextFieldGetLastPosition", Xm_TextFieldGetLastPosition},
	{"TextGetMaxLength", Xm_TextGetMaxLength},
	{"TextFieldGetMaxLength", Xm_TextFieldGetMaxLength},
	{"TextGetSelection", Xm_TextGetSelection},
	{"TextFieldGetSelection", Xm_TextFieldGetSelection},
	{"TextGetString", Xm_TextGetString},
	{"TextFieldGetString", Xm_TextFieldGetString},
	{"TextReplace", Xm_TextReplace},
	{"TextFieldReplace", Xm_TextFieldReplace},
	{"TextScroll", Xm_TextScroll},
	{"TextSetEditable", Xm_TextSetEditable},
	{"TextFieldSetEditable", Xm_TextFieldSetEditable},
	{"TextSetInsertionPosition", Xm_TextSetInsertionPosition},
	{"TextFieldSetInsertionPosition", Xm_TextFieldSetInsertionPosition},
	{"TextSetMaxLength", Xm_TextSetMaxLength},
	{"TextFieldSetMaxLength", Xm_TextFieldSetMaxLength},
	{"TextSetSelection", Xm_TextSetSelection},
	{"TextFieldSetSelection", Xm_TextFieldSetSelection},
	{"TextSetString", Xm_TextSetString},
	{"TextFieldSetString", Xm_TextFieldSetString},
	{"TextShowPosition", Xm_TextShowPosition},
	{"TextFieldShowPosition", Xm_TextFieldShowPosition},
	{"TextXYToPos", Xm_TextXYToPos},
	{"TextFieldXYToPos", Xm_TextFieldXYToPos},
	{"TextCopy", Xm_TextCopy},
	{"TextFieldCopy", Xm_TextFieldCopy},
	{"TextCut", Xm_TextCut},
	{"TextFieldCut", Xm_TextFieldCut},
	{"TextGetBaseline", Xm_TextGetBaseline},
	{"TextFieldGetBaseline", Xm_TextFieldGetBaseline},
	{"TextGetTopCharacter", Xm_TextGetTopCharacter},
	{"TextInsert", Xm_TextInsert},
	{"TextFieldInsert", Xm_TextFieldInsert},
	{"TextSetAddMode", Xm_TextSetAddMode},
	{"TextFieldSetAddMode", Xm_TextFieldSetAddMode},
	{"TextSetHighlight", Xm_TextSetHighlight},
	{"TextFieldSetHighlight", Xm_TextFieldSetHighlight},
	{"TextPaste", Xm_TextPaste},
	{"TextFieldPaste", Xm_TextFieldPaste},
	{"TextRemove", Xm_TextRemove},
	{"TextFieldRemove", Xm_TextFieldRemove},
	{"TextSetTopCharacter", Xm_TextSetTopCharacter},
	{"ListAddItem", Xm_ListAddItem},
	{"ListAddItemUnselected", Xm_ListAddItemUnselected},
	{"ListDeleteItem", Xm_ListDeleteItem},
	{"ListDeletePos", Xm_ListDeletePos},
	{"ListDeselectAllItems", Xm_ListDeselectAllItems},
	{"ListDeselectItem", Xm_ListDeselectItem},
	{"ListDeselectPos", Xm_ListDeselectPos},
	{"ListItemExists", Xm_ListItemExists},
	{"ListSelectItem", Xm_ListSelectItem},
	{"ListSelectPos", Xm_ListSelectPos},
	{"ListSetBottomItem", Xm_ListSetBottomItem},
	{"ListSetBottomPos", Xm_ListSetBottomPos},
	{"ListSetHorizPos", Xm_ListSetHorizPos},
	{"ListSetItem", Xm_ListSetItem},
	{"ListSetPos", Xm_ListSetPos},
	{"ListDeleteAllItems", Xm_ListDeleteAllItems},
	{"ListDeleteItemsPos", Xm_ListDeleteItemsPos},
	{"ListGetSelectedPos", Xm_ListGetSelectedPos},
	{"ListItemPos", Xm_ListItemPos},
	{"ListSetAddMode", Xm_ListSetAddMode},
	{0, 0} /* Sentinel */
};


/* Methods for Xmwc objects */

struct methodlist Xmwc_methods[] = {
	{0, 0} /* Sentinel */
};


/* Methods for Xmw objects */

struct methodlist Xmw_methods[] = {
	{0, 0} /* Sentinel */
};


struct methodlist *Xmw_methodlists[] = {
	Xmw_methods,
	0
};

void
initXm()
{
	object *m, *d;
	m = initmodule("Xm", Xm_methods);
	d = getmoduledict(m);
	dictinsert(d, "ArrowButton",
		(object*)newwclassobject(xmArrowButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ArrowButtonGadget",
		(object*)newwclassobject(xmArrowButtonGadgetClass,
			wclass_methodlists));
	dictinsert(d, "BulletinBoard",
		(object*)newwclassobject(xmBulletinBoardWidgetClass,
			wclass_methodlists));
	dictinsert(d, "CascadeButton",
		(object*)newwclassobject(xmCascadeButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "CascadeButtonGadget",
		(object*)newwclassobject(xmCascadeButtonGadgetClass,
			wclass_methodlists));
	dictinsert(d, "Command",
		(object*)newwclassobject(xmCommandWidgetClass,
			wclass_methodlists));
	dictinsert(d, "DialogShell",
		(object*)newwclassobject(xmDialogShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "DrawingArea",
		(object*)newwclassobject(xmDrawingAreaWidgetClass,
			wclass_methodlists));
	dictinsert(d, "DrawnButton",
		(object*)newwclassobject(xmDrawnButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "FileSelectionBox",
		(object*)newwclassobject(xmFileSelectionBoxWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Form",
		(object*)newwclassobject(xmFormWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Frame",
		(object*)newwclassobject(xmFrameWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Label",
		(object*)newwclassobject(xmLabelWidgetClass,
			wclass_methodlists));
	dictinsert(d, "LabelGadget",
		(object*)newwclassobject(xmLabelGadgetClass,
			wclass_methodlists));
	dictinsert(d, "List",
		(object*)newwclassobject(xmListWidgetClass,
			wclass_methodlists));
	dictinsert(d, "MainWindow",
		(object*)newwclassobject(xmMainWindowWidgetClass,
			wclass_methodlists));
	dictinsert(d, "MenuShell",
		(object*)newwclassobject(xmMenuShellWidgetClass,
			wclass_methodlists));
	dictinsert(d, "MessageBox",
		(object*)newwclassobject(xmMessageBoxWidgetClass,
			wclass_methodlists));
	dictinsert(d, "PanedWindow",
		(object*)newwclassobject(xmPanedWindowWidgetClass,
			wclass_methodlists));
	dictinsert(d, "PushButton",
		(object*)newwclassobject(xmPushButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "PushButtonGadget",
		(object*)newwclassobject(xmPushButtonGadgetClass,
			wclass_methodlists));
	dictinsert(d, "RowColumn",
		(object*)newwclassobject(xmRowColumnWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Scale",
		(object*)newwclassobject(xmScaleWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ScrollBar",
		(object*)newwclassobject(xmScrollBarWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ScrolledWindow",
		(object*)newwclassobject(xmScrolledWindowWidgetClass,
			wclass_methodlists));
	dictinsert(d, "SelectionBox",
		(object*)newwclassobject(xmSelectionBoxWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Separator",
		(object*)newwclassobject(xmSeparatorWidgetClass,
			wclass_methodlists));
	dictinsert(d, "SeparatorGadget",
		(object*)newwclassobject(xmSeparatorGadgetClass,
			wclass_methodlists));
	dictinsert(d, "Text",
		(object*)newwclassobject(xmTextWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ToggleButton",
		(object*)newwclassobject(xmToggleButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "ToggleButtonGadget",
		(object*)newwclassobject(xmToggleButtonGadgetClass,
			wclass_methodlists));
	dictinsert(d, "TextField",
		(object*)newwclassobject(xmTextFieldWidgetClass,
			wclass_methodlists));
	initxmsupport();
}
