
/* Methods for PyGC objects */

static object *
PyGC_DrawArc(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	Dimension arg3;
	Dimension arg4;
	int arg5;
	int arg6;
	if (!getargs(args, "(hhhhii)",
			&arg1,
			&arg2,
			&arg3,
			&arg4,
			&arg5,
			&arg6))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawArc(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4,
			arg5,
			arg6);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawArcs(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XArc *arcs; int narcs;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkshortlist(6, arg1, (short**)&arcs, &narcs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XArc[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawArcs(self->gc_display, self->gc_drawable, self->gc_gc,
			arcs, narcs);
		jump_flag = 0;
	}
	DEL(arcs);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawImageString(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	int arg2;
	object *arg3; int nchars;
	if (!getargs(args, "(iiS)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!(nchars = getstringsize(arg3), 1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be char[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawImageString(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			getstringvalue(arg3), nchars);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawLine(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	Position arg3;
	Position arg4;
	if (!getargs(args, "(hhhh)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawLine(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawLines(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XPoint *pts; int npts;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!checkshortlist(2, arg1, (short**)&pts, &npts)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XPoint[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawLines(self->gc_display, self->gc_drawable, self->gc_gc,
			pts, npts,
			arg2);
		jump_flag = 0;
	}
	DEL(pts);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawPoint(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	if (!getargs(args, "(hh)",
			&arg1,
			&arg2))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawPoint(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawPoints(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XPoint *pts; int npts;
	int arg2;
	if (!getargs(args, "(Oi)",
			&arg1,
			&arg2))
		return NULL;
	if (!checkshortlist(2, arg1, (short**)&pts, &npts)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XPoint[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawPoints(self->gc_display, self->gc_drawable, self->gc_gc,
			pts, npts,
			arg2);
		jump_flag = 0;
	}
	DEL(pts);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawRectangle(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	Dimension arg3;
	Dimension arg4;
	if (!getargs(args, "(hhhh)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawRectangle(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawRectangles(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XRectangle *rects; int nrects;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkshortlist(4, arg1, (short**)&rects, &nrects)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XRectangle[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawRectangles(self->gc_display, self->gc_drawable, self->gc_gc,
			rects, nrects);
		jump_flag = 0;
	}
	DEL(rects);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawSegments(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XSegment *segs; int nsegs;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkshortlist(4, arg1, (short**)&segs, &nsegs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XSegment[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawSegments(self->gc_display, self->gc_drawable, self->gc_gc,
			segs, nsegs);
		jump_flag = 0;
	}
	DEL(segs);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_DrawString(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	int arg2;
	object *arg3; int nchars;
	if (!getargs(args, "(iiS)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!(nchars = getstringsize(arg3), 1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be char[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XDrawString(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			getstringvalue(arg3), nchars);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_FillArc(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	Dimension arg3;
	Dimension arg4;
	int arg5;
	int arg6;
	if (!getargs(args, "(hhhhii)",
			&arg1,
			&arg2,
			&arg3,
			&arg4,
			&arg5,
			&arg6))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XFillArc(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4,
			arg5,
			arg6);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_FillArcs(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XArc *arcs; int narcs;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkshortlist(6, arg1, (short**)&arcs, &narcs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XArc[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XFillArcs(self->gc_display, self->gc_drawable, self->gc_gc,
			arcs, narcs);
		jump_flag = 0;
	}
	DEL(arcs);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_FillPolygon(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XPoint *pts; int npts;
	int arg2;
	int arg3;
	if (!getargs(args, "(Oii)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!checkshortlist(2, arg1, (short**)&pts, &npts)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XPoint[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XFillPolygon(self->gc_display, self->gc_drawable, self->gc_gc,
			pts, npts,
			arg2,
			arg3);
		jump_flag = 0;
	}
	DEL(pts);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_FillRectangle(self, args)
	GCobject *self;
	object *args;
{
	Position arg1;
	Position arg2;
	Dimension arg3;
	Dimension arg4;
	if (!getargs(args, "(hhhh)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XFillRectangle(self->gc_display, self->gc_drawable, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_FillRectangles(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; XRectangle *rects; int nrects;
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!checkshortlist(4, arg1, (short**)&rects, &nrects)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XRectangle[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XFillRectangles(self->gc_display, self->gc_drawable, self->gc_gc,
			rects, nrects);
		jump_flag = 0;
	}
	DEL(rects);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_ChangeGC(self, args)
	GCobject *self;
	object *args;
{
	object *arg1; unsigned long mask; XGCValues values;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "O",
			&arg1))
		return NULL;
	if (!PyGC_MakeValues(arg1, &mask, &values)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be XGCValues#");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XChangeGC(self->gc_display, self->gc_gc,
			mask, &values);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetArcMode(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetArcMode(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetBackground(self, args)
	GCobject *self;
	object *args;
{
	unsigned long arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetBackground(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetClipMask(self, args)
	GCobject *self;
	object *args;
{
	Pixmap arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetClipMask(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetClipOrigin(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	int arg2;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(ii)",
			&arg1,
			&arg2))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetClipOrigin(self->gc_display, self->gc_gc,
			arg1,
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetClipRectangles(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	int arg2;
	object *arg3; XRectangle *rects; int nrects;
	int arg4;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(iiOi)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!checkshortlist(4, arg3, (short**)&rects, &nrects)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be XRectangle[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetClipRectangles(self->gc_display, self->gc_gc,
			arg1,
			arg2,
			rects, nrects,
			arg4);
		jump_flag = 0;
	}
	DEL(rects);
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetDashes(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	object *arg2; int nchars;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(iS)",
			&arg1,
			&arg2))
		return NULL;
	if (!(nchars = getstringsize(arg2), 1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be char[]");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetDashes(self->gc_display, self->gc_gc,
			arg1,
			getstringvalue(arg2), nchars);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetFillRule(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetFillRule(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetFillStyle(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetFillStyle(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetFont(self, args)
	GCobject *self;
	object *args;
{
	Font arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetFont(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetForeground(self, args)
	GCobject *self;
	object *args;
{
	unsigned long arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetForeground(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetFunction(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetFunction(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetGraphicsExposures(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetGraphicsExposures(self->gc_display, self->gc_gc,
			(Bool)arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetLineAttributes(self, args)
	GCobject *self;
	object *args;
{
	unsigned int arg1;
	int arg2;
	int arg3;
	int arg4;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(iiii)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetLineAttributes(self->gc_display, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetPlaneMask(self, args)
	GCobject *self;
	object *args;
{
	unsigned long arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetPlaneMask(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetState(self, args)
	GCobject *self;
	object *args;
{
	unsigned long arg1;
	unsigned long arg2;
	int arg3;
	unsigned long arg4;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(llil)",
			&arg1,
			&arg2,
			&arg3,
			&arg4))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetState(self->gc_display, self->gc_gc,
			arg1,
			arg2,
			arg3,
			arg4);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetStipple(self, args)
	GCobject *self;
	object *args;
{
	Pixmap arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetStipple(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetSubwindowMode(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "i",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetSubwindowMode(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetTSOrigin(self, args)
	GCobject *self;
	object *args;
{
	int arg1;
	int arg2;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "(ii)",
			&arg1,
			&arg2))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetTSOrigin(self->gc_display, self->gc_gc,
			arg1,
			arg2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
PyGC_SetTile(self, args)
	GCobject *self;
	object *args;
{
	Pixmap arg1;
	if (self->gc_widget) {
		err_setstr(TypeError, "can't modify shared GC");
		return NULL;
	}
	if (!getargs(args, "l",
			&arg1))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XSetTile(self->gc_display, self->gc_gc,
			arg1);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

struct methodlist PyGC_methods[] = {
	{"DrawArc", PyGC_DrawArc},
	{"DrawArcs", PyGC_DrawArcs},
	{"DrawImageString", PyGC_DrawImageString},
	{"DrawLine", PyGC_DrawLine},
	{"DrawLines", PyGC_DrawLines},
	{"DrawPoint", PyGC_DrawPoint},
	{"DrawPoints", PyGC_DrawPoints},
	{"DrawRectangle", PyGC_DrawRectangle},
	{"DrawRectangles", PyGC_DrawRectangles},
	{"DrawSegments", PyGC_DrawSegments},
	{"DrawString", PyGC_DrawString},
	{"FillArc", PyGC_FillArc},
	{"FillArcs", PyGC_FillArcs},
	{"FillPolygon", PyGC_FillPolygon},
	{"FillRectangle", PyGC_FillRectangle},
	{"FillRectangles", PyGC_FillRectangles},
	{"ChangeGC", PyGC_ChangeGC},
	{"SetArcMode", PyGC_SetArcMode},
	{"SetBackground", PyGC_SetBackground},
	{"SetClipMask", PyGC_SetClipMask},
	{"SetClipOrigin", PyGC_SetClipOrigin},
	{"SetClipRectangles", PyGC_SetClipRectangles},
	{"SetDashes", PyGC_SetDashes},
	{"SetFillRule", PyGC_SetFillRule},
	{"SetFillStyle", PyGC_SetFillStyle},
	{"SetFont", PyGC_SetFont},
	{"SetForeground", PyGC_SetForeground},
	{"SetFunction", PyGC_SetFunction},
	{"SetGraphicsExposures", PyGC_SetGraphicsExposures},
	{"SetLineAttributes", PyGC_SetLineAttributes},
	{"SetPlaneMask", PyGC_SetPlaneMask},
	{"SetState", PyGC_SetState},
	{"SetStipple", PyGC_SetStipple},
	{"SetSubwindowMode", PyGC_SetSubwindowMode},
	{"SetTSOrigin", PyGC_SetTSOrigin},
	{"SetTile", PyGC_SetTile},
	{0, 0} /* Sentinel */
};

