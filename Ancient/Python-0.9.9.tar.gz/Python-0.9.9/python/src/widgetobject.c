#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"

#define extobject widgetobject
#define ob_ptr ob_widget
#define EXTPTR Widget
#define EXTNAME "Widget"
#define newextobject newwidgetobject
#define getextvalue getwidgetvalue
#define ext_forget widget_forget
#define Exttype Widgettype
#define ext_getattr widget_getattr
#define ext_setattr widget_setattr

static object *widget_getattr PROTO((object *, char *));
static int widget_setattr PROTO((object *, char *, object *));

#include "extobject.c"

static object *
widget_getattr(self, name)
	object *self;
	char *name;
{
	register widgetobject *wp = (widgetobject *)self;
	object *res = default_ext_getattr(wp, name);
	object *value;
	object *namev;
	Arg a[1];
	if (res != NULL)
		return res;
	err_clear();
	namev = newstringobject(name);
	if (namev == NULL)
		return NULL;
	XtSetArg(a[0], name, 0);
	XtGetValues(wp->ob_widget, a, 1);
	value = res_to_python(XtClass(wp->ob_widget), namev, a[0].value);
	DECREF(namev);
	return value;
}

static int
widget_setattr(self, name, value)
	object *self;
	char *name;
	object *value;
{
	register widgetobject *wp = (widgetobject *)self;
	object *namev;
	Arg a[1];
	int ok;
	namev = newstringobject(name);
	if (namev == NULL)
		return -1;
	ok = python_to_res(XtClass(wp->ob_widget), wp->ob_widget,
			   namev, value, &a[0].value);
	DECREF(namev);
	if (!ok)
		return -1;
	a[0].name = name;
	XtSetValues(wp->ob_widget, a, 1);
	return 0;
}
