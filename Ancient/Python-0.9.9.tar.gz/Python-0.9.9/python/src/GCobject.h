/* GC object interface */

int PyGC_MakeValues PROTO((object *, unsigned long *, XGCValues *));
object *PyGC_New PROTO((Display *, Drawable, GC, Widget));
