/* Widget Set Glx */

#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"

#include "Glxsupport.h"

/* Methods for Glx objects */

#include <X11/Xirisw/GlxDraw.h>

struct methodlist Glx_methods[] = {
	{"winset", Glx_winset},
	{"makeconfig", Glx_makeconfig},
	{0, 0} /* Sentinel */
};


/* Methods for Glxwc objects */

struct methodlist Glxwc_methods[] = {
	{0, 0} /* Sentinel */
};


/* Methods for Glxw objects */

struct methodlist Glxw_methods[] = {
	{0, 0} /* Sentinel */
};


struct methodlist *Glxw_methodlists[] = {
	Glxw_methods,
	0
};

void
initGlx()
{
	object *m, *d;
	m = initmodule("Glx", Glx_methods);
	d = getmoduledict(m);
	dictinsert(d, "Draw",
		(object*)newwclassobject(glxDrawWidgetClass,
			wclass_methodlists));
	initglxsupport();
}
