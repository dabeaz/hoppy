/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Xt (X Toolkit Intrinsics) module */

#include "allobjects.h"
#include "modsupport.h"
#include "ceval.h"
#include "sysmodule.h"

#include "widgetobject.h"
#include "GCobject.h"
#include "Fontobject.h"
#include "Xttypes.h"

#ifdef MOTIF_1_0
int XtConvertAndStore(w, ftype, fptr, ttype, tptr)
	Widget w;
	String ftype;
	XrmValue *fptr;
	String ttype;
	XrmValue *tptr;
{
	XtConvert(w, ftype, fptr, ttype, tptr);
	return tptr->addr != 0;
}
#endif /* MOTIF_1_0 */


object *Xt_Error; /* Exception raised for Xt-specific errors */

jmp_buf jump_where;
int jump_flag; /* 1 if allowed to jump, 0 if not, -1 if jumped */

int
checkstringlist(args, ps, pn)
	object *args;
	char ***ps;
	int *pn;
{
	int i, n;
	char **s;
	if (!is_listobject(args)) {
		err_setstr(TypeError, "list of strings expected");
		return 0;
	}
	n = getlistsize(args);
	s = NEW(String, n+1);
	if (s == NULL) {
		err_nomem();
		return 0;
	}
	for (i = 0; i < n; i++) {
		object *item = getlistitem(args, i);
		if (!is_stringobject(item)) {
			err_setstr(TypeError, "list of strings expected");
			return 0;
		}
		s[i] = getstringvalue(item);
	}
	s[n] = NULL; /* In case caller wants a NULL-terminated list */
	*ps = s;
	*pn = n;
	return 1;
}

int
putbackstringlist(list, s, n)
	object *list;
	char **s;
	int n;
{
	int oldsize = getlistsize(list);
	object *newlist;
	int i;
	if (n == oldsize)
		return 1;
	newlist = newlistobject(n);
	for (i = 0; i < n && newlist != NULL; i++) {
		object *item = newstringobject(s[i]);
		if (item == NULL) {
			DECREF(newlist);
			newlist = NULL;
		}
		else
			setlistitem(newlist, i, item);
	}
	if (newlist == NULL)
		return 0;
	(*list->ob_type->tp_as_sequence->sq_ass_slice)
		(list, 0, oldsize, newlist);
	DECREF(newlist);
	return 1;
}

static Widget toplevel;

int
checkargdict(wC, w, args, pa, pn)
	WidgetClass wC;
	Widget w;
	object *args;
	ArgList *pa;
	int *pn;
{
	int pos, n;
	object *key, *value;
	ArgList a;
	if (args == NULL || !is_dictobject(args)) {
		err_setstr(TypeError, "args must be a dictionary");
		return 0;
	}
	a = NEW(Arg, 1000); /* Hope that's enough */
	pos = 0;
	n = 0;
	while (mappinggetnext(args, &pos, &key, &value)) {
		if (!is_stringobject(key)) {
			err_setstr(TypeError,
				   "args dictionary keys must be strings");
			return NULL;
		}
		a[n].name = getstringvalue(key);
		if (!python_to_res(wC, w, key, value, &a[n].value))
			return 0;
		n++;
	}
	*pa = a;
	*pn = n;
	return 1;
}

static object *
widget_GetValues(self, args)
	widgetobject *self;
	object *args;
{
	object *result;
	int i, n;
	ArgList a;
	if (args == NULL || !is_listobject(args)) {
		err_setstr(TypeError, "list of names expected");
		return NULL;
	}
	n = getlistsize(args);
	a = NEW(Arg, n);
	if (a == NULL)
		return err_nomem();
	for (i = 0; i < n; i++) {
		object *item = getlistitem(args, i);
		char *name;
		if (!getargs(item, "s;name string expected", &name))
			return NULL;
		a[i].name = name;
		a[i].value = 0;
	}
	XtGetValues(self->ob_widget, a, n);
	result = newdictobject();
	for (i = 0; i < n && result != NULL; i++) {
		object *name, *value;
		int err;
		name = getlistitem(args, i);
		value = res_to_python(XtClass(self->ob_widget),
				      name, a[i].value);
		if (value == NULL) {
			DECREF(result);
			result = NULL;
			break;
		}
		err = dict2insert(result, name, value);
		XDECREF(value);
		if (err != 0) {
			DECREF(result);
			result = NULL;
		}
	}
	DEL(a);
	return result;
}

static object *
widget_DestroyWidget(self, args)
	widgetobject *self;
	object *args;
{
	if (!getargs(args, ""))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtDestroyWidget(self->ob_widget);
		jump_flag = 0;
	}
	if (widget_forget(self) != 0 || jump_flag) {
		jump_flag = 0;
		return NULL;
	}
	INCREF(None);
	return None;
}

static object *
widget_Convert(self, args)
	widgetobject *self;
	object *args;
{
	object *from_value;
	char *from_type;
	char *to_type;
	XrmValue from_ptr, to_ptr;
	int ival;
	int ok;
	if (!getargs(args, "(Os)", &from_value, &to_type))
		return NULL;
	if (!p2xtvalue(from_value, &from_ptr, &from_type))
		return NULL;
	to_ptr.size = 0;
	to_ptr.addr = 0;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		ok = XtConvertAndStore(self->ob_widget, from_type, &from_ptr,
			  to_type, &to_ptr);
		jump_flag = 0;
	}
	if (jump_flag) {
		jump_flag = 0;
		return NULL;
	}
	if (!ok) {
		err_setstr(Xt_Error, "Xt.Convert failed");
		return NULL;
	}
	return xtvalue2p(&to_ptr, to_type);
}

static object *
widget_TranslateCoords(self, args)
	widgetobject *self;
	object *args;
{
	Position arg1, arg2, ret1, ret2;
	if (!getargs(args, "(hh)", &arg1, &arg2))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		XtTranslateCoords(self->ob_widget, arg1, arg2, &ret1, &ret2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return mkvalue("(hh)", ret1, ret2);
}

static object *
widget_GetGC(self, args)
	widgetobject *self;
	object *args;
{
	Widget w = self->ob_widget;
	Display *display = XtDisplay(w);
	Drawable d = XtWindow(w);
	unsigned long mask;
	XGCValues values;
	GC gc;
	if (!PyGC_MakeValues(args, &mask, &values))
		return NULL;
	gc = XtGetGC(w, mask, &values);
	return PyGC_New(display, d, gc, w);
}

static object *
widget_CreateGC(self, args)
	widgetobject *self;
	object *args;
{
	Widget w = self->ob_widget;
	Display *display = XtDisplay(w);
	Drawable d = XtWindow(w);
	unsigned long mask;
	XGCValues values;
	GC gc;
	if (!PyGC_MakeValues(args, &mask, &values))
		return NULL;
	gc = XCreateGC(display, d, mask, &values);
	return PyGC_New(display, d, gc, (Widget)0);
}

static object *
widget_ListFonts(self, args)
	widgetobject *self;
	object *args;
{
	Widget w = self->ob_widget;
	Display *display = XtDisplay(w);
	char *pattern;
	char **fontnames;
	int count;
	object *list;
	if (!getargs(args, "s", &pattern))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		fontnames = XListFonts(display, pattern, 10000, &count);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	if (fontnames == NULL)
		count = 0;
	list = newlistobject(count);
	if (list != NULL) {
		int i;
		for (i = 0; i < count; i++) {
			object *item = newstringobject(fontnames[i]);
			if (item == NULL) {
				DECREF(list);
				list = NULL;
				break;
			}
			setlistitem(list, i, item);
		}
	}
	if (fontnames != NULL)
		XFreeFontNames(fontnames);
	return list;
}

static object *
widget_LoadQueryFont(self, args)
	widgetobject *self;
	object *args;
{
	Widget w = self->ob_widget;
	Display *display = XtDisplay(w);
	char *name;
	object *result;
	if (!getargs(args, "s", &name))
		return NULL;
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = PyFont_New(display, name);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return result;
}

/* For XtRemoveCallback to work we must "normalize" callback arguments
   so that when two callback specs are in fact the same (same function
   and same argument) then the same object is returned.  This is done
   by saving a list of all callback arguments ever received.  XXX One
   disadvantage of this approach is that items in this list will never
   be deleted, since we have no way of telling whether the toolkit still
   has a reference to them. */

object *
make_closure(cbfunc, cbarg, nbytes)
	object *cbfunc;
	object *cbarg;
	int nbytes;
{
	static object *allclosures;
	object *closure;
	int i, n;
	if (allclosures == NULL) {
		allclosures = newlistobject(0);
		if (allclosures == NULL)
			return NULL;
	}
	closure = mkvalue("(OOi)", cbfunc, cbarg, nbytes);
	if (closure == NULL)
		return NULL;
	n = getlistsize(allclosures);
	for (i = 0; i < n; i++) {
		object *item = getlistitem(allclosures, i);
		if (cmpobject(closure, item) == 0) {
			DECREF(closure);
			return item; /* No need to INCREF */
		}
	}
	if (addlistitem(allclosures, closure) == 0)
		DECREF(closure); /* It is still referenced by allclosures */
	return closure;
}

/* Save/restore jmp_buf status around call_object() */

static object *
call_object_save_jump(func, args)
	object *func;
	object *args;
{
	object *result;
	jmp_buf save_jump_where;
	int save_jump_flag;

	save_jump_flag = jump_flag;
	jump_flag = 0;
	if (save_jump_flag)
		memcpy((char *)save_jump_where,
		       (char *)jump_where, sizeof(save_jump_where));
	
	result = call_object(func, args);
	
	if (save_jump_flag)
		memcpy((char *)jump_where,
		       (char *)save_jump_where, sizeof(jump_where));
	jump_flag = save_jump_flag;
	
	return result;
}

void
univ_callback(w, closure, call_data)
	Widget w;
	XtPointer closure;
	XtPointer call_data;
{
	object *cbfunc;
	object *cbarg;
	widgetobject *wobj;
	object *warg;
	object *cbargs;
	object *result;
	int nbytes;
	if (!getargs((object*)closure, "(OOi)", &cbfunc, &cbarg, &nbytes)) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr, "--- bad closure for univ_callback ---\n");
		print_error();
		fprintf(stderr, "---\n");
		return;
	}
	wobj = newwidgetobject(w, widget_methodlists);
	warg = newsizedstringobject(call_data, nbytes);
	cbargs = mkvalue("(OOO)", wobj, cbarg, warg);
	XDECREF(wobj);
	XDECREF(warg);
	if (cbargs == NULL)
		result = NULL;
	else {
		result = call_object_save_jump(cbfunc, cbargs);
		DECREF(cbargs);
	}
	if (result == NULL) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr, "--- callback failed ---\n");
		print_error();
		fprintf(stderr, "---\n");
	}
	else
		DECREF(result);
}

void
univ_eventhandler(w, closure, call_data, continue_to_dispatch)
	Widget w;
	XtPointer closure;
	XEvent *call_data;
	Boolean *continue_to_dispatch;
{
	univ_callback(w, closure, (void *)call_data);
}

void
univ_inputhandler(closure, pfile, pid)
	XtPointer closure;
	int *pfile;
	XtInputId *pid;
{
	object *cbfunc;
	object *cbarg;
	object *warg;
	object *cbargs;
	object *result;
	if (!getargs((object *)closure, "(OO)", &cbfunc, &cbarg)) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr,
			"--- bad closure for univ_inputhandler ---\n");
		print_error();
		fprintf(stderr, "---\n");
		return;
	}
	cbargs = mkvalue("(Oii)", cbarg, *pfile, *pid);
	if (cbargs == NULL)
		result = NULL;
	else {
		result = call_object_save_jump(cbfunc, cbargs);
		DECREF(cbargs);
	}
	if (result == NULL) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr, "--- input handler failed ---\n");
		print_error();
		fprintf(stderr, "---\n");
	}
	else
		DECREF(result);
}

void
univ_timeouthandler(closure, pid)
	object *closure;
	int *pid;
{
	object *cbfunc;
	object *cbarg;
	object *warg;
	object *cbargs;
	object *result;
	if (!getargs(closure, "(OO)", &cbfunc, &cbarg)) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr,
			"--- bad closure for univ_inputhandler ---\n");
		print_error();
		fprintf(stderr, "---\n");
		return;
	}
	cbargs = mkvalue("(Oi)", cbarg, *pid);
	if (cbargs == NULL)
		result = NULL;
	else {
		result = call_object_save_jump(cbfunc, cbargs);
		DECREF(cbargs);
	}
	if (result == NULL) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr, "--- timeout handler failed ---\n");
		print_error();
		fprintf(stderr, "---\n");
	}
	else
		DECREF(result);
}

Boolean
univ_workproc(closure)
	object *closure;
{
	object *cbfunc;
	object *cbarg;
	object *warg;
	object *cbargs;
	object *result;
	int remove;
	if (!getargs(closure, "(OO)", &cbfunc, &cbarg)) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr,
			"--- bad closure for univ_workproc ---\n");
		print_error();
		fprintf(stderr, "---\n");
		return 1;
	}
	cbargs = mkvalue("(O)", cbarg);
	if (cbargs == NULL)
		result = NULL;
	else {
		result = call_object_save_jump(cbfunc, cbargs);
		DECREF(cbargs);
	}
	if (result == NULL) {
		if (jump_flag)
			longjmp(jump_where, 1);
		fprintf(stderr, "--- work proc failed ---\n");
		print_error();
		fprintf(stderr, "---\n");
		return 1;
	}
	remove = testbool(result);
	DECREF(result);
	return remove;
}

static object *
wclass_GetResourceList(self, args)
	wclassobject *self;
	object *args;
{
	XtResourceList list, p;
	Cardinal num;
	object *result;
	int i;
	if (!getargs(args, ""))
		return NULL;
	XtGetResourceList(self->ob_wclass, &list, &num);
	result = newlistobject(num);
	for (p = list, i = 0; i < num && result != NULL; p++, i++) {
		object *defval, *item;
		if (strcmp(p->default_type, "Immediate") == 0) {
			defval = xtargval2p((XtArgVal)p->default_addr,
					    p->resource_type,
					    p->resource_size);
		}
		else if (strcmp(p->default_type, "String") == 0) {
			defval = mkvalue("s", (char *)p->default_addr);
		}
		else if (strcmp(p->default_type, p->resource_type) == 0) {
			XrmValue xtvalue;
			if (strcmp(p->default_type, "XmString") == 0)
				xtvalue.addr = (XtPointer) &p->default_addr;
			else
				xtvalue.addr = p->default_addr;
			xtvalue.size = p->resource_size;
			defval = xtvalue2p(&xtvalue, p->default_type);
		}
		else {
			defval = None;
			INCREF(None);
		}
		if (defval == NULL) {
			err_clear();
			defval = None;
			INCREF(None);
		}
		item = mkvalue("(sssiisO)",
			       p->resource_name,
			       p->resource_class,
			       p->resource_type,
			       p->resource_size,
			       p->resource_offset,
			       p->default_type,
			       defval);
		XDECREF(defval);
		if (item == NULL) {
			DECREF(result);
			result = NULL;
		}
		else
			setlistitem(result, i, item);
	}
	XtFree((XtPointer)list);
	return result;
}

static object *
make_res_dict(wc)
	wclassobject *wc;
{
	XtResourceList list, p;
	Cardinal num;
	object *result;
	int i;
	XtGetResourceList(wc->ob_wclass, &list, &num);
	result = newdictobject();
	for (p = list, i = 0; i < num && result != NULL; p++, i++) {
		object *key = newstringobject(p->resource_name);
		object *type = mkvalue("(si)", p->resource_type,
				       p->resource_size);
		if (key == NULL || type == NULL ||
		    mappinginsert(result, key, type) != 0) {
			DECREF(result);
			result = NULL;
		}
		XDECREF(key);
		XDECREF(type);
	}
	XtFree((XtPointer)list);
	return result;
}

static object *
get_res_dict(wc)
	wclassobject *wc;
{
	static object *cache;
	object *dict;
	if (cache == NULL) {
		cache = newdictobject();
		if (cache == NULL)
			return NULL;
	}
	dict = mappinglookup(cache, (object *)wc);
	if (dict != NULL)
		return dict;
	dict = make_res_dict(wc);
	if (dict != NULL)
		mappinginsert(cache, (object *)wc, dict);
	return dict;
}

static object *
get_res_type(wC, name)
	WidgetClass wC;
	object *name;
{
	wclassobject *wc;
	object *dict;
	object *type;
 	wc = newwclassobject(wC, wclass_methodlists);
	if (wc == NULL)
		return NULL;
	dict = get_res_dict(wc);
	DECREF(wc);
	if (dict == NULL)
		return NULL;
	type = mappinglookup(dict, name);
	if (type == NULL)
		type = None;
	return type;
}

static char *
get_res_ctype(wC, name, p_size)
	WidgetClass wC;
	object *name;
	int *p_size;
{
	object *type = get_res_type(wC, name);
	char *ctype;
	int size;
	if (type == NULL)
		return NULL;
	if (type == None) {
		if (p_size)
			*p_size = 0;
		return "";
	}
	if (!getargs(type, "(si);bad res_dict item", &ctype, &size))
		return NULL;
	if (p_size)
		*p_size = size;
	return ctype;
}

object *
res_to_python(wC, name, value)
	WidgetClass wC;
	object *name;
	XtArgVal value;
{
	int size;
	char *ctype = get_res_ctype(wC, name, &size);
	object *v;
	if (ctype == NULL)
		return NULL;
	v = xtargval2p(value, ctype, size);
	if (v == NULL) {
		err_clear();
		v = None;
		INCREF(None);
	}
	return v;
}

int
python_to_res(wC, w, name, value, parg)
	WidgetClass wC;
	Widget w;
	object *name;
	object *value;
	XtArgVal *parg;
{
	int size;
	char *ctype;
	char *typename;
	XrmValue in, out;
	if (is_intobject(value)) {
		*parg = (XtArgVal)getintvalue(value);
		return 1;
	}
	if (is_widgetobject(value)) {
		*parg = (XtArgVal)getwidgetvalue(value);
		return 1;
	}
	ctype = get_res_ctype(wC, name, &size);
	if (ctype == NULL)
		return 0;
	if (!p2xtvalue(value, &in, &typename))
		return 0;
	out.size = 0;
	out.addr = 0;
	if (!XtConvertAndStore(w, typename, &in, ctype, &out)) {
		err_setstr(Xt_Error, "can't convert resource type");
		return 0;
	}
	if (!xtvalue2xtargval(&out, parg))
		return 0;
	return 1;
}

static void
myErrorHandler(msg)
	char *msg;
{
	if (jump_flag) {
		err_setstr(Xt_Error, msg);
		longjmp(jump_where, 1);
	}
	fatal(msg);
}

static void
myErrorMsgHandler(name, type, class, defaultp, params, num_params)
	String name, type, class, defaultp;
	String *params;
	Cardinal* num_params;
{
	char buf[1000];
	vsprintf(buf, defaultp, (XtPointer)params); /* XXX not quite */
	if (jump_flag) {
		object *val = mkvalue("(ssss)", name, type, class, buf);
		err_setval(Xt_Error, val);
		XDECREF(val);
		longjmp(jump_where, 1);
	}
	fatal(buf);
}

#ifdef USE_EDITRES
/* This requires the X11R5 include directory */
#include <X11/Xmu/Editres.h>
#endif

static object *
Xt_CreateApplicationShell(self, args)
	object *self;
	object *args;
{
	Widget result;
	Widget w;
	WidgetClass wC;
	String arg1;
	object *arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_wclassobject(arg2)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be WidgetClass");
		return NULL;
	}
	w = NULL;
	wC = getwclassvalue(arg2);
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtCreateApplicationShell(arg1,
			getwclassvalue(arg2),
			a, nargs);
#ifdef USE_EDITRES
		/* Support editres */
		XtAddEventHandler(result, (EventMask)0, 1,
				  _XEditResCheckMessages, NULL);
#endif
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
widget_CreatePopupShell(self, args)
	widgetobject *self;
	object *args;
{
	Widget result;
	Widget w = self->ob_widget;
	WidgetClass wC = XtClass(self->ob_widget);
	String arg1;
	object *arg2;
	object *arg3; ArgList a; int nargs;
	if (!getargs(args, "(sOO)",
			&arg1,
			&arg2,
			&arg3))
		return NULL;
	if (!is_wclassobject(arg2)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg2 should be WidgetClass");
		return NULL;
	}
	if (!checkargdict(wC, w, arg3, &a, &nargs)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg3 should be argdict");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		result = XtCreatePopupShell(arg1,
			getwclassvalue(arg2),
			self->ob_widget,
			a, nargs);
#ifdef USE_EDITRES
		/* Support editres */
		XtAddEventHandler(result, (EventMask)0, 1,
				  _XEditResCheckMessages, NULL);
#endif
		jump_flag = 0;
	}
	DEL(a);
	if (jump_flag) { jump_flag = 0; return NULL; }
	return (object *)newwidgetobject(result, widget_methodlists);
}

static object *
Xt_Initialize(self, args)
	object *self;
	object *args;
{
	static int been_here;
	Widget result;
	String classname;
	object *optlist;
	object *argv; char **s; int nstrs;
	char buf[1000];
	classname = NULL;
	optlist = NULL;
	argv = NULL;
	if (!getargs(args, "")) {
		err_clear();
		if (!getargs(args, "(sOO)",  &classname, &optlist, &argv))
			return NULL;
	}
	if (optlist != NULL &&
	    (!is_listobject(optlist) || getlistsize(optlist) != 0)) {
		err_setstr(TypeError, "arg 2 should be empty list (options)");
		return NULL;
	}
	if (argv == NULL) {
		argv = sysget("argv");
		if (argv == NULL) {
			err_setstr(TypeError, "can't find sys.argv");
			return NULL;
		}
	}
	if (!checkstringlist(argv, &s, &nstrs)) {
		if (!err_occurred())
			err_setstr(TypeError,
				"arg 3 should be list of strings (sys.argv)");
		return NULL;
	}
	if (nstrs > 0) {
		/* If argv[0] has a ".py" suffix, remove the suffix */
		char *p = strrchr(s[0], '.');
		if (p != NULL && strcmp(p, ".py") == 0) {
			int n = p - s[0];
			if (n >= sizeof(buf))
				n = sizeof(buf)-1;
			strncpy(buf, s[0], n);
			buf[n] = '\0';
			s[0] = buf;
		}
	}
	if (been_here++) {
		err_setstr(Xt_Error,
			   "xt.XtInitialize must be called only once");
		return NULL;
	}
	if (classname == NULL && nstrs > 0)
		classname = s[0];
	result = XtInitialize(NULL, classname, NULL, 0, &nstrs, s);
	if (!putbackstringlist(argv, s, nstrs))
		return NULL;
	DEL(s);
	XtSetErrorHandler(myErrorHandler);
	XtSetErrorMsgHandler(myErrorMsgHandler);
#ifdef USE_EDITRES
	/* Support editres for first top-level shell */
	/* This requires linking with the X11R5 -lXmu -lXt -lX11 -lXext */
	XtAddEventHandler(result, (EventMask)0, 1,
			  _XEditResCheckMessages, NULL);
#endif
	toplevel = result;
	return (object *)newwidgetobject(result, widget_methodlists);
}

#include "Xtgenerated.h"

struct methodlist *wclass_methodlists[] = {
	wclass_methods,
	0
};

struct methodlist *widget_methodlists[] = {
	widget_methods,
	0
};

void
initXt()
{
	object *m, *d;
	m = initmodule("Xt", Xt_methods);
	d = getmoduledict(m);
	dictinsert(d, "Error", Xt_Error = newstringobject("Xt.Error"));
	makewidgets(d);
}
