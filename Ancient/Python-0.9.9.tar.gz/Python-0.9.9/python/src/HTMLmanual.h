/* Manually written functions for HTML */

#if 0
/* Template */
static object *
HTML_$$(self, args)
	object *self;
	object *args;
{
	object *arg1;
	if (!getargs(args, "O", &arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		HTML$$(getwidgetvalue(arg1));
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}
#endif

static object *
HTML_GetHRefs(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char **harray;
	int count;
	object *list;
	int i;
	if (!getargs(args, "O", &arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		harray = HTMLGetHRefs(getwidgetvalue(arg1), &count);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	list = newlistobject(count);
	for (i = 0; i < count && list != NULL; i++) {
		object *item = newstringobject(harray[i]);
		if (item == NULL) {
			DECREF(list);
			list = NULL;
		}
		else
			setlistitem(list, i, item);
	}
	return list;
}

static object *
HTML_IdToPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	int arg2;
	int ret0;
	int ret1;
	int ret2;
	if (!getargs(args, "(Oi)", &arg1, &arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		ret0 = HTMLIdToPosition(getwidgetvalue(arg1), arg2,
					&ret1, &ret2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return mkvalue("(iii)", ret0, ret1, ret2);
}

static object *
HTML_AnchorToPosition(self, args)
	object *self;
	object *args;
{
	object *arg1;
	char *arg2;
	int ret0;
	int ret1;
	int ret2;
	if (!getargs(args, "(Os)", &arg1, &arg2))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		ret0 = HTMLAnchorToPosition(getwidgetvalue(arg1), arg2,
					&ret1, &ret2);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return mkvalue("(iii)", ret0, ret1, ret2);
}

static object *
HTML_SetSelection(self, args)
	object *self;
	object *args;
{
	object *arg1;
	ElementRef start, end;
	if (!getargs(args, "(O(ii)(ii))", &arg1,
		     &start.id, &start.pos, &end.id, &end.pos))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		HTMLSetSelection(getwidgetvalue(arg1), &start, &end);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	INCREF(None);
	return None;
}

static object *
HTML_SearchText(self, args)
	object *self;
	object *args;
{
	object *arg1;
	object *arg3;
	char *pattern;
	int backward, caseless, page;
	ElementRef start, end;
	if (!getargs(args, "(OsOii)",
		     &arg1, &pattern, &arg3, &backward, &caseless))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	start.id = start.pos = end.id = end.pos = 0;
	if (arg3 != None) {
		if (!getargs(arg3,
			     "(ii);start position must be None or (int, int)",
			     &start.id, &start.pos))
			return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		page = HTMLSearchText(getwidgetvalue(arg1),
				      pattern, &start, &end,
				      backward, caseless);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	return mkvalue("(i(ii)(ii))",
		       page, start.id, start.pos, end.id, end.pos);
}

static object *
HTML_GetTextAndSelection(self, args)
	object *self;
	object *args;
{
	object *arg1, *result;
	char *ret0, *ret1, *ret2, *ret3;
	int off1, off2, off3;
	if (!getargs(args, "O", &arg1))
		return NULL;
	if (!is_widgetobject(arg1)) {
		if (!err_occurred())
			err_setstr(TypeError, "arg1 should be Widget");
		return NULL;
	}
	if (!setjmp(jump_where)) {
		jump_flag = 1;
		ret0 = HTMLGetTextAndSelection(getwidgetvalue(arg1),
					       &ret1, &ret2, &ret3);
		jump_flag = 0;
	}
	if (jump_flag) { jump_flag = 0; return NULL; }
	if (ret0 == NULL)
		return err_nomem();
	off1 = off2 = off3 = -1;
	if (ret1)
		off1 = ret1-ret0;
	if (ret2)
		off2 = ret2-ret0;
	if (ret3)
		off3 = ret3-ret0;
	result = mkvalue("(siii)", ret0, off1, off2, off3);
	free(ret0);
}

static object *
HTML_cbarg(self, args)
	object *self;
	object *args;
{
	char *str;
	int len;
	WbAnchorCallbackData *cd;
	if (!getargs(args, "s#", &str, &len))
		return NULL;
	if (len != 100) {
		err_setstr(ValueError,
			   "cbarg argument must be callback's call_data");
		return NULL;
	}
	cd = (WbAnchorCallbackData *)str;
	return mkvalue("(s#iiss)",
		       (char *)cd->event,
		       sizeof(*cd->event),
		       cd->page,
		       cd->element_id,
		       cd->text,
		       cd->href);
}
