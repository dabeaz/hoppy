/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* Template for an wrapper around any kind of external object */

#ifndef EXTNAME

/* Being used stand-alone */

#include "allobjects.h"
#include "modsupport.h"

typedef struct {
	OB_HEAD
	EXTPTR ob_ptr;
	struct methodlist **ob_methodlists;
} extobject;

#endif

#ifndef EXTNAME
#define EXTNAME "ext"
#endif

#ifndef EXTPTR
#ifdef __STDC__
typedef void *EXTPTR;
#else
typedef char *EXTPTR;
#endif
#endif

/* Other names to redefine when used as a template:
   extobject, ob_ptr, newextobject, getextvalue, ext_forget, Exttype */

/* Possibly also redefine ext_getattr, ext_setattr */

#ifndef ext_getattr
#define ext_getattr default_ext_getattr
#endif

#ifndef ext_setattr
#define ext_setattr 0
#endif

static object *extknown;

extern typeobject Exttype;

#define is_extobject(xp)	((xp)->ob_type == &Exttype)

extobject *
newextobject(ptr, methodlists)
	EXTPTR ptr;
	struct methodlist **methodlists;
{
	extobject *xp;
	object *key;
	if (extknown == NULL) {
		extknown = newdictobject();
		if (extknown == NULL)
			return NULL;
	}
	key = newintobject((long)ptr);
	if (key == NULL)
		return NULL;
	xp = (extobject *)dict2lookup(extknown, key);
	if (xp != NULL) {
		INCREF(xp);
		goto done;
	}
	xp = NEWOBJ(extobject, &Exttype);
	if (xp == NULL)
		goto done;
	xp->ob_ptr = ptr;
	xp->ob_methodlists = methodlists;
	if (dict2insert(extknown, key, (object *)xp) != 0) {
		DECREF(xp);
		xp = NULL;
	}
 done:
	DECREF(key);
	return xp;
}

static void
ext_dealloc(xp)
	extobject *xp;
{
	DEL(xp);
}

static int
_ext_forget(xp)
	extobject *xp;
{
	object *key = newintobject((long)xp->ob_ptr);
	int res;
	if (key == NULL)
		return -1;
	res = dict2remove(extknown, key);
	DECREF(key);
	return res;
}

EXTPTR
getextvalue(xp)
	object *xp;
{
	if (xp && is_extobject(xp))
		return ((extobject *)xp)->ob_ptr;
	err_badcall();
	return NULL;
}

int
ext_forget(xp)
	object *xp;
{
	if (xp && is_extobject(xp))
		return _ext_forget((extobject *)xp);
	err_badcall();
	return -1;
}

static object *
ext___forget__(xp)
	extobject *xp;
{
	if (_ext_forget(xp) != 0)
		return NULL;
	INCREF(None);
	return None;
}

static struct methodlist ext_methods[] = {
	{"__forget__",	ext___forget__},
	{NULL,		NULL}		/* sentinel */
};

static object *
default_ext_getattr(xp, name)
	extobject *xp;
	char *name;
{
	object *res;
	struct methodlist **pm;
	for (pm = xp->ob_methodlists; *pm != NULL; pm++) {
		res = findmethod(*pm, (object *)xp, name);
		if (res != NULL)
			return res;
		err_clear();
	}
	return findmethod(ext_methods, (object *)xp, name);
}

typeobject Exttype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	EXTNAME,		/*tp_name*/
	sizeof(extobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	ext_dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	ext_getattr,		/*tp_getattr*/
	ext_setattr,		/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
	0,			/*tp_hash*/
};
