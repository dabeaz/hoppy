/* Widget Set Xaw */

#include "allobjects.h"
#include "modsupport.h"
#include "widgetobject.h"


/* Methods for Xaw objects */

#include <X11/Xaw/Box.h>

#include <X11/Xaw/Clock.h>

#include <X11/Xaw/Command.h>

#include <X11/Xaw/Dialog.h>

#include <X11/Xaw/Form.h>

#include <X11/Xaw/Grip.h>

#include <X11/Xaw/Label.h>

#include <X11/Xaw/List.h>

#include <X11/Xaw/Logo.h>

#include <X11/Xaw/Mailbox.h>

#include <X11/Xaw/MenuButton.h>

#include <X11/Xaw/Paned.h>

#include <X11/Xaw/Panner.h>

#include <X11/Xaw/Porthole.h>

#include <X11/Xaw/Repeater.h>

#include <X11/Xaw/Scrollbar.h>

#include <X11/Xaw/Simple.h>

#include <X11/Xaw/SimpleMenu.h>

#include <X11/Xaw/StripChart.h>

#include <X11/Xaw/Text.h>

#include <X11/Xaw/Toggle.h>

#include <X11/Xaw/Tree.h>

#include <X11/Xaw/Viewport.h>

struct methodlist Xaw_methods[] = {
	{0, 0} /* Sentinel */
};


/* Methods for Xawwc objects */

struct methodlist Xawwc_methods[] = {
	{0, 0} /* Sentinel */
};


/* Methods for Xaww objects */

struct methodlist Xaww_methods[] = {
	{0, 0} /* Sentinel */
};


struct methodlist *Xaww_methodlists[] = {
	Xaww_methods,
	0
};

void
initXaw()
{
	object *m, *d;
	m = initmodule("Xaw", Xaw_methods);
	d = getmoduledict(m);
	dictinsert(d, "Box",
		(object*)newwclassobject(boxWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Clock",
		(object*)newwclassobject(clockWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Command",
		(object*)newwclassobject(commandWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Dialog",
		(object*)newwclassobject(dialogWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Form",
		(object*)newwclassobject(formWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Grip",
		(object*)newwclassobject(gripWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Label",
		(object*)newwclassobject(labelWidgetClass,
			wclass_methodlists));
	dictinsert(d, "List",
		(object*)newwclassobject(listWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Logo",
		(object*)newwclassobject(logoWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Mailbox",
		(object*)newwclassobject(mailboxWidgetClass,
			wclass_methodlists));
	dictinsert(d, "MenuButton",
		(object*)newwclassobject(menuButtonWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Paned",
		(object*)newwclassobject(panedWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Panner",
		(object*)newwclassobject(pannerWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Porthole",
		(object*)newwclassobject(portholeWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Repeater",
		(object*)newwclassobject(repeaterWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Scrollbar",
		(object*)newwclassobject(scrollbarWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Simple",
		(object*)newwclassobject(simpleWidgetClass,
			wclass_methodlists));
	dictinsert(d, "SimpleMenu",
		(object*)newwclassobject(simpleMenuWidgetClass,
			wclass_methodlists));
	dictinsert(d, "StripChart",
		(object*)newwclassobject(stripChartWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Text",
		(object*)newwclassobject(textWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Toggle",
		(object*)newwclassobject(toggleWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Tree",
		(object*)newwclassobject(treeWidgetClass,
			wclass_methodlists));
	dictinsert(d, "Viewport",
		(object*)newwclassobject(viewportWidgetClass,
			wclass_methodlists));
}
