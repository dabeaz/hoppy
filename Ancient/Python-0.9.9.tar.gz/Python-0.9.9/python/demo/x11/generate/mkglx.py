#! /ufs/guido/bin/sgi/python

from mktools import *

widgetset('Glx', 'Glxw', 'Glxwc', '<X11/Xirisw/Glx%s.h>', 'glx%s', 'Glx')

write('#include "Glxsupport.h"\n')

setmoduleprefix()

dowidget('Draw', 'Draw')
#dowidget('MDraw', 'MDraw')
myfunction('void', 'winset', 'Widget')
myfunction('int', 'makeconfig', 'list')

dolist()

setwclassprefix()
dolist()

setwidgetprefix()
dolist()

initextras.append('initglxsupport();')

endwidgetset()
