#! /ufs/guido/bin/sgi/python

import os
if os.environ.has_key('MOTIFVERSION'):
	MOTIFVERSION = eval(os.environ['MOTIFVERSION'])
else:
	MOTIFVERSION = 1.1

from mktools import *

def xmcreate(name):
	dofunction('Widget', 'XmCreate%s' % name,
		  'Widget', 'String', 'argdict')

def xmwidget(name, fname):
	dowidget(name, fname)
	xmcreate(name)

widgetset('Xm', 'Xmw', 'Xmwc', '<Xm/%s.h>', 'xm%s', 'Xm')

write('#include "Xmsupport.h"\n')

setmoduleprefix()

xmwidget('ArrowButton', 'ArrowB')
dogadget('ArrowButton', 'ArrowBG')

xmwidget('BulletinBoard', 'BulletinB')
xmcreate('BulletinBoardDialog')

xmwidget('CascadeButton', 'CascadeB')
dogadget('CascadeButton', 'CascadeBG')

xmwidget('Command', 'Command')
dofunction('void', 'XmCommandError', 'Widget', 'XmString')
dofunction('void', 'XmCommandAppendValue', 'Widget', 'XmString')
dofunction('void', 'XmCommandSetValue', 'Widget', 'XmString')

xmwidget('DialogShell', 'DialogS')

xmwidget('DrawingArea', 'DrawingA')

xmwidget('DrawnButton', 'DrawnB')

xmwidget('FileSelectionBox', 'FileSB')
xmcreate('FileSelectionDialog')
dofunction('void', 'XmFileSelectionDoSearch', 'Widget', 'XmString')

xmwidget('Form', 'Form')
xmcreate('FormDialog')

xmwidget('Frame', 'Frame')

xmwidget('Label', 'Label')
dogadget('Label', 'LabelG')

xmwidget('List', 'List')

xmwidget('MainWindow', 'MainW')

xmwidget('MenuShell', 'MenuShell')

xmwidget('MessageBox', 'MessageB')
xmcreate('ErrorDialog')
xmcreate('InformationDialog')
xmcreate('MessageDialog')
xmcreate('QuestionDialog')
xmcreate('WarningDialog')
xmcreate('WorkingDialog')

xmwidget('PanedWindow', 'PanedW')

xmwidget('PushButton', 'PushB')
dogadget('PushButton', 'PushBG')

xmwidget('RowColumn', 'RowColumn')
xmcreate('MenuBar')
xmcreate('OptionMenu')
xmcreate('PopupMenu')
xmcreate('PulldownMenu')
xmcreate('RadioBox')

xmwidget('Scale', 'Scale')

xmwidget('ScrollBar', 'ScrollBar')
xmcreate('ScrolledList')

xmwidget('ScrolledWindow', 'ScrolledW')
dofunction('void', 'XmScrolledWindowSetAreas',
	  'Widget', 'Widget', 'Widget', 'Widget')

xmwidget('SelectionBox', 'SelectioB')
xmcreate('PromptDialog')
xmcreate('SelectionDialog')

xmwidget('Separator', 'Separator')
dogadget('Separator', 'SeparatoG')

xmwidget('Text', 'Text')
xmcreate('ScrolledText')

xmwidget('ToggleButton', 'ToggleB')
dofunction('Boolean', 'XmToggleButtonGetState', 'Widget')
dofunction('void', 'XmToggleButtonSetState', 'Widget', 'Boolean', 'Boolean')

dogadget('ToggleButton', 'ToggleBG')
dofunction('Boolean', 'XmToggleButtonGadgetGetState', 'Widget')
dofunction('void', 'XmToggleButtonGadgetSetState',
	  'Widget', 'Boolean', 'Boolean')

if MOTIFVERSION >= 1.1:
	xmcreate('SimpleMenuBar')
	xmcreate('SimpleOptionMenu')
	xmcreate('SimplePopupMenu')
	xmcreate('SimplePulldownMenu')
	xmcreate('SimpleRadioBox')
	xmwidget('TextField', 'TextF')
	xmcreate('WorkArea')

if MOTIFVERSION >= 1.2:
	xmwidget('DragIcon', 'DragIcon')
	xmcreate('TemplateDialog')

dofunction('void', 'XmMenuPosition', 'Widget', 'Event*')

# Xm*GetChild family
dofunction('Widget', 'XmCommandGetChild', 'Widget', 'int')
dofunction('Widget', 'XmFileSelectionBoxGetChild', 'Widget', 'int')
dofunction('Widget', 'XmMessageBoxGetChild', 'Widget', 'int')
dofunction('Widget', 'XmSelectionBoxGetChild', 'Widget', 'int')

# XmText and XmTextField access functions
def xmtextfunc(returntype, name, *args):
	apply(dofunction, (returntype, 'XmText'+name)+args)
	if MOTIFVERSION >= 1.1:
		apply(dofunction, (returntype, 'XmTextField'+name)+args)
xmtextfunc('void', 'ClearSelection', 'Widget', 'Time')
xmtextfunc('Boolean', 'GetEditable', 'Widget')
xmtextfunc('XmTextPosition', 'GetInsertionPosition', 'Widget')
xmtextfunc('XmTextPosition', 'GetLastPosition', 'Widget')
xmtextfunc('int', 'GetMaxLength', 'Widget')
xmtextfunc('String', 'GetSelection', 'Widget')
#xmtextfunc('Boolean', 'GetSelectionPosition',
#	   'Widget', '>XmTextPosition', '>XmTextPosition')
#xmtextfunc('XmTextSource', 'GetSource', 'Widget')
xmtextfunc('String', 'GetString', 'Widget')
#xmtextfunc('Boolean', 'PosToXY',
#	   'Widget', 'XmTextPosition', '>Position', '>Position')
xmtextfunc('void', 'Replace',
	   'Widget', 'XmTextPosition', 'XmTextPosition', 'String')
dofunction('void', 'XmTextScroll', 'Widget', 'int')
xmtextfunc('void', 'SetEditable', 'Widget', 'Boolean')
xmtextfunc('void', 'SetInsertionPosition', 'Widget', 'XmTextPosition')
xmtextfunc('void', 'SetMaxLength', 'Widget', 'int')
xmtextfunc('void', 'SetSelection',
	   'Widget', 'XmTextPosition', 'XmTextPosition', 'Time')
#xmtextfunc('void', 'SetSource',
#	   'Widget', 'XmTextSource', 'XmTextPosition', 'XmTextPosition')
xmtextfunc('void', 'SetString', 'Widget', 'String')
xmtextfunc('void', 'ShowPosition', 'Widget', 'XmTextPosition')
xmtextfunc('XmTextPosition', 'XYToPos',
	   'Widget', 'Position', 'Position')
if MOTIFVERSION >= 1.1:
	xmtextfunc('Boolean', 'Copy', 'Widget', 'Time')
	xmtextfunc('Boolean', 'Cut', 'Widget', 'Time')
	xmtextfunc('int', 'GetBaseline', 'Widget')
	dofunction('XmTextPosition', 'XmTextGetTopCharacter', 'Widget')
	xmtextfunc('void', 'Insert', 'Widget', 'XmTextPosition', 'String')
	xmtextfunc('void', 'SetAddMode', 'Widget', 'Boolean')
	xmtextfunc('void', 'SetHighlight',
	  'Widget', 'XmTextPosition', 'XmTextPosition', 'XmHighlightMode')
	xmtextfunc('Boolean', 'Paste', 'Widget')
	xmtextfunc('Boolean', 'Remove', 'Widget')
	dofunction('void', 'XmTextSetTopCharacter', 'Widget', 'XmTextPosition')
	

# XmList functions
dofunction('void', 'XmListAddItem', 'Widget', 'XmString', 'int')
#dofunction('void', 'XmListAddItems', 'Widget', 'XmStringList', 'int')
dofunction('void', 'XmListAddItemUnselected', 'Widget', 'XmString', 'int')
dofunction('void', 'XmListDeleteItem', 'Widget', 'XmString')
#dofunction('void', 'XmListDeleteItems', 'Widget', 'XmStringList')
dofunction('void', 'XmListDeletePos', 'Widget', 'int')
dofunction('void', 'XmListDeselectAllItems', 'Widget')
dofunction('void', 'XmListDeselectItem', 'Widget', 'XmString')
dofunction('void', 'XmListDeselectPos', 'Widget', 'int')
#myfunction('Boolean', 'XmListGetMatchPos',
#	   'Widget', 'XmString', '>intlist')
dofunction('Boolean', 'XmListItemExists', 'Widget', 'XmString')
#dofunction('void', 'XmListReplaceItems', 'Widget', 'WidgetList', 'WidgetList')
#dofunction('void', 'XmListReplaceItemsPos',
#	  'Widget', 'WidgetList', int)
dofunction('void', 'XmListSelectItem', 'Widget', 'XmString', 'Boolean')
dofunction('void', 'XmListSelectPos', 'Widget', 'int', 'Boolean')
dofunction('void', 'XmListSetBottomItem', 'Widget', 'XmString')
dofunction('void', 'XmListSetBottomPos', 'Widget', 'int')
dofunction('void', 'XmListSetHorizPos', 'Widget', 'int')
dofunction('void', 'XmListSetItem', 'Widget', 'XmString')
dofunction('void', 'XmListSetPos', 'Widget', 'int')
if MOTIFVERSION >= 1.1:
	dofunction('void', 'XmListDeleteAllItems', 'Widget')
	dofunction('void', 'XmListDeleteItemsPos', 'Widget', 'int', 'int')
	myfunction('Boolean', 'XmListGetSelectedPos', 'Widget', '>intlist')
	dofunction('int', 'XmListItemPos', 'Widget', 'XmString')
	dofunction('void', 'XmListSetAddMode', 'Widget', 'Boolean')


dolist()

setwclassprefix()
dolist()

setwidgetprefix()
dolist()

initextras.append('initxmsupport();')

endwidgetset()
