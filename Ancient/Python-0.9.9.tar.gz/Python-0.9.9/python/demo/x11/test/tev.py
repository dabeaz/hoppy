# test event handlers

from newdir import dir
import sys
import Xt
import Xm
import X
import XEvent

def handler(w, closure, event, *rest):
	e = XEvent.mkevent(event)
	for name in dir(e):
		if name <> 'init': print name, '=', getattr(e, name),
	print

t = Xt.Initialize('T', [], sys.argv)
t.AddEventHandler(X.ExposureMask, 1, handler, None)
t.geometry = '+100+100'

l = Xm.CreateLabel(t, 'l', {})
l.AddEventHandler(X.ExposureMask, 1, handler, None)
l.ManageChild()

t.RealizeWidget()
Xt.MainLoop()
