# Test Xt.AddTimeOut

import Xt
import sys

def main():
	t = Xt.Initialize('T', [], sys.argv)
	id = Xt.AddTimeOut(1000, f, 10)
	Xt.MainLoop()

ncalls = 0

def f(udata, id):
	global ncalls
	print ncalls, udata, id
	ncalls = ncalls + 1
	if ncalls != udata:
		id = Xt.AddTimeOut(1000, f, udata)

main()
