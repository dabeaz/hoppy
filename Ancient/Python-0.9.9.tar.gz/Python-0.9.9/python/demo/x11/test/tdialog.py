
import os
import sys

import Xt
import Xm
import Xmd



def main():
	shell = Xt.Initialize()
	#
	args = {}
	args['orientation'] = Xmd.VERTICAL
	args['packing'] = Xmd.PACK_COLUMN
	args['numColumns'] = 2
	args['isAligned'] = 0
	rc = Xm.CreateRowColumn(shell, 'rc', args)
	rc.ManageChild()
	#
	for label in 'aap', 'noot', 'mies met de lange naam':
		args = {}
		args['alignment'] = Xmd.ALIGNMENT_BEGINNING
		w = Xm.CreateLabel(rc, label, args)
		w.labelString = label
		w.ManageChild()
	#
	for label in 'aap', 'noot', 'mies':
		args = {}
		args['columns'] = 1
		w = Xm.CreateTextField(rc, label + 'Text', args)
		Xm.TextFieldSetString(w, label)
		w.ManageChild()
	#
	shell.RealizeWidget()
	Xt.MainLoop()

main()
