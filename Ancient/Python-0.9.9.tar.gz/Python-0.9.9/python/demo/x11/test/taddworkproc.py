# Test Xt.AddWorkProc

import Xt
import sys

def main():
	t = Xt.Initialize('T', [], sys.argv)
	id = Xt.AddWorkProc(f, 10)
	Xt.MainLoop()

ncalls = 0

def f(udata):
	global ncalls
	print ncalls, udata
	ncalls = ncalls + 1
	return ncalls == udata

main()
