import sys, os, Xt, Xm

def main():
	# Create 2 toplevel widgets (2 windows)

	toplevel1 = Xt.Initialize('Twoshells', [], sys.argv)
	toplevel2 = Xt.CreateApplicationShell('Window2', Xt.TopLevelShell, {})

	# Set width and height

	toplevel1.SetValues({'width': 200, 'height': 300})
	toplevel2.SetValues({'width': 200, 'height': 300})

	# Create a XmLabel widget as a child of each shell

	bb1 = toplevel1.CreateManagedWidget('board1', Xm.Label, {})
	bb2 = toplevel2.CreateManagedWidget('board2', Xm.Label, {})

	# Realize the widgets and enter the main loop

	toplevel1.RealizeWidget()
	toplevel2.RealizeWidget()
	Xt.MainLoop()

main()
