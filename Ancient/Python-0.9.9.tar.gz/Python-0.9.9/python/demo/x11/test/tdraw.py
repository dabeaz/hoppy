import Xt
import Xm

import X
import Xmd

import XEvent

import sys
import os
import string

boxes = []
rects = []

def cb_expose(widget, userdata, calldata):
	gc = widget.GetGC({})
	gc.DrawRectangles(rects)
	for x, y, width, height, label in boxes:
		gc.DrawString(x+2, y+height-2, label)

def cb_button(widget, userdata, event):
	event = XEvent.mkevent(event)
	mx, my = event.x, event.y
	hits = 0
	for x, y, width, height, label in boxes:
		if x <= mx < x+width and y <= my < y+height:
			print label
			hits = hits+1
	if hits == 1:
		for i in range(len(boxes)):
			x, y, width, height, label = boxes[i]
			x = (x + 97)%400
			y = (y + 71)%300
			boxes[i] = x, y, width, height, label
			rects[i] = x, y, width, height
		widget.UnmanageChild()
		widget.ManageChild()

def main():
	shell = Xt.Initialize()
	#
	args = {}
	args['width'] = 400 + 160
	args['height'] = 300 + 20
	draw = Xm.CreateDrawingArea(shell, 'draw', args)
	draw.AddCallback('exposeCallback', cb_expose, None)
	draw.AddEventHandler(X.ButtonReleaseMask, 0, cb_button, None)
	draw.ManageChild()
	#
	x, y, width, height, label = 20, 20, 160, 20, 'hello world'
	for i in range(300):
		boxes.append(x, y, width, height, label + `i`)
		rects.append(x, y, width, height)
		x = (x + 79) % 400
		y = (y + 83) % 300
	#
	shell.RealizeWidget()
	Xt.MainLoop()

main()
