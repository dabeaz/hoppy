import sys
import gl
import Glx
import Xt
import time

top = Xt.Initialize('GL', [], sys.argv)
g = top.CreateManagedWidget('g', Glx.Draw, {})
top.SetValues({'width': 120, 'height': 90})

def cb_ginit(*args):
	gl.winget()
	print 'ginit callback'

color = 0

def cb_expose(*args):
	global color
	color = (color+1) % 8
	gl.winget()
	print 'expose callback'
	gl.reshapeviewport()
	gl.color(color)
	gl.clear()

def cb_resize(*args):
	gl.winget()
	print 'resize callback'

def cb_input(*args):
	gl.winget()
	print 'input callback', args

g.AddCallback('ginitCallback', cb_ginit, 0)
g.AddCallback('exposeCallback', cb_expose, 0)
g.AddCallback('resizeCallback', cb_resize, 0)
g.AddCallback('inputCallback', cb_input, 0)

g.overlayWindow, g.popupWindow, g.underlayWindow

top.RealizeWidget()

Xt.MainLoop()
