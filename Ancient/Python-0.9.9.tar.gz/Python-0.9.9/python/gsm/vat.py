# VAT packet header (0 is MSB):
#
#  0                   1                   2                   3   
#  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# | V |           |T|   |         |                               |
# | e |    NSID   |S| 0 |  Audio  |        Conference ID          |
# | r |           | |   | Format  |                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# |                 Time Stamp (in audio samples)                 |
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#
#  protocol version (2 bits)
#  no. of speaker id's (6 bits) [= 0 if src address should be used as id]
#  flags (3 bits)
#  audio format (5 bits)
#  conference identifier (16 bits)
#  timestamp [in audio samples] (32 bits)
#  <0 to 63 4-byte speaker id's>
#  <audio data>

# Audio formats
AUDF_MULAW8      = 0       # 64 kb/s 8KHz mu-law encoded PCM
AUDF_CELP        = 1       # 4.8 kb/s FED-STD-1016 CELP
AUDF_G721        = 2       # 32 kb/s CCITT ADPCM
AUDF_GSM         = 3       # 13 kb/s GSM
AUDF_G723        = 4       # 24 kb/s CCITT ADPCM
AUDF_LPC4        = 28      # 4.8 kb/s LPC, 4 frames
AUDF_LPC1        = 29      # 4.8 kb/s LPC, 1 frame
AUDF_IDVI        = 30      # 32 kb/s Intel DVI ADPCM
AUDF_UNDEF       = 31      # undefined

# Control message types
CTRL_TYPE_ID     = 1
CTRL_TYPE_DONE   = 2
CTRL_TYPE_IDLIST = 3
