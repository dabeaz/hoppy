# Listen to a VAT protocol audio multicast transmission encoded using GSM.
# Argument is pair of group and port (that's two arguments!).
# Interrupt or kill it to stop listening.


# XXX To do:
# - support other audio encodings
# - listen on companion port for participant announcements
# - support multiple conferences
# - improve printed info
# - etc.


import sys
import os
import string
import select
import socket
import nis
import gsm
import al
import AL
import struct
from vat import *
import getopt


def main():
	# Get options
	debug = 0
	noaudio = 0
	opts, args = getopt.getopt(sys.argv[1:], 'dn')
	for o, a in opts:
		if o == '-d':
			debug = debug + 1
		if o == '-n':
			noaudio = 1
	#
	# Set default arguments (RIPE Prague meeting)
	if not args:
		args = ['224.0.1.10', '4100']
	#
	# Parse arguments, open sockets
	socklist = [] # List of sockets
	idlist = [] # List of corresponding (group, port) pairs
	for i in range(0, len(args)-1, 2):
		group = args[i]
		port = string.atoi(args[i+1])
		try:
			s = openmcastsock(group, port)
		except socket.error, msg:
			print group, port, ':', msg
			continue
		socklist.append(s)
		idlist.append((group, port))
	#
	# Give up if no sockets opened
	if not socklist:
		print 'No valid "group port" arguments'
		sys.exit(1)
	#
	if not noaudio:
		#
		# Save audio rate and install cleanup handler to restore it
		global dev, saveparams
		dev = AL.DEFAULT_DEVICE
		saveparams = [AL.OUTPUT_RATE, 0]
		sys.exitfunc = cleanup
		# Set audio device to 8 kHz
		al.getparams(dev, saveparams)
		params = [AL.OUTPUT_RATE, AL.RATE_8000]
		al.setparams(dev, params)
		#
		# Open audio port
		c = al.newconfig()
		c.setchannels(AL.MONO)
		c.setwidth(AL.SAMPLE_16)
		c.setqueuesize(16000)
		p = al.openport('GSM audio', 'w', c)
		#
		# Create GSM decoding object
		g = gsm.create()
	#
	# Init state variables
	lastsender = None # Sender of most recently received packet
	packets = 0 # Packet count
	prevt = 0 # Previous timestamp (in msecs)
	#
	# Main loop -- handle packets as they come in...
	while 1:
		# Block until something is available
		set1, set2, set3 = select.select(socklist, [], [])
		# Handle all sockets that have something available
		for s in set1:
			i = socklist.index(s)
			data, sender = s.recvfrom(1500)
			if sender <> lastsender:
				# Print where the packets are now coming from
				lastsender = sender
				host, port = sender
				try:
					host = nis.match(host, 'hosts.byaddr')
				except nis.error:
					pass
				print host, port
			packets = packets + 1 # Count packets
			# Decode the header
			b1, b2, confid, stamp = struct.unpack('bbhl', data[:8])
			version = (b1>>6) & 0x03 # protocol version
			if version <> 0:
				print 'version not 0 but', version
				continue
			nsid = b1 & 0x3f # number of speaker ids after header
			ts = (b2>>7) & 0x01 # time stamp
			format = b2 & 0x1f # audio format
			if format <> AUDF_GSM:
				print 'audio format not GSM but', format
				continue
			t = (stamp>>5) & 0x07ffffff # convert to msec
			dt = (t - prevt) & 0x07ffffff # time difference
			prevt = t # save current time for next round
			# Compute #missed samples; never more than 1 second
			missed = min((dt-20)*8, 8000)
			if missed > 0:
				# missed some samples
				if debug: print 'padding', missed, 'samples'
				if not noaudio:
					p.writesamps('\0\0' * missed)
			# Decode and play the GSM frames
			i = 8 + 4*nsid
			while i+33 <= len(data):
				frame = data[i:i+33]
				if noaudio:
					print 'frame:', `frame`
				else:
					samples = g.decode(frame)
					p.writesamps(samples)
				i = i+33
			# Check if we have leftover data in the packet
			remains = data[i:]
			if remains:
				print 'leftover bytes:', `remains`


# Cleanup function -- reset audio output rate
def cleanup():
	al.setparams(dev, saveparams)


# Open a UDP socket, bind it to a port and select a multicast group
def openmcastsock(group, port):
	# Import modules used only here
	import regsub
	import socket
	import struct
	from SOCKET import *
	from IN import *
	#
	# Create a socket
	s = socket.socket(AF_INET, SOCK_DGRAM)
	#
	# Bind it to the port
	s.bind('', port)
	#
	# Look up multicast group address in name server
	# (doesn't hurt if it is already in ddd.ddd.ddd.ddd format)
	group = socket.gethostbyname(group)
	#
	# Construct binary group address
	bytes = eval(regsub.gsub('\.', ',', group))
	grpaddr = 0
	for byte in bytes: grpaddr = (grpaddr << 8) | byte
	#
	# Construct struct mreq from grpaddr and ifaddr
	ifaddr = INADDR_ANY
	mreq = struct.pack('ll', grpaddr, ifaddr)
	#
	# Add group membership
	s.setsockopt(IPPROTO_IP, IP_ADD_MEMBERSHIP, mreq)
	#
	return s


main()
