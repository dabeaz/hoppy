# Spy on a list of multicast transmissions.
# Arguments are pairs of group and port (that's two arguments per pair!)

import sys
import string
import select
import socket
import nis

def main():
	socklist = []
	idlist = []
	for i in range(1, len(sys.argv)-1, 2):
		group = sys.argv[i]
		port = string.atoi(sys.argv[i+1])
		try:
			s = openmcastsock(group, port)
		except socket.error, msg:
			print group, port, ':', msg
			continue
		socklist.append(s)
		idlist.append((group, port))
	#
	if not socklist:
		print 'No valid "group port" arguments'
		sys.exit(1)
	#
	seen = {}
	try:
		while 1:
			set1, set2, set3 = select.select(socklist, [], [])
			for s in set1:
				i = socklist.index(s)
				data, sender = s.recvfrom(1500)
				host = sender[0]
				try:
					host = nis.match(host, 'hosts.byaddr')
					host = string.split(host)[1]
				except nis.error:
					pass
				if data[:4] == '\0\1\0\0':
					data = data[4:]
					if '\0' in data:
						j = string.index(data, '\0')
						data = data[:j]
				elif data[:1] == '\300': data = data[1:]
				if '\0' not in data:
					if seen.has_key(data): continue
					seen[data] = host
				print idlist[i][1], host,
				rdata = `data`
				print rdata[:40]
	except KeyboardInterrupt:
		print '---------- Users seen ----------'
		users = seen.keys()
		users.sort()
		for user in users:
			print `user`, seen[user]


# Open a UDP socket, bind it to a port and select a multicast group
def openmcastsock(group, port):
	# Import modules used only here
	import regsub
	import socket
	import struct
	from SOCKET import *
	from IN import *
	#
	# Create a socket
	s = socket.socket(AF_INET, SOCK_DGRAM)
	#
	# Allow multiple copies of this program on one machine
	# (not strictly needed)
	s.setsockopt(SOL_SOCKET, SO_REUSEPORT, 1)
	#
	# Bind it to the port
	s.bind('', port)
	#
	# Look up multicast group address in name server
	# (doesn't hurt if it is already in ddd.ddd.ddd.ddd format)
	group = socket.gethostbyname(group)
	#
	# Construct binary group address
	bytes = eval(regsub.gsub('\.', ',', group))
	grpaddr = 0
	for byte in bytes: grpaddr = (grpaddr << 8) | byte
	#
	# Construct struct mreq from grpaddr and ifaddr
	ifaddr = INADDR_ANY
	mreq = struct.pack('ll', grpaddr, ifaddr)
	#
	# Add group membership
	s.setsockopt(IPPROTO_IP, IP_ADD_MEMBERSHIP, mreq)
	#
	return s


main()
