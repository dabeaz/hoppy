/***********************************************************
Copyright 1991, 1992, 1993 by Stichting Mathematisch Centrum,
Amsterdam, The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior permission.

STICHTING MATHEMATISCH CENTRUM DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH CENTRUM BE LIABLE
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

/* GSM audio compression module */

#include "allobjects.h"
#include "modsupport.h"

#include "gsm.h"

typedef struct {
	OB_HEAD
	gsm g_handle;
} gsmobject;

extern typeobject Gsmtype;	/* Really static, forward */

#define is_gsmobject(v)		((v)->ob_type == &Gsmtype)

static gsmobject *
newgsmobject()
{
	gsmobject *xp;
	xp = NEWOBJ(gsmobject, &Gsmtype);
	if (xp == NULL)
		return NULL;
	xp->g_handle = gsm_create();
	if (xp->g_handle == NULL) {
		DEL(xp);
		return NULL;
	}
	return xp;
}

/* Gsm methods */

static void
g_dealloc(xp)
	gsmobject *xp;
{
	if (xp->g_handle != NULL)
		gsm_destroy(xp->g_handle);
	DEL(xp);
}

static object *
g_encode(self, args)
	gsmobject *self;
	object *args;
{
	char *sample;
	int nbytes;
	object *result;
	if (!getargs(args, "s#", &sample, &nbytes))
		return NULL;
	if (nbytes != 320) {
		err_setstr(ValueError,
			   "gsm.encode input must be 160 2-byte samples");
		return NULL;
	}
	result = newsizedstringobject((char *)NULL, sizeof(gsm_frame));
	if (result == NULL)
		return NULL;
	gsm_encode(self->g_handle, (gsm_signal *)sample,
		   (gsm_byte *) getstringvalue(result));
	return result;
}

static object *
g_decode(self, args)
	gsmobject *self;
	object *args;
{
	char *buf;
	int nbytes;
	object *result;
	if (!getargs(args, "s#", &buf, &nbytes))
		return NULL;
	if (nbytes != 33) {
		err_setstr(ValueError, "gsm.encode input must be 33 bytes");
		return NULL;
	}
	result = newsizedstringobject((char *)NULL, 320);
	if (result == NULL)
		return NULL;
	gsm_decode(self->g_handle, (gsm_byte *)buf,
		   (gsm_signal *)getstringvalue(result));
	return result;
}

static struct methodlist g_methods[] = {
	{"encode",	g_encode},
	{"decode",	g_decode},
	{NULL,		NULL}		/* sentinel */
};

static object *
g_getattr(xp, name)
	gsmobject *xp;
	char *name;
{
	return findmethod(g_methods, (object *)xp, name);
}

static typeobject Gsmtype = {
	OB_HEAD_INIT(&Typetype)
	0,			/*ob_size*/
	"gsm",			/*tp_name*/
	sizeof(gsmobject),	/*tp_size*/
	0,			/*tp_itemsize*/
	/* methods */
	g_dealloc,		/*tp_dealloc*/
	0,			/*tp_print*/
	g_getattr,		/*tp_getattr*/
	0,			/*tp_setattr*/
	0,			/*tp_compare*/
	0,			/*tp_repr*/
	0,			/*tp_as_number*/
	0,			/*tp_as_sequence*/
	0,			/*tp_as_mapping*/
};


static object *
g_create(self, args)
	object *self; /* Not used */
	object *args;
{
	return (object *) newgsmobject();
}


/* List of functions defined in the module */

static struct methodlist gsm_methods[] = {
	{"create",	g_create},
	{NULL,		NULL}		/* sentinel */
};


/* Initialize module gsm */

void
initgsm()
{
	initmodule("gsm", gsm_methods);
}
