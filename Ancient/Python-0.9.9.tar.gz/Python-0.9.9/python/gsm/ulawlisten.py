# Listen to an audio multicast transmission (using U-LAW).
# Argument is pair of group and port (that's two arguments!).
# The output is piped through playulaw.

import sys
import os
import string
import select
import socket
import nis

PLAYULAW = '/usr/local/radio/bin/playulaw'

def main():
	socklist = []
	idlist = []
	if len(sys.argv) <= 1:
		sys.argv.append('224.0.1.10')
		sys.argv.append('4100')
	for i in range(1, len(sys.argv)-1, 2):
		group = sys.argv[i]
		port = string.atoi(sys.argv[i+1])
		try:
			s = openmcastsock(group, port)
		except socket.error, msg:
			print group, port, ':', msg
			continue
		socklist.append(s)
		idlist.append((group, port))
	#
	if not socklist:
		print 'No valid "group port" arguments'
		sys.exit(1)
	#
	pipe = os.popen(PLAYULAW, 'w')
	#
	lastsender = None
	while 1:
		set1, set2, set3 = select.select(socklist, [], [])
		for s in set1:
			i = socklist.index(s)
			data, sender = s.recvfrom(8192)
			if sender <> lastsender:
				lastsender = sender
				host, port = sender
				try:
					host = nis.match(host, 'hosts.byaddr')
				except nis.error: pass
				print host, port
			if data[:1] in ('\01\0\0\0', '\0\200\0\0', \
				'\0\3\0\0', '\1\0\0\0', '\1\200\0\0', \
				'\1\3\0\0'):
				pipe.write(data[8:])
				pipe.flush()
			else:
				print idlist[i][1], `data`


# Open a UDP socket, bind it to a port and select a multicast group
def openmcastsock(group, port):
	# Import modules used only here
	import regsub
	import socket
	import struct
	from SOCKET import *
	from IN import *
	#
	# Create a socket
	s = socket.socket(AF_INET, SOCK_DGRAM)
	#
	# Bind it to the port
	s.bind('', port)
	#
	# Look up multicast group address in name server
	# (doesn't hurt if it is already in ddd.ddd.ddd.ddd format)
	group = socket.gethostbyname(group)
	#
	# Construct binary group address
	bytes = eval(regsub.gsub('\.', ',', group))
	grpaddr = 0
	for byte in bytes: grpaddr = (grpaddr << 8) | byte
	#
	# Construct struct mreq from grpaddr and ifaddr
	ifaddr = INADDR_ANY
	mreq = struct.pack('ll', grpaddr, ifaddr)
	#
	# Add group membership
	s.setsockopt(IPPROTO_IP, IP_ADD_MEMBERSHIP, mreq)
	#
	return s


main()
