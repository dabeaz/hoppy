# This is an old name for posixpath

# Warn user that this module name is out-of-date
import sys
sys.stderr.write('Warning: you are importing path -- ' + \
	'better import os and use os.path instead\n')
del sys

from posixpath import *
