import string

returntypes = ('int', 'error')
functions = []

def main(file):
	while 1:
		line = file.readline()
		if line == '':
			break
		if line[:2] == '%%':
			break
		if line[0] == '#':
			continue
		functions.append(line[:-1])
	while 1:
		line = file.readline()
		if line == '':
			break
		if line[:2] != '%%':
			print line[:-1]
			continue
		if line[:-1] == '%%functions':
			do_functions()
		if line[:-1] == '%%functionlist':
			do_funclist()

int_types = ('int','boolean','long')

def do_funclist():
	for line in functions:
		name = string.splitfields(line, '\t')[1]
		print '\t{"' + name + '",\tsv_' + name + '},'

def do_functions():
	first = 1
	for line in functions:
		if not first:
			print
		first = 0
		args = string.splitfields(line, '\t')
		[type, name] = args[:2]
		a = []
		i = 0
		for arg in args[2:]:
			i = i + 1
			f = string.splitfields(arg, ':')
			if len(f) == 1:
				a.append((f[0], 'arg'+`i`))
			else:
				a.append((f[0], f[1]))
		args = a
		print 'static object *'
		print 'sv_' + name + '(self, args)'
		print '\tsvobject *self;'
		print '\tobject *args;'
		print '{'
		outarglist = []
		for arg in args:
			if arg[0][:3] == 'out':
				arg = (arg[0][4:], arg[1])
				outarglist.append(arg[1])
			if arg[0] == 'string':
				print '\tchar *' + arg[1] + ';'
			else:
				print '\t' + arg[0] + ' ' + arg[1] + ';'
		if type == 'int':
			print '\tint v;'
			outargs = 'i'
		else:
			outargs = ''
		print
		argstr = ''
		for arg in args:
			arg = arg[0]
			if arg[:3] == 'out':
				arg = arg[4:]
				if arg in int_types:
					outargs = outargs + 'i'
				elif arg == 'string':
					outargs = outargs + 's'
			else:
				if arg in int_types:
					argstr = argstr + 'i'
				elif arg == 'string':
					argstr = argstr + 's'
		if len(argstr) == 0:
			print '\tif (!getnoarg(args))'
		else:
			s = '\tif (!getargs(args, "'
			if len(argstr) > 1:
				s = s + '('
			s = s + argstr
			if len(argstr) > 1:
				s = s + ')'
			s = s + '"'
			for arg in args:
				if arg[0][:3] == 'out':
					continue
				s = s + ', &' + arg[1]
			s = s + '))'
			print s
		print '\t\treturn NULL;'
		print
		if type == 'error':
			s = '\tif ('
		else:
			s = '\tv = '
		s = s + 'sv' + name + '(self->ob_svideo'
		for arg in args:
			s = s + ', '
			if arg[0][:3] == 'out':
				s = s + '&'
			s = s + arg[1]
		s = s + ')'
		if type == 'error':
			s = s + ') {'
			print s
		else:
			s = s + ';'
			print s
			print '\tif (v == -1) {'
		print '\t\terr_setstr(RuntimeError, svStrerror(svideo_errno));'
		print '\t\treturn NULL;'
		print '\t}'
		print
		if len(outargs) == 0:
			print '\tINCREF(None);'
			print '\treturn None;'
		elif len(outargs) == 1:
			s = '\treturn newintobject((long) '
			if type <> 'error':
				s = s + 'v'
			else:
				s = s + outarglist[0]
			s = s + ');'
			print s
		else:
			s = '\treturn mkvalue("(' + outargs + ')"'
			if type <> 'error':
				s = s + ', (long) v'
			for arg in outarglist:
				s = s + ', (long) ' + arg
			s = s + ');'
			print s
		print '}'

import sys
main(sys.stdin)
