extern int global_int;

print_global () {
    printf ("the value of global_int is %d\n", global_int);
}
