# Python test set -- part 3, built-in operations.


print '3. Operations'
print 'XXX Not yet implemented'
